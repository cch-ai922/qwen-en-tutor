---
title: "A Two-Stage Deep-Learning Framework for Forecasting Pests and Diseases in Greenhouse Tomato Cultivation: Improved YOLOv8 Lesion Detection and Distillation-Enhanced Vision-Transformer Pest Classification"
author: "[Author Name]  \n[Department / Laboratory]  \n[University]"
date: "[Month Year]"
abstract: |
  Greenhouse tomato production is chronically threatened by pests and foliar diseases whose early, accurate identification is essential for timely intervention and reduced agrochemical use. This thesis proposes a two-stage visual framework that mirrors how a human scout actually works: first locating suspicious regions across the canopy from a distance, then inspecting them closely to name the causal agent. In the first stage, an *improved YOLOv8* detector locates candidate diseased or infested regions in wide-field ("distant") canopy images. Because such regions are small and low-contrast at distance, the detector is augmented with a high-resolution P2 detection branch and a lightweight Coordinate Attention module, two changes targeted specifically at small-lesion sensitivity. In the second stage, the detected regions are re-imaged at close range and classified by a *distillation-enhanced Vision Transformer*. To overcome the data-hungry nature of transformers on a modest agricultural dataset, the classifier combines a DeiT-style distillation token driven by a convolutional teacher with a two-phase transfer-learning fine-tuning schedule. The detection and classification outputs are aggregated over space and time to drive a simple early-warning module. The proposed components are described in detail and evaluated against representative prior models for both stages, with ablation studies isolating the contribution of each modification. *(Experimental values reported here are illustrative placeholders pending the author's measured results.)*
---

\newpage

# Chapter 1 — Introduction and Review of Prior Studies

## 1.1 Background and Motivation

Tomato (*Solanum lycopersicum*) is among the most economically important greenhouse vegetables worldwide, valued for its yield density, year-round production potential, and nutritional importance. Protected cultivation—greenhouses and plastic tunnels—raises productivity per unit area but also creates a warm, humid, and densely planted micro-environment in which pests and pathogens spread rapidly. Outbreaks of whitefly, aphids, leafminers, spider mites, and thrips, together with foliar diseases such as early blight, late blight, leaf mould, and bacterial spot, can each cause substantial yield loss when detected late. Because pest and disease pressure compounds over time, the practical value of any monitoring system lies less in a single snapshot diagnosis than in the ability to detect emerging problems early and to forecast their development so that growers can intervene before damage becomes severe.

Conventional monitoring relies on periodic manual scouting, in which trained personnel walk the rows and visually inspect plants. This approach is labour-intensive, subjective, and difficult to scale; symptoms are easily missed in their early stages, and the interval between inspections allows infestations to escalate. These limitations have motivated a long line of research into automated, image-based detection and classification of plant pests and diseases [27], and more recently into systems that close the loop between sensing and decision-making for sustainable, reduced-chemical crop protection [33].

The central premise of this thesis is that effective forecasting of greenhouse pests and diseases requires two complementary visual capabilities operating at different spatial scales. At the canopy scale, the system must *locate* where something is wrong—efficiently scanning large areas and flagging candidate regions even when symptoms are small and inconspicuous. At the organ scale, the system must *identify* what the problem is—distinguishing among visually similar pests and diseases from close-up imagery. These two tasks have different statistical structures, different failure modes, and are best served by different model families: a fast one-stage object detector for the first, and a high-capacity fine-grained classifier for the second.

## 1.2 Limitations of Traditional Detection and Classification Methods

Early computer-vision approaches to plant protection relied on hand-crafted features—colour histograms, texture descriptors such as the grey-level co-occurrence matrix, and keypoint descriptors such as SIFT and SURF—coupled with classical classifiers such as support-vector machines, k-nearest neighbours, or random forests [13]. While these pipelines achieved reasonable accuracy under controlled laboratory conditions, their performance degraded sharply under the variable illumination, occlusion, cluttered backgrounds, and scale variation that characterise real greenhouse imagery. The features were brittle: a descriptor tuned for one lighting condition or one cultivar often failed to transfer, and the separation of feature engineering from classification prevented end-to-end optimisation.

The advent of deep convolutional neural networks (CNNs) addressed many of these problems by learning hierarchical features directly from data [30; 32; 18]. CNN-based classifiers trained on large image collections such as the PlantVillage repository [26] demonstrated that disease recognition could be automated at high accuracy [27]. However, two gaps remained for greenhouse deployment. First, image-level classifiers presuppose that the diseased region has already been isolated; they do not, by themselves, find lesions within a wide canopy view. Second, accuracy reported on curated, single-leaf datasets often overstated field performance, because real images contain multiple overlapping leaves, distant small symptoms, and confounding background [28].

### 1.2.1 Greenhouse-Specific Imaging Challenges

Several characteristics of the greenhouse environment make automated visual monitoring harder than the curated benchmarks on which many published models are tuned, and they shape the design decisions taken later in this thesis. Lighting is highly variable: natural daylight through glazing mixes with supplementary artificial lighting, producing strong gradients, specular highlights on glossy leaves, and shifting colour temperature over the day. The canopy is dense and self-occluding, so a symptom may be partly hidden behind overlapping leaves, and the same plant part appears at many orientations. Scale varies enormously between the wide-field view used to scan the canopy and the close-up view needed to read fine detail, which is precisely why a single fixed-scale model is poorly suited to the whole task. Physical factors—camera vibration, condensation, and dust on lenses—further degrade image quality. Finally, the data are intrinsically imbalanced and long-tailed: common pests dominate while economically important but rarer problems are scarce, and the distribution of a specific greenhouse differs from that of any public dataset, creating a domain-shift gap between training and deployment. Each of these factors is revisited in the methodology: scale variation motivates the two-stage design and the P2 branch (Chapter 2), lighting and clutter motivate Coordinate Attention, and data scarcity and imbalance motivate the distillation-based classifier.

## 1.3 Evolution of Object Detection

Object detection—jointly localising and classifying objects—provides the missing capability of finding lesions within a scene. The modern literature divides into two broad families.

**Two-stage detectors.** The region-based CNN (R-CNN) family first generates candidate regions and then classifies each region. R-CNN [8] established the paradigm; Fast R-CNN [9] and Faster R-CNN [10] progressively integrated the stages and introduced a learnable region-proposal network, greatly improving speed and accuracy. Feature Pyramid Networks (FPN) [12] further improved multi-scale detection by fusing features across resolutions. Two-stage detectors remain accurate, particularly for small objects, but their computational cost limits real-time use.

**One-stage detectors.** Single-shot methods frame detection as direct regression over a dense set of locations, predicting boxes and class scores in one forward pass. SSD [11] and RetinaNet (with its focal-loss remedy for foreground–background imbalance [13]) are prominent examples. The You Only Look Once (YOLO) family [1] popularised real-time detection by reformulating the task as a single regression problem over a grid. Successive versions—YOLO9000 [2], YOLOv3 [3], YOLOv4 [4], YOLOv5 [5], YOLOv7 [6], and YOLOv8 [7]—steadily improved the speed–accuracy trade-off through better backbones, multi-scale feature aggregation, anchor-free heads, and refined training recipes [41; 42]. YOLOX [48] notably introduced the anchor-free, decoupled head that YOLOv8 later refined.

**Transformer-based detectors.** More recently, the Transformer architecture [14] has entered detection. DETR [25] reformulated detection as set prediction with a transformer encoder–decoder, removing hand-designed components such as non-maximum suppression, while hierarchical vision transformers such as Swin [24] provided strong detection backbones. These models are powerful but typically heavier and more data-hungry than the YOLO family, which remains the pragmatic choice for real-time, edge-deployable agricultural monitoring.

Within this landscape, **YOLOv8** is an attractive base detector for the first stage of our system. Released by Ultralytics in 2023, it is a single-stage, anchor-free, multi-scale detector built from a CSPDarknet-style backbone with C2f feature-aggregation modules, an SPPF block, a PAN-FPN neck, and a decoupled detection head trained with distribution-focal and CIoU losses [7; 26]. It offers an excellent speed–accuracy balance and a scalable family of model sizes suitable for edge hardware. Its principal weakness for our purpose is sensitivity to *small* objects: the default detection heads operate at strides of 8, 16, and 32 pixels, which is coarse for the tiny, low-contrast lesions seen in distant canopy images. This weakness directly motivates the improvements described in Chapter 2.

## 1.4 Image Classification and Vision Transformers for Fine-Grained Recognition

Once a candidate region is localised and re-imaged at close range, naming the specific pest or disease is a fine-grained classification problem, characterised by small inter-class differences (e.g., distinguishing whitefly from aphid damage) and large intra-class variation (e.g., the same pest at different life stages). CNNs such as ResNet [18], EfficientNet [19], and the mobile-efficient MobileNetV3 [20] are strong baselines for this task.

The Vision Transformer (ViT) [15] reframed image classification by splitting an image into fixed-size patches, embedding each patch as a token, prepending a learnable classification token, adding positional embeddings, and processing the sequence with a standard Transformer encoder [14]. ViT can match or exceed CNNs on large datasets and captures long-range dependencies that benefit fine-grained discrimination. Its weakness is a *lack of inductive bias*: because it does not assume locality or translation equivariance the way convolutions do, it requires very large training sets to reach its potential—an unrealistic requirement for a specialised agricultural dataset.

The Data-efficient image Transformer (DeiT) [16] resolves this tension through knowledge distillation [17]. DeiT introduces a dedicated *distillation token* alongside the class token; this token learns to reproduce the predictions of a teacher network—ideally a CNN, whose convolutional inductive bias is thereby transferred to the transformer student—through the attention mechanism. With this token-based distillation and a carefully designed training recipe, DeiT reaches competitive accuracy using only mid-sized data and a single machine, rather than the hundreds of millions of images the original ViT required. This data-efficiency property is precisely what a greenhouse pest classifier needs, and it directly motivates the classifier improvements in Chapter 2.

## 1.5 Related Work on Plant Pest and Disease Recognition

A large and growing body of work applies these architectures to plant protection. On the detection side, numerous studies adapt the YOLO family to tomato leaf disease. Improved YOLOv8 variants have been reported to raise mean average precision over the baseline by integrating attention mechanisms and better multi-scale fusion: examples include receptive-field-attention designs that replace the SPPF module and add adaptive spatial feature fusion [34], lightweight attention modules such as SimAM combined with dynamic convolution [35], and CBAM-style channel–spatial attention [21] integrated into YOLOv8 detection pipelines [36]. Comparative studies confirm that YOLOv8-based detectors outperform earlier YOLOv5 and Faster R-CNN baselines on tomato leaf datasets while sustaining real-time frame rates [36]. Multi-scale-fusion designs have specifically targeted the missed detection of small, densely clustered, or early-stage low-contrast symptoms [43], and optimisation-oriented studies have shown that careful choice of optimiser and training schedule yields consistent gains in precision, recall, and mAP for tomato leaf disease detection in sustainable-agriculture settings [33].

On the classification side, transformer and hybrid transformer–CNN models have become prominent. Vision transformers and refined ViT variants have been applied to plant-leaf disease classification with strong accuracy and the added benefit of attention-based localisation of infected regions [37]. Hybrid ViT–CNN designs and lightweight transformers have been proposed for real-time disease detection and pest classification, sometimes coupled with explainability methods such as Grad-CAM [44] and SHAP [45] to make predictions interpretable to growers [38]. Attention-score-based multi-transformer techniques have reported very high accuracy on apple, grape, and tomato leaf datasets, outperforming ResNet, VGG, and MobileNet baselines [39], and multi-stage transformer frameworks augmented with semantic knowledge have been used to scale classification across many disease categories [40]. For insect pests specifically, the large-scale IP102 benchmark [29]—over 75,000 images across 102 categories with a long-tailed distribution and roughly 19,000 detection-annotated images—has become a standard testbed for both classification and detection of agricultural pests.

## 1.6 Research Gap and Problem Statement

Three observations emerge from this review. First, most existing systems address *either* detection *or* classification in isolation, whereas effective greenhouse forecasting requires both, operating at different spatial scales. A single-stage classifier on whole-canopy images struggles with small symptoms and clutter; a detector alone produces coarse "diseased/not-diseased" boxes without the fine-grained pest identity needed to choose a treatment. Second, detectors applied to distant canopy imagery consistently under-perform on small, low-contrast lesions—the very symptoms that matter most for *early* warning. Third, transformer classifiers, although well suited to fine-grained pest identification, are data-hungry and tend to be trained from scratch or naively fine-tuned on small agricultural datasets, leaving their data-efficiency potential untapped.

The problem addressed by this thesis is therefore: *how to design a practical, accurate, and real-time-capable visual system that (i) reliably localises small, early-stage pest and disease symptoms across the greenhouse canopy, and (ii) identifies the specific causal agent from close-up imagery with high accuracy despite limited training data, in a form whose outputs can drive temporal forecasting and early warning.*

## 1.7 Purpose and Objectives

The purpose of this research is to develop and evaluate a two-stage detection-then-classification framework for forecasting pests and diseases in greenhouse tomatoes. The specific objectives are:

1. To design an improved YOLOv8 detector that increases sensitivity to small, low-contrast lesions in distant canopy images, through a high-resolution detection branch and a lightweight attention mechanism, while preserving real-time speed (Chapter 2, Section 1).
2. To design a distillation-enhanced Vision Transformer classifier that achieves high fine-grained accuracy on a modest pest dataset, through token-based knowledge distillation from a convolutional teacher and a principled two-phase fine-tuning schedule (Chapter 2, Section 2).
3. To integrate the two stages into a coherent system, with a sensing-to-decision data flow and a temporal aggregation module supporting early warning (Chapter 3).
4. To evaluate each stage rigorously against representative prior models, and to isolate the contribution of each proposed modification through ablation studies (Chapter 3).

## 1.8 Contributions

The principal contributions are: (1) a clearly motivated two-stage architecture matching model choice to spatial scale; (2) a small-lesion-oriented improvement of YOLOv8 combining a P2 detection branch with Coordinate Attention, described and ablated in detail; (3) a data-efficient ViT classifier combining DeiT-style distillation with a two-phase fine-tuning schedule; and (4) a comparative evaluation protocol against prior detection and classification models. The methodological emphasis throughout is on a small number of well-justified, clearly explained improvements rather than a large collection of incremental tricks.

## 1.9 Organisation of the Thesis

The remainder of the thesis is organised as follows. **Chapter 2** presents the methodology in two sections: Section 1 details the improved YOLOv8 lesion detector, and Section 2 details the distillation-enhanced ViT pest classifier. **Chapter 3** describes the system configuration, implementation, datasets, evaluation metrics, and the experimental comparison against prior models, including ablation studies, followed by discussion. The thesis closes with conclusions and directions for future work, and a list of references.

\newpage
# Chapter 2 — Methodology

This chapter presents the two-stage framework in detail. The overall pipeline is shown in Figure 1. A wide-field camera images the canopy; the improved YOLOv8 detector of Section 2.1 locates candidate diseased or infested regions. Each region guides the capture (or cropping) of a close-up image, which the distillation-enhanced Vision Transformer of Section 2.2 classifies into a specific pest or disease category. The classified detections are aggregated spatially and temporally to support forecasting, as described in Chapter 3.

![Two-stage greenhouse pest and disease forecasting pipeline. Stage 1 (detection) operates on distant canopy images; Stage 2 (classification) operates on close-up crops of the regions flagged by Stage 1.](figs/fig_pipeline.png)

A guiding design principle is restraint: rather than stacking many modifications, each stage introduces only a small number of changes, each chosen because it addresses a specific, well-understood weakness of the base model. Section 2.1 introduces two coupled changes to the detector (a high-resolution detection branch and a positional attention module) aimed at small-lesion sensitivity. Section 2.2 introduces two changes to the classifier (token-based distillation and a two-phase fine-tuning schedule) aimed at data efficiency. The reasoning behind each change is explained before its formulation.

## 2.1 Section 1 — Improved YOLOv8 for Lesion Detection in Distant Images

### 2.1.1 Base Detector and the Small-Object Problem

The base detector is YOLOv8 [7]. Architecturally it comprises three parts: a *backbone* (a CSPDarknet-derived network whose central building block is the C2f module, which splits the input, processes part of it through a series of lightweight bottlenecks, and concatenates all intermediate outputs to improve gradient flow and channel-information reuse); a *neck* (a path-aggregation feature-pyramid network, PAN-FPN, that fuses features top-down and bottom-up across scales); and a *decoupled, anchor-free head* that predicts, at each location, a class distribution and a bounding-box offset, the latter via a distribution-focal-loss (DFL) formulation, with CIoU used for box regression [7; 47]. Detection is performed at three pyramid levels, conventionally denoted P3, P4, and P5, corresponding to feature strides of 8, 16, and 32 pixels relative to the input.

The difficulty in our setting is one of *scale*. In a distant canopy image, an early-stage lesion or a small insect may occupy only a handful of pixels. The smallest YOLOv8 detection level, P3 at stride 8, assigns one feature-map cell to an 8×8 input region; objects smaller than this are poorly represented, because the spatial detail needed to localise and characterise them has already been pooled away by the time features reach P3. Empirically, this manifests as missed detections and imprecise boxes for exactly the small, early symptoms that an *early-warning* system most needs to catch. The two modifications below address this directly.

### 2.1.2 Improvement 1 — A High-Resolution P2 Detection Branch

The first modification adds a fourth detection level, **P2**, at stride 4. The backbone already computes a stride-4 feature map early in its hierarchy; the standard architecture simply does not attach a detector to it. We extend the neck so that the top-down pathway continues one level further, fusing the high-resolution stride-4 backbone features with up-sampled semantic features from P3, and we attach an additional decoupled head to the resulting P2 feature map. Detection is then performed over four levels, P2–P5, at strides {4, 8, 16, 32}.

Conceptually, the P2 branch quadruples the spatial sampling density relative to P3: each P2 cell corresponds to a 4×4 input region rather than 8×8, so a lesion only a few pixels across is now covered by several cells rather than falling between samples. Because YOLOv8 is anchor-free and predicts object centres directly, no anchor re-design is required; the new head simply predicts centres and box distributions at the finer resolution. The architecture is illustrated in Figure 2.

![Improved YOLOv8 detector. A high-resolution P2 detection branch (stride 4) is added to the standard P3–P5 levels, and a Coordinate Attention module is inserted before each detection head. The P2 branch increases sampling density for small lesions; Coordinate Attention preserves the positional information those lesions depend on.](figs/fig_yolo.png)

The cost of the P2 branch is additional computation and memory, because it operates on a large feature map. To keep the detector real-time on edge hardware, we (i) use a lightweight head for P2 with reduced channel width, and (ii) retain the nano/small backbone scale. The trade-off—modestly higher latency for substantially better small-object recall—is quantified in the ablation study of Chapter 3.

### 2.1.3 Improvement 2 — Coordinate Attention before the Detection Heads

Adding resolution is necessary but not sufficient: high-resolution feature maps also carry more background clutter (leaf veins, water droplets, lighting gradients) that can produce false positives. The second modification therefore inserts a lightweight attention module, **Coordinate Attention (CA)** [22], immediately before each detection head, so that the network learns to emphasise the channels and spatial locations that correspond to genuine lesions.

Unlike channel-only attention such as squeeze-and-excitation [23], or the spatial attention of CBAM [21] which pools positional information into a single map, Coordinate Attention preserves *directional* positional structure—important when a lesion's location within the field of view matters. Given an input feature map $X \in \mathbb{R}^{C\times H\times W}$, CA first applies two one-dimensional average-pooling operations, one along the width and one along the height, producing a pair of direction-aware descriptors:

$$
z_c^{h}(h) = \frac{1}{W}\sum_{w=1}^{W} x_c(h,w), \qquad
z_c^{w}(w) = \frac{1}{H}\sum_{h=1}^{H} x_c(h,w).
$$

These two descriptors are concatenated and passed through a shared $1\times1$ convolution with batch normalisation and a non-linear activation $\delta$ to produce an intermediate representation $f$:

$$
f = \delta\big(\mathrm{BN}(W_1\,[\,z^{h},\,z^{w}\,])\big).
$$

The intermediate $f$ is split back into a height branch and a width branch, each passed through its own $1\times1$ convolution and a sigmoid $\sigma$ to yield two attention weights:

$$
g^{h} = \sigma(W_h\, f^{h}), \qquad g^{w} = \sigma(W_w\, f^{w}).
$$

Finally, the input is re-weighted by the outer combination of the two directional gates:

$$
y_c(h,w) = x_c(h,w)\;\cdot\;g_c^{h}(h)\;\cdot\;g_c^{w}(w).
$$

The structure is shown in Figure 3. Intuitively, $g^h$ answers "which rows matter?" and $g^w$ answers "which columns matter?"; their product sharpens the response at lesion locations while suppressing clutter, at negligible parameter cost (two $1\times1$ convolutions). Placing CA before the heads—rather than throughout the backbone—keeps the overhead small and focuses the attention where the localisation decision is actually made.

![Coordinate Attention module. Factorised pooling along height and width yields two direction-aware descriptors that are fused and split into per-row and per-column gates, which re-weight the input feature map.](figs/fig_ca.png)

### 2.1.4 Training Objective

Training uses the standard YOLOv8 multi-task loss, now summed over four detection levels rather than three. For each level the loss combines a classification term, a box-regression term, and a distribution-focal term:

$$
\mathcal{L}_{\text{det}} = \lambda_{\text{cls}}\,\mathcal{L}_{\text{cls}}
+ \lambda_{\text{box}}\,\mathcal{L}_{\text{CIoU}}
+ \lambda_{\text{dfl}}\,\mathcal{L}_{\text{DFL}},
$$

where $\mathcal{L}_{\text{cls}}$ is binary cross-entropy over classes, $\mathcal{L}_{\text{CIoU}}$ is the complete-IoU regression loss [47], and $\mathcal{L}_{\text{DFL}}$ is the distribution-focal loss that models each box coordinate as a discrete distribution. Positive samples are assigned by YOLOv8's task-aligned assigner, which scores candidates by a combination of classification confidence and IoU. The loss weights $\lambda_\ast$ follow the YOLOv8 defaults unless otherwise stated. No change to the loss form is required by our modifications; the P2 branch simply contributes additional terms at the finer scale, and Coordinate Attention is trained end-to-end with the rest of the network.

### 2.1.5 Summary of Section 1

In summary, the improved detector makes two targeted changes—a P2 high-resolution branch and a Coordinate Attention module before the heads—each addressing a distinct aspect of the small-lesion problem (sampling density and clutter suppression, respectively). Both are inexpensive, require no anchor re-engineering thanks to YOLOv8's anchor-free design, and are validated individually and jointly in the ablation study of Chapter 3.

### 2.1.6 Detection-to-Classification Interface

The two stages are coupled by a deterministic interface that converts detector outputs into classifier inputs. After the detector produces boxes, low-confidence predictions are removed by a confidence threshold $\tau_{\text{conf}}$ and duplicate boxes are merged by non-maximum suppression at IoU threshold $\tau_{\text{nms}}$. Each surviving box is then expanded by a padding factor $\rho$ to include diagnostic context around the lesion (the surrounding leaf tissue often carries information needed to distinguish causes), giving a crop region

$$
w' = (1+\rho)\,w, \qquad h' = (1+\rho)\,h,
$$

centred on the original box and clipped to the image bounds. In a PTZ configuration, the expanded box centre is mapped to pan/tilt angles and a zoom level so that the macro camera re-images the region at high resolution; in a fixed-camera configuration, the crop is taken directly from the high-resolution wide-field frame. Crops smaller than a minimum size are up-sampled to the classifier's input resolution, and multiple crops from one frame are batched for efficient classification. This interface deliberately keeps the two models decoupled, so that either can be retrained or replaced independently, and so that the confidence and padding parameters can be tuned to trade recall for precision at the system level.

### 2.1.7 Complexity and Real-Time Considerations

The principal cost of the proposed detector is the P2 branch, which operates on a stride-4 feature map four times larger in each spatial dimension than P3 and therefore dominates the added computation. Three measures keep the detector real-time on edge hardware: the P2 head uses a reduced channel width; Coordinate Attention adds only two $1\times1$ convolutions and is therefore negligible in cost; and inference uses half-precision and, where available, a TensorRT-optimised engine. The net effect, quantified in Chapter 3, is a modest reduction in frame rate relative to the baseline in exchange for a substantial gain in small-lesion recall—an exchange that is favourable for an early-warning application, where missing an emerging problem is more costly than a small latency increase.

## 2.2 Section 2 — Distillation-Enhanced Vision Transformer for Pest Identification

### 2.2.1 Base Classifier and the Data-Efficiency Problem

The second stage classifies the close-up image of each detected region into a specific pest or disease category. The base classifier is a Vision Transformer (ViT-B/16) [15]: the input image is divided into non-overlapping $16\times16$ patches, each patch is linearly projected to a token embedding, a learnable class token is prepended, positional embeddings are added, and the resulting sequence is processed by a stack of Transformer encoder blocks, each consisting of multi-head self-attention (MSA) and a feed-forward MLP with residual connections and layer normalisation [14]. The final class-token representation is mapped to class scores by a linear head.

ViT's strength—global self-attention that relates distant image regions—is well matched to fine-grained pest identification, where the discriminative cue may be a wing pattern, an antenna, or the distribution of feeding damage across the leaf. Its weakness is that, lacking the convolutional priors of locality and translation equivariance, it must learn these regularities from data and therefore needs very large training sets to generalise [15]. A specialised greenhouse pest dataset is, by contrast, modest in size and long-tailed in class frequency [29]. Training a ViT from scratch on such data over-fits badly. The two modifications below make the transformer data-efficient.

### 2.2.2 Improvement 1 — Token-Based Knowledge Distillation (DeiT-style)

The first and primary modification adopts the **distillation-token** strategy of DeiT [16], which transfers knowledge [17] from a convolutional *teacher* into the transformer *student* through the attention mechanism itself.

Concretely, in addition to the usual class token, we append a second special token—the **distillation token**—to the input sequence. Like the class token, it interacts with all patch tokens through self-attention across the encoder, but its supervisory signal is different: whereas the class token is trained against the ground-truth label, the distillation token is trained to match the prediction of a teacher network. The teacher is a convolutional network (we use an EfficientNet [19] fine-tuned on the same pest data), chosen precisely because its convolutional inductive bias is the property the transformer lacks; distilling from a CNN teacher therefore injects that bias into the student. Figure 4 shows the architecture.

![Distillation-enhanced ViT. A distillation token is added alongside the class token; it is supervised by a fine-tuned convolutional teacher through hard-label distillation, while the class token is supervised by the ground-truth label. At inference the two token predictions are fused.](figs/fig_vit.png)

We use *hard-label* distillation, which DeiT found to work well and which is simple to implement: the teacher's top-1 prediction $y_t = \arg\max_c Z_t(c)$ is treated as an additional target. Writing $\psi$ for the softmax function, $Z_s^{\text{cls}}$ and $Z_s^{\text{dist}}$ for the student's class-token and distillation-token logits, $y$ for the ground-truth label, and $\mathcal{L}_{\text{CE}}$ for cross-entropy, the training objective is

$$
\mathcal{L}_{\text{ViT}} = \tfrac{1}{2}\,\mathcal{L}_{\text{CE}}\big(\psi(Z_s^{\text{cls}}),\,y\big)
\;+\; \tfrac{1}{2}\,\mathcal{L}_{\text{CE}}\big(\psi(Z_s^{\text{dist}}),\,y_t\big).
$$

The first term trains the class token toward the true label; the second trains the distillation token toward the teacher's decision. Crucially, the two tokens are *separate*: they are free to converge to slightly different, complementary solutions rather than being forced to agree, which DeiT showed yields better results than distilling into a single token. At inference, the two predictions are fused—here by averaging the post-softmax probabilities of the class and distillation tokens—to produce the final classification.

The benefit in our setting is twofold. First, data efficiency: the teacher supplies a dense, informative training signal that compensates for the limited number of labelled pest images, allowing the transformer to reach high accuracy without the massive datasets ViT normally demands. Second, inductive bias: by learning to imitate a convolutional teacher, the student inherits useful priors about locality and texture that are well suited to the fine-grained, texture-rich appearance of pests and lesions.

### 2.2.3 Improvement 2 — Two-Phase Transfer-Learning Fine-Tuning

The second modification concerns *how* the transformer is adapted to the pest domain. Rather than fine-tuning a pretrained ViT naively (which, with a freshly initialised classification head, can destabilise the well-trained backbone in the first epochs and erase valuable pretrained features), we use a disciplined **two-phase schedule** built on a model pretrained on ImageNet [31].

In **Phase 1 (linear probing)**, the entire transformer backbone is frozen and only the new classification head (and the distillation token's head) are trained. This lets the randomly initialised head settle into a sensible region of parameter space using the fixed, high-quality pretrained features, without corrupting them. In **Phase 2 (full fine-tuning)**, the backbone is unfrozen and the whole network is trained end-to-end at a smaller learning rate, using **layer-wise learning-rate decay** so that layers closer to the input—which encode generic, broadly transferable features—are updated more gently than layers closer to the output, which must specialise to pest categories. Concretely, the learning rate of layer $\ell$ is scaled as

$$
\eta_\ell = \eta_{\text{base}}\cdot \xi^{\,(L-\ell)},
$$

where $L$ is the number of layers, $\ell$ indexes from input to output, and $\xi \in (0,1)$ is the decay factor (e.g., $\xi=0.75$). We optimise with AdamW [46], which decouples weight decay from the gradient update and is the standard choice for stable transformer fine-tuning, together with a cosine learning-rate schedule and a short warm-up. Standard augmentations appropriate to fine-grained natural imagery (random resized crop, horizontal flip, colour jitter, and mild RandAugment) regularise training without distorting the diagnostic cues. Resolution is handled following the DeiT practice of training at a lower resolution and optionally fine-tuning at a higher one, with positional embeddings interpolated when the number of patches changes [16].

This two-phase schedule is conceptually simple but materially important: it is what allows a high-capacity transformer to be adapted reliably on a modest dataset without over-fitting or catastrophic forgetting, and it composes naturally with the distillation token of the previous subsection (the teacher's signal is available throughout both phases).

### 2.2.4 Summary of Section 2

The classifier therefore makes two targeted changes—token-based distillation from a convolutional teacher, and a two-phase fine-tuning schedule with layer-wise learning-rate decay—both aimed at the single underlying problem of making a data-hungry transformer work well on a modest, long-tailed pest dataset. As in Section 2.1, the changes are few, individually motivated, and individually ablated in Chapter 3.

\newpage
## 2.3 Data Preprocessing and Augmentation

Both stages rely on augmentation to bridge the gap between training data and greenhouse conditions, but the two stages are augmented differently because they face different invariances. For the **detector**, mosaic augmentation (compositing four images) enriches context and small-object frequency, and is disabled for the final training epochs because its synthetic layouts otherwise bias the late-stage optimisation; HSV jitter improves robustness to the greenhouse's variable lighting and colour temperature; and random scaling and translation build tolerance to the scale variation inherent in canopy imaging. For the **classifier**, augmentation must preserve the fine diagnostic cues that define pest identity, so random resized cropping, horizontal flipping, mild colour jitter, and a moderate RandAugment policy are used, while aggressive mixing augmentations are applied cautiously to avoid blending class-defining detail. Class imbalance—pronounced in pest data [29]—is addressed with class-balanced sampling and, where needed, loss re-weighting so that rare but important categories are not ignored. All images are normalised to the statistics of the pretraining corpus [31] to match the distribution the backbones expect.

## 2.4 Implementation of the Integrated Pipeline

At run time the system executes a simple, auditable loop per inspection cycle. For each canopy section: (1) acquire a wide-field frame and record the micro-climate; (2) run the improved detector to obtain lesion boxes; (3) apply confidence thresholding, NMS, and padding to form crop regions (Section 2.1.6); (4) acquire or extract close-up crops and classify each with the distillation-enhanced ViT; (5) write each classified detection, with its location, class, confidence, and timestamp, to the incidence record; and (6) update the forecasting/early-warning state (Chapter 3). The detector runs on the edge device and only the small crops and metadata are transmitted upstream, while the classifier and forecasting logic run on the server. Because the steps are explicit and the two models are decoupled, the pipeline is straightforward to test stage by stage, to profile for latency, and to extend—for example by inserting a tracking step so that the same lesion observed across cycles is associated into a single growing instance.

# Chapter 3 — System Configuration, Implementation, and Performance Evaluation

> **Note on results.** The quantitative values in the tables and result figures of this chapter are *illustrative placeholders* that show the intended structure of the evaluation. They must be replaced with the author's actual measured results before submission. The experimental design, metrics, baselines, and ablations are real and ready to use.

## 3.1 System Configuration

The deployed system, shown in Figure 5, consists of three tiers. A **greenhouse sensing node** carries two cameras and environmental sensors. A wide-field RGB camera images each canopy section at fixed intervals to feed Stage 1; a pan–tilt–zoom (PTZ) or motorised macro camera captures close-up images of the regions flagged by Stage 1 to feed Stage 2. (Where a PTZ camera is unavailable, the close-up image is approximated by a high-resolution crop of the wide-field frame around the detected box.) Temperature and relative-humidity sensors record the micro-climate, which is a strong covariate of pest and disease development and is used by the forecasting module.

![System configuration and data flow across the sensing node, edge device, and server.](figs/fig_system.png)

An **edge device** (e.g., an NVIDIA Jetson-class module) runs the Stage-1 detector in real time, so that only small cropped regions—rather than full-resolution video—need to be transmitted upstream. A **server** runs the Stage-2 transformer classifier and the forecasting/early-warning module, and hosts a dashboard for growers. This division keeps bandwidth and latency low while concentrating the heavier transformer computation where GPU resources are available.

### 3.1.1 From Detection to Forecasting

Forecasting is built on the time series of classified detections. For each canopy section and each pest/disease class, the system accumulates an incidence count per inspection cycle, producing a spatio-temporal record of where and how fast symptoms are appearing. A lightweight early-warning rule combines the trend in incidence with the measured micro-climate: when the rate of increase of a class crosses a threshold under conducive temperature/humidity conditions, an alert is raised and localised on a canopy map. This deliberately simple, interpretable mechanism is appropriate for grower decision support and avoids over-claiming predictive precision; more elaborate temporal models are noted as future work in the conclusion.

## 3.2 Implementation Details

The detector is implemented in PyTorch using the Ultralytics framework [7], extended with the additional P2 head and the Coordinate Attention module of Section 2.1. The classifier is implemented in PyTorch using a standard ViT-B/16 backbone with an added distillation token (Section 2.2); the convolutional teacher is an EfficientNet [19] fine-tuned on the same close-up data. Representative training configurations are summarised in Table 1; these should be adjusted to the author's hardware and final dataset.

Table 1. Representative training configuration (to be finalised by the author).

| Setting | Stage 1 — Improved YOLOv8 | Stage 2 — Distillation-ViT |
|---|---|---|
| Backbone / scale | YOLOv8-s + P2 + CA | ViT-B/16 (ImageNet-pretrained) |
| Teacher | — | EfficientNet (fine-tuned) |
| Input resolution | 640 × 640 | 224 × 224 (opt. 384 fine-tune) |
| Optimiser | SGD / AdamW | AdamW [46] |
| LR schedule | cosine, warm-up | cosine, warm-up, layer-wise decay |
| Batch size | [fill in] | [fill in] |
| Epochs | [fill in] | Phase 1: [fill]; Phase 2: [fill] |
| Augmentation | mosaic, flip, HSV, scale | RRC, flip, colour jitter, RandAugment |
| Hardware | edge GPU (e.g. Jetson) | server GPU |

## 3.3 Datasets

Three categories of data support the system. For **Stage-1 detection**, public tomato leaf disease detection sets and field-style sets such as PlantDoc [28] provide bounding-box-annotated lesions, complemented by curated single-leaf imagery from the PlantVillage repository [26]. For **Stage-2 classification**, the large-scale IP102 insect-pest benchmark [29] supplies fine-grained pest categories, again complemented by leaf-disease classification data. A **self-collected greenhouse dataset**—wide-field and close-up image pairs captured under real production conditions and expert-annotated—is used to evaluate the integrated system under deployment-realistic distribution shift. Table 2 records the dataset composition; counts are placeholders to be completed by the author.

Table 2. Dataset composition (placeholder counts).

| Dataset | Role | Classes | Images | Annotation |
|---|---|---|---|---|
| Tomato leaf disease (public) | Stage-1 train/val | [n] | [n] | boxes |
| PlantDoc [28] | Stage-1 field test | [n] | [n] | boxes |
| IP102 [29] | Stage-2 train/val | up to 102 | ~75,000 | labels (subset: boxes) |
| Self-collected greenhouse | Integrated test | [n] | [n] | boxes + labels |

## 3.4 Evaluation Metrics

**Detection (Stage 1).** Detections are scored by Intersection over Union (IoU) between a predicted box $B_p$ and ground-truth box $B_{gt}$:

$$
\mathrm{IoU} = \frac{|B_p \cap B_{gt}|}{|B_p \cup B_{gt}|}.
$$

From IoU-thresholded matches we compute precision and recall,

$$
P = \frac{TP}{TP+FP}, \qquad R = \frac{TP}{TP+FN},
$$

and summarise the precision–recall curve by Average Precision (AP), the area under that curve, averaged over classes to give mean Average Precision (mAP). We report **mAP@0.5** (IoU threshold 0.5) and **mAP@0.5:0.95** (averaged over IoU thresholds from 0.5 to 0.95 in steps of 0.05), together with inference speed in frames per second (FPS) and model size (parameters), since real-time edge deployment is a design goal.

**Classification (Stage 2).** We report top-1 accuracy and, because the pest distribution is long-tailed, per-class precision and recall and the macro-averaged F1 score,

$$
F1 = \frac{2\,P\,R}{P+R},
$$

together with a confusion matrix to expose systematic inter-class errors.

### 3.4.1 Experimental Protocol

To make the comparison fair and the results trustworthy, all models within a stage are trained and evaluated under identical conditions: the same train/validation/test partition, the same input resolution, and the same augmentation budget, differing only in the architecture under test. Hyper-parameters are selected on the validation split only; the test split is touched once, for final reporting. Because deep-network training is stochastic, each configuration is run several times with different random seeds and results are reported as mean $\pm$ standard deviation, so that a claimed improvement can be distinguished from run-to-run noise; where appropriate, a paired significance test is applied to the per-image scores of two models. The self-collected greenhouse set is held out entirely from training and used only to measure performance under realistic distribution shift. Training uses early stopping on the validation metric to avoid over-fitting, and all software versions, seeds, and configurations are recorded for reproducibility.

## 3.5 Detection Results: Comparison with Prior Models

The improved detector is compared against representative prior models—Faster R-CNN [10], SSD [11], YOLOv5 [5], YOLOv7 [6], and the YOLOv8 baseline [7]—trained and evaluated under identical data splits and augmentation. Figure 6 and Table 3 report the comparison (illustrative values).

![Detection performance versus prior models (illustrative values; replace with measured results). Bars show mAP@0.5 and mAP@0.5:0.95; the dashed line shows inference speed (FPS).](figs/fig_det_compare.png)

Table 3. Detection comparison on the tomato lesion test set (ILLUSTRATIVE — replace with measured values).

| Model | mAP@0.5 (%) | mAP@0.5:0.95 (%) | Params (M) | FPS |
|---|---|---|---|---|
| Faster R-CNN [10] | 78.1 | 49.0 | 41.5 | 22 |
| SSD [11] | 74.5 | 45.2 | 24.0 | 61 |
| YOLOv5s [5] | 81.3 | 52.1 | 7.2 | 118 |
| YOLOv7 [6] | 83.0 | 54.3 | 36.9 | 96 |
| YOLOv8s [7] | 84.6 | 56.0 | 11.2 | 130 |
| **Ours (P2 + CA)** | **88.2** | **60.8** | 12.4 | 112 |

The intended narrative—to be confirmed by the author's data—is that the proposed detector achieves the highest mAP, with the largest relative gain on small lesions, while retaining real-time speed; the modest FPS reduction relative to the baseline is the expected cost of the high-resolution P2 branch.

## 3.6 Classification Results: Comparison with Prior Models

The distillation-enhanced classifier is compared against CNN baselines—ResNet-50 [18], MobileNetV3 [20], EfficientNet-B0 [19]—and against transformer baselines—a vanilla ViT-B/16 [15] and DeiT-B [16]—all fine-tuned on the same close-up data. Figure 7 and Table 4 report the comparison (illustrative values).

![Classification performance versus prior models (illustrative values; replace with measured results).](figs/fig_cls_compare.png)

Table 4. Classification comparison on the close-up pest test set (ILLUSTRATIVE — replace with measured values).

| Model | Top-1 Acc (%) | Macro F1 (%) | Params (M) |
|---|---|---|---|
| ResNet-50 [18] | 89.4 | 88.7 | 25.6 |
| MobileNetV3 [20] | 87.1 | 86.2 | 5.4 |
| EfficientNet-B0 [19] | 91.2 | 90.6 | 5.3 |
| ViT-B/16 [15] | 90.0 | 89.1 | 86.6 |
| DeiT-B [16] | 92.3 | 91.7 | 86.6 |
| **Ours (KD-ViT)** | **94.6** | **94.0** | 86.6 |

The intended finding is that token-based distillation plus the two-phase schedule lifts the transformer above both the CNN baselines and the plain transformer baselines, with the gain most pronounced on under-represented (long-tail) pest classes, where the teacher's signal is most valuable.

## 3.7 Ablation Studies

To isolate the contribution of each proposed change, Figure 8 reports two ablations: the detector with neither, either, or both of the P2 branch and Coordinate Attention; and the classifier with neither, either, or both of the two-phase fine-tuning schedule and the distillation token.

![Ablation studies (illustrative values; replace with measured results). Left: detector. Right: classifier.](figs/fig_ablation.png)

The detector ablation is intended to show that the P2 branch contributes the larger share of the small-object gain, that Coordinate Attention adds a further improvement chiefly by reducing false positives on cluttered high-resolution features, and that the two are complementary. The classifier ablation is intended to show that both the fine-tuning schedule and the distillation token help individually and combine for the best result. A representative per-class error structure for the classifier is shown as a confusion matrix in Figure 9.

![Confusion matrix for the close-up pest classifier (illustrative). Off-diagonal mass indicates the most common inter-class confusions, e.g. between visually similar small insects.](figs/fig_confusion.png)

## 3.8 Qualitative Results and Error Analysis

Beyond aggregate metrics, qualitative inspection is used to understand *how* the model succeeds or fails, since two models with similar mAP can behave very differently in practice. The improvements of Chapter 2 are expected to manifest in specific, visible ways: the P2 branch should recover small, early-stage lesions that the baseline misses entirely, shifting errors from missed detections (false negatives) toward, at worst, slightly imprecise boxes; Coordinate Attention should reduce false positives triggered by leaf veins, water droplets, and lighting gradients on the high-resolution feature map. For the classifier, the dominant residual errors are expected to be confusions between visually similar agents—for example among small sap-sucking insects, or between early symptoms of different foliar diseases—as reflected in the off-diagonal structure of the confusion matrix (Figure 9). The hardest cases are anticipated to be heavy occlusion, extreme back-lighting, and rare long-tail classes with few training examples; these define where additional data collection and the domain-adaptation work of the conclusion would be most valuable. Documenting representative success and failure crops, including the model's attention maps, is recommended both for transparency and because reviewers value seeing failure cases honestly reported.

## 3.9 Computational Cost and Deployment Considerations

Because the system is intended for real production use, computational cost is a first-class evaluation criterion alongside accuracy. The relevant quantities are the detector's edge latency and frame rate, the classifier's server-side throughput, peak memory on each device, and the upstream bandwidth required. The architecture is designed to keep these favourable: running the detector on the edge means only small crops and metadata, rather than full-resolution video, traverse the network, substantially reducing bandwidth; half-precision and engine-level optimisation keep edge latency within budget despite the added P2 branch; and batching crops amortises the classifier's per-image cost on the server. A deployment-cost table—edge latency, FPS, edge and server memory, and bandwidth per cycle—should be reported alongside the accuracy tables so that the accuracy gains of the proposed components can be weighed against their resource cost. Quantisation and detector–classifier co-distillation, noted in the conclusion, are the natural next steps for fully on-edge operation.

## 3.10 Discussion

Read together, the intended results support the thesis's central design choice: matching model family to spatial scale. Stage 1 shows that a small number of scale-aware modifications recover the small-lesion sensitivity that early warning requires, without sacrificing the real-time speed that makes YOLOv8 attractive in the first place. Stage 2 shows that the data-efficiency problem that normally discourages the use of transformers on specialised agricultural data can be addressed directly, through distillation and disciplined transfer learning, rather than by abandoning the transformer for a CNN.

Several limitations should be stated honestly. The placeholder results must be replaced by measured values, and the conducive-condition forecasting rule is deliberately simple. The system's accuracy under severe occlusion, extreme lighting, and rare pest classes remains to be characterised on the self-collected greenhouse set, and the close-up capture step assumes either a PTZ camera or sufficient wide-field resolution. These are addressed as future work.

\newpage

# Conclusion and Future Work

This thesis proposed and described in detail a two-stage visual framework for forecasting pests and diseases in greenhouse tomatoes. The first stage improves YOLOv8 for small-lesion detection in distant canopy images through two targeted, individually justified changes—a high-resolution P2 detection branch and a Coordinate Attention module before the heads. The second stage makes a Vision Transformer data-efficient for fine-grained pest identification in close-up images through token-based knowledge distillation from a convolutional teacher and a two-phase transfer-learning fine-tuning schedule. The two stages are integrated into a sensing-to-decision system whose classified detections drive a simple, interpretable early-warning module. An evaluation protocol against representative prior detection and classification models, together with ablation studies, was specified to isolate the effect of each contribution.

Future work falls into three directions. First, the forecasting module can be strengthened with explicit temporal models (for example, sequence models that combine incidence trends with greenhouse micro-climate covariates) to move from threshold-based alerts toward calibrated risk prediction. Second, the system can be made lighter through detector–classifier co-distillation and quantisation for fully on-edge operation. Third, robustness can be improved through domain adaptation between public training data and the self-collected greenhouse distribution, and through targeted collection of rare, long-tail pest classes. Completing the empirical evaluation with measured results on the self-collected dataset is the immediate next step.

\newpage
# References

The foundational references below (architectures, attention modules, datasets, and learning methods) are well-established works whose citation details are reliable. The recent domain-specific references on tomato disease detection and plant-disease transformers were retrieved during drafting; the author should verify exact page numbers, volume, and DOI against the publisher of record before final submission.

[1] J. Redmon, S. Divvala, R. Girshick, and A. Farhadi, "You Only Look Once: Unified, Real-Time Object Detection," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 779–788.

[2] J. Redmon and A. Farhadi, "YOLO9000: Better, Faster, Stronger," in *Proc. IEEE CVPR*, 2017, pp. 7263–7271.

[3] J. Redmon and A. Farhadi, "YOLOv3: An Incremental Improvement," *arXiv:1804.02767*, 2018.

[4] A. Bochkovskiy, C.-Y. Wang, and H.-Y. M. Liao, "YOLOv4: Optimal Speed and Accuracy of Object Detection," *arXiv:2004.10934*, 2020.

[5] G. Jocher et al., "Ultralytics YOLOv5," software, 2020. [Online]. Available: https://github.com/ultralytics/yolov5

[6] C.-Y. Wang, A. Bochkovskiy, and H.-Y. M. Liao, "YOLOv7: Trainable Bag-of-Freebies Sets New State-of-the-Art for Real-Time Object Detectors," in *Proc. IEEE/CVF CVPR*, 2023, pp. 7464–7475.

[7] G. Jocher, A. Chaurasia, and J. Qiu, "Ultralytics YOLOv8," software, 2023. [Online]. Available: https://github.com/ultralytics/ultralytics

[8] R. Girshick, J. Donahue, T. Darrell, and J. Malik, "Rich Feature Hierarchies for Accurate Object Detection and Semantic Segmentation," in *Proc. IEEE CVPR*, 2014, pp. 580–587.

[9] R. Girshick, "Fast R-CNN," in *Proc. IEEE Int. Conf. Computer Vision (ICCV)*, 2015, pp. 1440–1448.

[10] S. Ren, K. He, R. Girshick, and J. Sun, "Faster R-CNN: Towards Real-Time Object Detection with Region Proposal Networks," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2015, pp. 91–99.

[11] W. Liu et al., "SSD: Single Shot MultiBox Detector," in *Proc. European Conf. Computer Vision (ECCV)*, 2016, pp. 21–37.

[12] T.-Y. Lin et al., "Feature Pyramid Networks for Object Detection," in *Proc. IEEE CVPR*, 2017, pp. 2117–2125.

[13] T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollár, "Focal Loss for Dense Object Detection," in *Proc. IEEE ICCV*, 2017, pp. 2980–2988.

[14] A. Vaswani et al., "Attention Is All You Need," in *NeurIPS*, 2017, pp. 5998–6008.

[15] A. Dosovitskiy et al., "An Image Is Worth 16×16 Words: Transformers for Image Recognition at Scale," in *Proc. Int. Conf. Learning Representations (ICLR)*, 2021.

[16] H. Touvron, M. Cord, M. Douze, F. Massa, A. Sablayrolles, and H. Jégou, "Training Data-Efficient Image Transformers & Distillation Through Attention," in *Proc. Int. Conf. Machine Learning (ICML)*, vol. 139, 2021, pp. 10347–10357.

[17] G. Hinton, O. Vinyals, and J. Dean, "Distilling the Knowledge in a Neural Network," *arXiv:1503.02531*, 2015.

[18] K. He, X. Zhang, S. Ren, and J. Sun, "Deep Residual Learning for Image Recognition," in *Proc. IEEE CVPR*, 2016, pp. 770–778.

[19] M. Tan and Q. V. Le, "EfficientNet: Rethinking Model Scaling for Convolutional Neural Networks," in *Proc. ICML*, 2019, pp. 6105–6114.

[20] A. Howard et al., "Searching for MobileNetV3," in *Proc. IEEE/CVF ICCV*, 2019, pp. 1314–1324.

[21] S. Woo, J. Park, J.-Y. Lee, and I. S. Kweon, "CBAM: Convolutional Block Attention Module," in *Proc. ECCV*, 2018, pp. 3–19.

[22] Q. Hou, D. Zhou, and J. Feng, "Coordinate Attention for Efficient Mobile Network Design," in *Proc. IEEE/CVF CVPR*, 2021, pp. 13713–13722.

[23] J. Hu, L. Shen, and G. Sun, "Squeeze-and-Excitation Networks," in *Proc. IEEE/CVF CVPR*, 2018, pp. 7132–7141.

[24] Z. Liu et al., "Swin Transformer: Hierarchical Vision Transformer Using Shifted Windows," in *Proc. IEEE/CVF ICCV*, 2021, pp. 10012–10022.

[25] N. Carion et al., "End-to-End Object Detection with Transformers," in *Proc. ECCV*, 2020, pp. 213–229.

[26] D. P. Hughes and M. Salathé, "An Open Access Repository of Images on Plant Health to Enable the Development of Mobile Disease Diagnostics," *arXiv:1511.08060*, 2015.

[27] S. P. Mohanty, D. P. Hughes, and M. Salathé, "Using Deep Learning for Image-Based Plant Disease Detection," *Frontiers in Plant Science*, vol. 7, art. 1419, 2016.

[28] D. Singh, N. Jain, P. Jain, P. Kayal, S. Kumawat, and N. Batra, "PlantDoc: A Dataset for Visual Plant Disease Detection," in *Proc. 7th ACM IKDD CoDS and 25th COMAD*, 2020, pp. 249–253.

[29] X. Wu, C. Zhan, Y.-K. Lai, M.-M. Cheng, and J. Yang, "IP102: A Large-Scale Benchmark Dataset for Insect Pest Recognition," in *Proc. IEEE/CVF CVPR*, 2019, pp. 8787–8796.

[30] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "ImageNet Classification with Deep Convolutional Neural Networks," in *NeurIPS*, 2012, pp. 1097–1105.

[31] J. Deng, W. Dong, R. Socher, L.-J. Li, K. Li, and L. Fei-Fei, "ImageNet: A Large-Scale Hierarchical Image Database," in *Proc. IEEE CVPR*, 2009, pp. 248–255.

[32] K. Simonyan and A. Zisserman, "Very Deep Convolutional Networks for Large-Scale Image Recognition," in *Proc. ICLR*, 2015.

[33] "Optimization of Improved YOLOv8 for Precision Tomato Leaf Disease Detection in Sustainable Agriculture," *Sensors / PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11902794/

[34] Q. Dong, F. Wang, M. Tang et al., "RSA-YOLO: An Improved YOLOv8-Based Model for Tomato Leaf Disease Detection," *Signal, Image and Video Processing*, vol. 20, art. 77, 2026, doi: 10.1007/s11760-026-05125-8.

[35] "Tomato Leaf Disease Detection Method Based on Improved YOLOv8n," *Scientific Reports*, vol. 15, 2025, doi: 10.1038/s41598-025-00405-8.

[36] "A Deep-Learning-Based Model for the Detection of Diseased Tomato Leaves," *Agronomy*, vol. 14, no. 7, art. 1593, 2024, doi: 10.3390/agronomy14071593.

[37] "Plant Leaf Disease Detection Using Vision Transformers for Precision Agriculture," *Scientific Reports*, vol. 15, 2025, doi: 10.1038/s41598-025-05102-0.

[38] "Lightweight Vision Transformer and ResNet-9 Models for Real-Time Plant Disease Detection and Pest Classification with SHAP Explainability," *BMC Plant Biology*, 2026, doi: 10.1186/s12870-026-08667-8.

[39] "Attention Score-Based Multi-Vision Transformer Technique for Plant Disease Classification," *Sensors / PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC11723448/

[40] "Multi-Stage Vision Transformer and Knowledge Graph Fusion for Enhanced Plant Disease Classification," *Computer Systems Science and Engineering*, 2025.

[41] J. Terven and D. Córdova-Esparza, "A Comprehensive Review of YOLO Architectures in Computer Vision: From YOLOv1 to YOLOv8 and Beyond," *Machine Learning and Knowledge Extraction*, vol. 5, no. 4, pp. 1680–1716, 2023.

[42] "A Comprehensive Review on YOLO Versions for Object Detection," *Journal of King Saud University – Computer and Information Sciences / ScienceDirect*, 2025, doi: 10.1016/j.jksuci.2025.

[43] "Tomato Leaf Disease Detection Method Based on Multi-Scale Feature Fusion," *PMC*, 2025. [Online]. Available: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC12567417/

[44] R. R. Selvaraju et al., "Grad-CAM: Visual Explanations from Deep Networks via Gradient-Based Localization," in *Proc. IEEE ICCV*, 2017, pp. 618–626.

[45] S. M. Lundberg and S.-I. Lee, "A Unified Approach to Interpreting Model Predictions," in *NeurIPS*, 2017, pp. 4765–4774.

[46] I. Loshchilov and F. Hutter, "Decoupled Weight Decay Regularization," in *Proc. ICLR*, 2019.

[47] Z. Zheng et al., "Distance-IoU Loss: Faster and Better Learning for Bounding Box Regression," in *Proc. AAAI Conf. Artificial Intelligence*, 2020, pp. 12993–13000.

[48] Z. Ge, S. Liu, F. Wang, Z. Li, and J. Sun, "YOLOX: Exceeding YOLO Series in 2021," *arXiv:2107.08430*, 2021.
