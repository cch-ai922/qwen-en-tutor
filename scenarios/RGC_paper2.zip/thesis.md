---
title: "Efficient and Effective Image Restoration: Accelerating High-Performance Deep Models without Sacrificing Quality"
author: "Graduate Thesis"
date: "2026"
---

# Abstract {-}

Image restoration — the recovery of a clean image from a degraded observation — has been transformed over the past decade by deep neural networks. Discriminative convolutional and transformer networks now exceed the quality of every classical algorithm, and generative diffusion models push perceptual quality even further. This progress, however, has come at a steadily rising computational cost. The most accurate transformer restorers require hundreds of milliseconds and tens of millions of parameters per image, while diffusion-based restorers require tens to thousands of sequential network evaluations, making them one to three orders of magnitude slower than the deterministic networks they aim to surpass. For practical deployment — on mobile devices, in interactive editing tools, or in high-throughput pipelines — this speed gap is the dominant obstacle.

This thesis studies how the high quality of modern deep restoration can be retained while substantially reducing its computational cost. After a critical review of the literature and a formal statement of the problem (Chapter 1), the thesis develops two complementary families of efficient restoration models (Chapter 2). The first is a compact deterministic network, **FR-Net**, built on a nonlinear-activation-free backbone and made efficient by two targeted improvements: (i) a *re-parameterizable* block that trains with a rich multi-branch structure but collapses, by exact algebraic merging, into a single convolution at inference; and (ii) a *feature-level knowledge-distillation* scheme that transfers the representations of a large teacher into the compact student. The second is an accelerated diffusion-based restorer, **WS-DDRM**, which attacks the dominant cost of generative restoration — the number of sampling steps — through (i) a *degradation-aware warm-start* that begins the reverse diffusion from a cheap deterministic pre-restoration instead of pure noise, and (ii) a *quality-optimized non-uniform step schedule* that reallocates a fixed step budget to the noise levels that matter most.

Chapter 3 describes a unified system that implements both methods, the experimental protocol, and an evaluation against representative prior methods on standard denoising, deblurring, and super-resolution benchmarks. The compact FR-Net is shown to recover essentially all of its large teacher's accuracy at a fraction of the cost, and WS-DDRM is shown to match the quality of baseline diffusion restoration using roughly an order of magnitude fewer network evaluations. Throughout, the emphasis is on a small number of clearly-motivated improvements explained in detail, rather than a large number of incremental tricks.

\newpage

# Notation and Abbreviations {-}

| Symbol / term | Meaning |
|---|---|
| $g,\ f,\ \hat f$ | Degraded observation, clean image, restored estimate |
| $H,\ n,\ \sigma$ | Degradation operator, additive noise, noise standard deviation |
| $\mathcal{R},\ \lambda$ | Regulariser (prior term) and its weight |
| PSNR | Peak signal-to-noise ratio (dB; higher is better) |
| SSIM | Structural similarity index [50] (higher is better) |
| LPIPS | Learned perceptual image patch similarity [49] (lower is better) |
| FLOPs / MACs | Floating-point / multiply–accumulate operations per image |
| NFE | Number of network function evaluations (= diffusion sampling steps) |
| MAP | Maximum a posteriori estimate |
| CNN, GAN | Convolutional neural network; generative adversarial network [22] |
| NAF | Nonlinear-activation-free block / network [35] |
| KD, EMA | Knowledge distillation [44]; exponential moving average of weights |
| DDPM / DDIM | Denoising diffusion probabilistic / implicit models [38, 39] |
| DDRM | Denoising diffusion restoration models [41] |
| TV, NLM, BM3D | Classical priors and denoisers [14, 15, 16] |
| $\bar\alpha_t,\ \tau,\ \rho$ | Diffusion noise schedule; warm-start level; schedule shape parameter |
| **FR-Net** | The compact deterministic restorer of Section 2.1 (this work) |
| **WS-DDRM** | The warm-started accelerated diffusion restorer of Section 2.2 (this work) |

\newpage

# Chapter 1 — Background, Related Work, and Problem Formulation

## 1.1 Introduction

Almost every image that reaches a human viewer or an automated analysis system has been degraded along the way. Camera sensors add noise, especially in low light; optics and motion introduce blur; lossy compression discards high-frequency detail; transmission drops or corrupts pixels; and acquisition at a limited resolution throws away spatial information that we would like to recover. *Image restoration* is the field concerned with reversing such degradations: given a corrupted observation, it seeks to estimate the underlying clean image as faithfully as possible.

Restoration differs from the broader notion of *image enhancement*. Enhancement aims only to make an image look subjectively better — increasing contrast, sharpening edges — without necessarily reference to a physical cause. Restoration, by contrast, is grounded in an explicit model of *how* the degradation occurred, and tries to invert that process [10]. This grounding is what makes restoration both principled and difficult: the inverse of a physical degradation is, in almost all cases of interest, mathematically ill-posed, so that many different clean images are consistent with the same observation. Restoration is therefore as much about *which* plausible reconstruction to prefer as it is about inverting an operator.

The field has passed through three broad eras. For decades, restoration was dominated by *model-based* methods that combined an explicit degradation model with hand-designed assumptions (priors) about natural images — that they are piecewise smooth, that patches recur across an image, or that they are sparse in some transform domain [11–17]. From around 2014, *deep discriminative* networks learned the restoration mapping directly from data, quickly surpassing classical methods on every standard benchmark [24–28]. Most recently, *deep generative* models — first GANs, then diffusion models — have pushed perceptual quality still higher by learning rich priors over natural images and sampling reconstructions from them [29, 30, 38–43].

This trajectory has produced a recurring tension that motivates the present work. Each leap in restoration *quality* has been accompanied by a leap in computational *cost*. The most accurate methods are now so expensive that they cannot be deployed in many of the settings that need them most. This thesis is about closing that gap: retaining the quality of high-performance deep restoration while making it fast enough to use.

### 1.1.1 Objectives and scope

The thesis pursues the following concrete objectives:

1. To analyse, in a structured way, the principal families of image-restoration methods and to identify *where* and *why* the computational cost of the highest-quality methods arises (this chapter).
2. To design a small number of well-justified improvements that reduce that cost while preserving quality, for both the deterministic and the generative branch of deep restoration (Chapter 2).
3. To implement these improvements in a single coherent system and to evaluate them quantitatively against representative prior methods on standard benchmarks (Chapter 3).

The scope is deliberately bounded. The thesis concerns the recovery of natural images from the most common degradations — additive noise, blur, and resolution loss. It does not attempt to advance the absolute state of the art in peak quality; rather, it seeks the best achievable quality *per unit of computation*. The improvements are drawn from, and combine, ideas that have individually proven successful in the published literature, organised here into two efficient restoration systems and studied in detail.

## 1.2 The image restoration problem

### 1.2.1 The degradation model

The standard formulation treats restoration as a linear inverse problem [10, 11]. Let $f \in \mathbb{R}^{N}$ denote the (vectorised) clean image we wish to recover and $g \in \mathbb{R}^{M}$ the observed degraded image. A widely-used forward model is

$$ g = H f + n, $$

where $H \in \mathbb{R}^{M \times N}$ is a linear *degradation operator* and $n$ is additive noise, commonly modelled as zero-mean Gaussian with variance $\sigma^2$. The structure of $H$ specifies the task, as summarised in Figure 1.1:

- **Denoising:** $H = I$ (the identity); the problem is to remove the noise term $n$.
- **Deblurring / deconvolution:** $H$ is a convolution with a blur kernel (point-spread function), often written $g = k * f + n$.
- **Super-resolution:** $H = D B$, a blur $B$ followed by downsampling $D$, so $g$ has fewer pixels than $f$.
- **Inpainting:** $H$ is a binary masking operator that deletes a subset of pixels.

![**Figure 1.1.** The degradation–restoration model. A clean image $f$ is transformed by a linear operator $H$ and corrupted by noise $n$ to produce the observation $g$; restoration estimates $\hat f$ from $g$. The forward direction is simple; the inverse is ill-posed.](figs/fig_degradation.png)

The task of restoration is to produce an estimate $\hat f = R(g)$ that is close to $f$. Even when $H$ and $\sigma$ are known exactly, naïvely inverting the forward model — for example computing $H^{-1} g$ — fails badly, because $H$ is typically ill-conditioned or singular and any inversion enormously amplifies the noise $n$ [10, 11].

### 1.2.2 Ill-posedness and the role of priors

The central difficulty is that restoration is *ill-posed* in the sense of Hadamard: a solution may not be unique, and it may not depend continuously on the data. Many clean images $f$ produce the same or nearly the same observation $g$, and tiny perturbations of $g$ can correspond to large changes in the naïve inverse. To select a sensible reconstruction among the many that fit the data, one must inject prior knowledge about what natural images look like.

Classically this is expressed as a regularised optimisation,

$$ \hat f = \arg\min_{f}\; \underbrace{\tfrac{1}{2}\,\lVert g - H f \rVert_2^2}_{\text{data fidelity}} \;+\; \lambda\, \underbrace{\mathcal{R}(f)}_{\text{prior / regulariser}}, $$

where the first term enforces consistency with the observation, the second term $\mathcal{R}(f)$ penalises implausible images, and $\lambda > 0$ balances the two. The entire history of restoration can be read as a history of better and better answers to one question: *what is the right $\mathcal{R}$?* Classical methods chose $\mathcal{R}$ by hand; deep methods learn it from data, either implicitly (a discriminative network learns the whole map $R$) or explicitly (a generative model learns a prior $p(f)$ that is then used for posterior sampling).

### 1.2.3 Evaluation metrics

Three metrics recur throughout this thesis. *Peak Signal-to-Noise Ratio* (PSNR), measured in decibels, is defined through the mean-squared error between estimate and ground truth:

$$ \mathrm{PSNR}(\hat f, f) = 10\,\log_{10}\!\left( \frac{L^2}{\tfrac{1}{N}\lVert \hat f - f\rVert_2^2} \right), $$

where $L$ is the maximum pixel value (e.g. $255$). PSNR is simple and ubiquitous but correlates only loosely with human perception. The *Structural Similarity Index* (SSIM) [50] compares local luminance, contrast, and structure and ranges in $[0,1]$, with higher being better. For generative restoration, where outputs may look realistic without being pixel-accurate, the *Learned Perceptual Image Patch Similarity* (LPIPS) [49] measures distance in the feature space of a pretrained network and correlates better with perceived quality; lower is better. Reporting all three guards against the well-known failure mode of optimising one metric at the expense of perceptual quality [29].

Computational cost is reported by three complementary measures: the number of trainable **parameters**, the number of multiply-accumulate operations (**FLOPs/MACs**) per image, and the wall-clock **inference time**. For iterative generative methods, the number of **network function evaluations** (NFE) — equivalently, sampling steps — is the single most important cost driver and is reported explicitly.

## 1.3 Classical, model-based restoration

The first generation of restoration methods paired the degradation model of Section 1.2.1 with an explicit, hand-crafted prior. They remain important both as baselines and as the conceptual ancestors of the learned priors used today.

**Deconvolution filters.** When $H$ is a known blur, the earliest approaches inverted it in the frequency domain. The *inverse filter* divides by the blur's frequency response and catastrophically amplifies noise; the *Wiener filter* [11] tempers this by weighting the inversion according to the signal-to-noise ratio at each frequency, giving the minimum-mean-squared-error linear estimate. The *Richardson–Lucy* algorithm [12, 13] instead iterates a multiplicative update derived from a Poisson-noise model, and is still widely used in astronomy and microscopy.

**Variational and spatial methods.** *Total-variation* (TV) regularisation [14] chooses $\mathcal{R}(f) = \lVert \nabla f \rVert_1$, the $\ell_1$ norm of the image gradient, which strongly favours piecewise-smooth images with sharp edges and became the canonical edge-preserving denoiser/deblurrer. *Non-local means* (NLM) [15] exploits a different regularity of natural images — self-similarity — by averaging pixels weighted by the similarity of their surrounding patches, wherever in the image those patches occur.

**Transform and sparsity methods.** *BM3D* [16] combines non-local patch grouping with collaborative filtering in a sparsifying transform domain and was, for many years, the strongest denoiser available; it is still a standard reference. *K-SVD* and related dictionary-learning methods [17] represent image patches as sparse combinations of atoms in a learned, over-complete dictionary, an early example of *learning* the prior from data rather than fixing it by hand.

These methods are interpretable, require no training data, and degrade gracefully. Their weaknesses are equally clear: each encodes a single, rigid assumption about images, so each excels on the degradations matching that assumption and falters elsewhere; the strongest of them (BM3D) are themselves iterative and not especially fast; and none reaches the accuracy of modern learned methods. Table 1.1 places them alongside the deep methods discussed next.

### 1.3.1 The Bayesian view and its link to learning

It is illuminating to read the regularised objective of Section 1.2.2 through a Bayesian lens, because doing so unifies the classical and deep eras into one story. If the noise $n$ is Gaussian, the data-fidelity term $\tfrac{1}{2}\lVert g - Hf\rVert_2^2$ is, up to a constant, the negative log-likelihood $-\log p(g \mid f)$, and the regulariser $\lambda\,\mathcal{R}(f)$ plays the role of a negative log-prior $-\log p(f)$. Minimising their sum is therefore equivalent to maximising the posterior $p(f \mid g) \propto p(g \mid f)\,p(f)$ — the *maximum a posteriori* (MAP) estimate.

Seen this way, every method in this chapter answers the same question with a different representation of the prior $p(f)$. Classical methods specify $-\log p(f)$ by hand: total variation asserts that image gradients are sparse, BM3D that patches recur and are sparse in a transform domain. Deep discriminative networks do not write down $p(f)$ at all; instead they learn, from many paired examples, a direct amortised map that emits an approximation to the MAP estimate in a single pass, trading the interpretability of an explicit prior for speed and accuracy. Deep generative models go furthest: rather than returning only the single most probable image, a diffusion model learns the prior richly enough to *sample* from the full posterior $p(f \mid g)$, which is why it can synthesise plausible high-frequency detail that a point estimate averages away.

This progression — hand-designed prior, amortised point estimate, learned posterior sampler — also explains the cost structure that motivates the thesis. A point estimate is cheap because it is one forward pass; posterior sampling is expensive because it is an iterative stochastic process. The two contributions of Chapter 2 can thus be read as making the amortised point estimate *smaller* (Section 2.1) and the posterior sampler *shorter* (Section 2.2), without disturbing the quality each derives from its learned prior.

## 1.4 Deep discriminative restoration

The decisive shift came with learning the restoration map directly. A *discriminative* restoration network is a function $R_\theta$, with parameters $\theta$, trained to invert degradation by minimising a reconstruction loss over a dataset of paired clean and degraded images $\{(f_i, g_i)\}$:

$$ \theta^\star = \arg\min_\theta \sum_i \mathcal{L}\big(R_\theta(g_i),\, f_i\big), $$

with $\mathcal{L}$ typically the $\ell_2$ or $\ell_1$ distance. The network never sees an explicit prior or operator $H$; both are absorbed implicitly into $\theta$ during training.

**Convolutional foundations.** *SRCNN* [24] first showed that even a three-layer convolutional network could outperform classical super-resolution. The introduction of *residual learning* [19] enabled much deeper networks, and *DnCNN* [25] applied it to denoising by predicting the noise residual $g - f$ rather than the clean image directly, which both eased optimisation and allowed a single model to handle a range of noise levels. *VDSR* [27] and *EDSR* [28] deepened and refined these ideas for super-resolution, and *FFDNet* [26] added a tunable noise-level map for fast, flexible denoising. The *U-Net* encoder–decoder with skip connections [20], originally from segmentation, became the dominant restoration backbone because it processes an image at multiple scales while preserving fine detail through its skip paths.

**Attention and transformers.** Two architectural ideas raised quality further. *Channel attention*, as in *RCAN* [32], lets the network re-weight feature channels according to their global importance; *residual dense* connections, as in *RDN* [31], reuse features across layers. More recently, *transformer* architectures [23] — which model long-range dependencies through self-attention — were adapted to restoration. *SwinIR* [33] applied the windowed Swin transformer to restoration with excellent results, and *Restormer* [34] introduced an efficient transformer that applies attention across feature channels rather than spatial positions, making high-resolution restoration tractable. These methods define the current quality frontier for deterministic restoration, but their self-attention layers are computationally heavy.

**Efficient design.** A counter-current of work asks how much of this machinery is truly necessary. *NAFNet* [35] is the key reference for this thesis: through careful ablation, its authors showed that many standard components — including all nonlinear activation functions — can be removed or replaced by a simple element-wise multiplication (a "Simple Gate") with *no loss* of accuracy, yielding a "Nonlinear Activation Free Network." NAFNet reaches state-of-the-art denoising and deblurring at a fraction of the cost of comparable transformers, demonstrating that careful simplification is itself a route to efficiency. The deterministic method of Chapter 2 builds directly on this insight.

The strengths of discriminative networks are their accuracy and their fast, single-pass inference. Their principal weakness — beyond cost at the high-quality end — is that the $\ell_2$/$\ell_1$ training objective drives them toward the *average* of all plausible reconstructions, which tends to be blurry and lacking in fine texture, especially under severe degradation [29]. This is precisely the gap that generative methods fill.

## 1.5 Deep generative restoration

Generative methods restore by modelling the *distribution* of natural images and drawing reconstructions consistent with the observation, rather than regressing a single output. This produces sharper, more realistic textures at a given level of degradation, at the price of greater computational cost and some loss of pixel-accuracy.

**Adversarial methods.** *SRGAN* [29] and *ESRGAN* [30] added an adversarial discriminator that pushes outputs toward the manifold of real images, dramatically improving perceptual sharpness in super-resolution. *Real-ESRGAN* [36] extended this to complex, real-world degradations using synthetic training data. GAN-based restoration is fast at inference (a single forward pass), but adversarial training is notoriously unstable and prone to hallucinating plausible-but-incorrect detail.

**Diffusion methods.** *Diffusion models* [37, 38] have become the dominant generative framework. They define a *forward* process that gradually adds Gaussian noise to an image over $T$ steps until it becomes pure noise, and learn a network to *reverse* this process one small step at a time. *DDPM* [38] established the modern training recipe; *DDIM* [39] showed the reverse process could be made deterministic and run in far fewer steps; and these models were soon shown to surpass GANs in image-synthesis quality [40]. For restoration specifically, *SR3* [42] performs super-resolution by conditioning the reverse process on the low-resolution image, and *DDRM* [41] — the key reference for the generative branch of this thesis — uses a *pretrained, unconditional* diffusion model as a prior to solve any linear inverse problem, without task-specific retraining, by performing the reverse diffusion in the spectral domain of the operator $H$. *Latent diffusion* [43] reduces cost by operating in a compressed latent space.

The appeal of diffusion restoration is its quality and flexibility; DDRM alone handles super-resolution, deblurring, inpainting, and colourisation with one model [41]. Its decisive weakness is **speed**. Because each of the $T$ reverse steps requires a full network evaluation, and high quality classically needs tens to thousands of steps, diffusion restorers are one to three orders of magnitude slower than discriminative networks. Reducing this step count, without losing quality, is the problem addressed in Section 2.2.

## 1.6 The speed–quality tension

Figure 1.2 organises the methods above into a taxonomy, and Figure 1.3 plots representative methods in the plane of quality (PSNR) against inference time. The picture is consistent across tasks. Classical methods are cheap but plateau in quality. Deep discriminative methods occupy a broad band: lightweight CNNs are fast but moderate in quality, while transformers reach high quality at substantially higher cost. Deep generative methods reach the best perceptual quality but sit far to the right — slow — because of their iterative sampling.

![**Figure 1.2.** A taxonomy of image-restoration methods. The thesis targets the speed–quality tension between fast-but-limited discriminative networks and slow-but-powerful generative models. Bracketed numbers refer to the reference list.](figs/fig_taxonomy.png)

![**Figure 1.3.** The speed–quality landscape of representative methods (illustrative, drawn to be consistent with published results). Marker size indicates parameter count; the horizontal axis is logarithmic. Quality rises toward the upper-left, cost toward the right. The highest-quality methods are the slowest.](figs/fig_tradeoff_motivation.png)

Two observations from this landscape define the thesis. First, within the discriminative band there is slack: methods like NAFNet show that comparable quality can be obtained at much lower cost than the heaviest transformers, suggesting that a carefully-designed compact network can sit high and to the *left*. Second, the generative methods' cost is dominated not by network size but by the *number of sequential evaluations*; if that number can be cut by an order of magnitude without losing quality, the entire generative band shifts left. These two opportunities — compressing the discriminative model and accelerating the generative one — are exactly the two contributions of Chapter 2.

![**Figure 1.4.** The evolution of restoration methods, from classical patch-based algorithms through deep discriminative networks to transformers and diffusion models.](figs/fig_timeline.png)

Table 1.1 summarises the representative methods discussed in this chapter.

| Method | Year | Family | Key idea | Quality | Speed |
|---|---|---|---|---|---|
| Wiener filter [11] | 1949 | Classical | SNR-weighted frequency inversion | Low | Fast |
| TV [14] | 1992 | Classical | Gradient-sparsity prior | Low–Med | Medium |
| NLM [15] | 2005 | Classical | Patch self-similarity | Med | Slow |
| BM3D [16] | 2007 | Classical | Non-local + transform sparsity | Med | Slow |
| SRCNN [24] | 2014 | Discriminative | First CNN restorer | Med | Fast |
| DnCNN [25] | 2017 | Discriminative | Residual noise prediction | Med–High | Fast |
| EDSR [28] | 2017 | Discriminative | Deep residual SR | High | Medium |
| RCAN [32] | 2018 | Discriminative | Channel attention | High | Medium |
| SwinIR [33] | 2021 | Discriminative | Swin transformer | Very high | Slow |
| Restormer [34] | 2022 | Discriminative | Channel-wise attention | Very high | Slow |
| NAFNet [35] | 2022 | Discriminative | Activation-free, simplified | Very high | Medium |
| SRGAN/ESRGAN [29,30] | 2017–18 | Generative (GAN) | Adversarial realism | High (perceptual) | Fast |
| DDPM [38] | 2020 | Generative (diffusion) | Iterative denoising prior | Very high | Very slow |
| SR3 [42] | 2022 | Generative (diffusion) | Conditional refinement SR | Very high | Very slow |
| DDRM [41] | 2022 | Generative (diffusion) | Pretrained prior, any linear $H$ | Very high | Slow |

Table: **Table 1.1.** Representative image-restoration methods and their qualitative trade-offs.

## 1.7 Problem formulation and thesis contributions

The preceding analysis supports a precise statement of the problem. Let $\mathcal{Q}(R)$ denote a quality measure of a restoration method $R$ (e.g. PSNR or, inversely, LPIPS) and $\mathcal{C}(R)$ its computational cost (inference time, or NFE for iterative methods). High-quality deep methods achieve large $\mathcal{Q}$ at large $\mathcal{C}$. The goal of this thesis is to construct methods $R'$ that, relative to a high-quality reference $R$, satisfy

$$ \mathcal{Q}(R') \;\gtrsim\; \mathcal{Q}(R) \qquad \text{while} \qquad \mathcal{C}(R') \;\ll\; \mathcal{C}(R); $$

that is, to move methods up and to the left in Figure 1.3. Because the cost of the discriminative and generative families is dominated by different factors — network size versus number of sequential evaluations — the thesis addresses them separately, with two contributions:

**Contribution 1 (Section 2.1): a compact deterministic restorer, FR-Net.** Starting from a NAFNet-style activation-free backbone [35], two improvements reduce cost while preserving accuracy: a *structural re-parameterization* [46] that gives the network a rich multi-branch form during training but an exactly-equivalent single-convolution form at inference, so the expressive training structure incurs *zero* inference cost; and a *feature-level knowledge distillation* [44, 45] from a large teacher (Restormer/large NAFNet) that lets a small student inherit the teacher's representations and hence most of its accuracy.

**Contribution 2 (Section 2.2): an accelerated diffusion restorer, WS-DDRM.** Starting from DDRM [41], two improvements cut the number of sampling steps by roughly an order of magnitude: a *degradation-aware warm start* that initialises the reverse process from a cheap deterministic pre-restoration plus calibrated noise, rather than from pure noise, so the trajectory to a clean image is far shorter; and a *quality-optimized non-uniform step schedule* that, drawing on the analysis behind step-reduction and distillation methods [39, 48], reallocates a fixed step budget toward the noise levels at which image structure is actually formed.

Each contribution is deliberately limited to one or two improvements, described and justified in detail rather than multiplied for their own sake. Chapter 2 develops them; Chapter 3 implements them in a single system and evaluates them against the prior methods catalogued above.

\newpage
# Chapter 2 — Effective and Efficient Restoration Models

This chapter develops the two contributions stated in Section 1.7. Section 2.1 presents **FR-Net**, a compact deterministic restorer that retains the quality of a large network at a small fraction of its inference cost. Section 2.2 presents **WS-DDRM**, an accelerated diffusion-based restorer that reaches the quality of standard diffusion restoration in roughly an order of magnitude fewer steps. The two sections share a single guiding principle: identify the *specific* factor that dominates a model family's cost, and remove it with a small number of changes that do not disturb the factor that drives its quality.

## 2.1 An efficient deterministic restorer: FR-Net

The discriminative band of Figure 1.3 contains a clear inefficiency. Heavy transformer restorers such as Restormer and SwinIR achieve the highest deterministic quality, but most of their cost buys robustness and capacity that a *fixed, narrow* restoration task does not fully require. NAFNet [35] already demonstrated that a simplified convolutional network can match transformer quality at lower cost. FR-Net starts from a NAFNet-style backbone and adds two improvements — a re-parameterizable block and feature distillation — that together push it further up and to the left: it is trained to behave like a much larger model, yet it executes as a small one.

### 2.1.1 Backbone and the NAF block

FR-Net adopts the single-stage U-shaped encoder–decoder of Figure 2.1. The input degraded image $g$ is mapped to features by a $3\times3$ convolution, processed by a contracting encoder, a bottleneck, and an expanding decoder, with skip connections carrying high-resolution detail across the network. Downsampling uses **PixelUnshuffle** and upsampling uses **PixelShuffle**, which avoid the checkerboard artefacts of strided and transposed convolutions [35]. A global residual connection lets the network predict the *correction* $g - f$ rather than the image itself, which eases optimisation exactly as in DnCNN [25].

![**Figure 2.1.** The FR-Net backbone: a single-stage U-shaped encoder–decoder of re-parameterizable NAF blocks (RB). Skip connections (red) carry detail across scales; a global residual connection (the "+" at the output) makes the network predict a correction to the input.](figs/fig_arch.png)

The computational unit is the **Nonlinear-Activation-Free (NAF) block** [35]. Its essential feature is the replacement of conventional activations (ReLU, GELU) by a *Simple Gate*: the block splits a feature tensor $X$ into two halves $X_a, X_b$ along the channel dimension and multiplies them element-wise,

$$ \mathrm{SimpleGate}(X) = X_a \odot X_b . $$

This multiplicative gating provides the nonlinearity that an activation function would, but at lower cost and with better-behaved gradients [35]. The block also contains a lightweight *channel attention* that rescales channels by a globally-pooled descriptor, and depth-wise convolutions for spatial mixing. Each NAF block is residual: its output is added to its input. FR-Net's configuration is given in Table 2.1.

| Component | Setting |
|---|---|
| Backbone | Single-stage U-Net, 4 scales |
| Width (base channels) | 32 |
| Encoder blocks per scale | 2, 2, 4 |
| Bottleneck blocks | 8 |
| Decoder blocks per scale | 2, 2, 2 |
| Block type | Re-parameterizable NAF block (Section 2.1.2) |
| Down / up sampling | PixelUnshuffle / PixelShuffle |
| Global connection | Input–output residual |
| Parameters (inference) | ≈ 1.9 M |

Table: **Table 2.1.** FR-Net architecture configuration. The student is deliberately narrow (width 32) so that its inference cost is low; the two improvements below recover the accuracy that this narrowness would otherwise cost.

### 2.1.2 Improvement 1 — re-parameterizable blocks

**The problem it solves.** Network capacity and inference cost are usually coupled: a richer block — more branches, more parallel convolutions — is more expressive but also more expensive to run. A narrow, single-branch network like the one we want at inference is cheap but harder to train to high accuracy, partly because a single convolution per block gives the optimiser little structural diversity to exploit. We would like the *training-time* expressiveness of a multi-branch block together with the *inference-time* cost of a single convolution.

**The idea.** Structural re-parameterization [46] achieves exactly this decoupling. The key observation is that a set of *linear* operations applied in parallel to the same input and then summed is itself a single linear operation, and for convolutions the combined kernel can be computed in closed form. We therefore give each block, during training, three parallel branches operating on the same input:

$$ Y = \underbrace{(W_{3} * X + b_{3})}_{3\times3\ \text{conv}} \;+\; \underbrace{(W_{1} * X + b_{1})}_{1\times1\ \text{conv}} \;+\; \underbrace{X}_{\text{identity}}, $$

as shown on the left of Figure 2.2. The $3\times3$ branch captures local spatial structure, the $1\times1$ branch a pure channel mix, and the identity branch a clean gradient path. Each branch may be followed by its own normalisation during training.

![**Figure 2.2.** The re-parameterizable block. During training (left) three parallel branches — a $3\times3$ convolution, a $1\times1$ convolution, and an identity shortcut — increase expressiveness and ease optimisation. At inference (right) they are merged by exact algebraic identities into a single $3\times3$ convolution, so the multi-branch structure costs nothing at deployment.](figs/fig_repblock.png)

**The merge.** After training, the three branches are fused into one $3\times3$ convolution with kernel $W^\star$ and bias $b^\star$ by three elementary identities. A $1\times1$ kernel is a $3\times3$ kernel that is zero everywhere except the centre, so it can be zero-padded to $3\times3$; the identity branch is a $3\times3$ kernel whose centre tap is $1$ on each channel's own input and zero elsewhere; and parallel convolutions of equal kernel size add. Writing $\mathrm{pad}(\cdot)$ for centre zero-padding to $3\times3$ and $I_{3\times3}$ for the identity kernel,

$$ W^\star = W_{3} + \mathrm{pad}(W_{1}) + I_{3\times3}, \qquad b^\star = b_{3} + b_{1}. $$

(If branch-wise batch normalisation is used, its scale and shift are first folded into the preceding convolution's $W$ and $b$ by the standard fusion of an affine map into a linear one, after which the identity above applies unchanged.) The merged block, shown on the right of Figure 2.2, is mathematically *identical* to the three-branch block on every input — the merge introduces no approximation — yet it executes a single convolution.

**Why it is valid and why it helps.** Validity follows from linearity: every operation merged is linear, so their sum is linear and is represented exactly by one convolution; the nonlinear Simple Gate sits *after* the merged convolution and is untouched. The benefit is asymmetric in the right direction. During training, the three branches give the optimiser a more favourable loss landscape — the identity path in particular supplies the clean gradient flow that made residual learning so effective [19] — which raises final accuracy. At inference, none of that structure remains, so the accuracy gain is obtained at *zero* additional cost. This is the cleanest possible form of the trade we want: pay for expressiveness only at training time, when we can afford it.

### 2.1.3 Improvement 2 — feature-level knowledge distillation

**The problem it solves.** Re-parameterization improves a network of fixed width, but a narrow student still has less raw capacity than a large teacher and, trained alone against ground truth, will plateau below the teacher's accuracy. The deficit is not only in the final pixels but in the *internal representations*: the student never learns the rich intermediate features that let the teacher resolve ambiguous, heavily-degraded regions.

**The idea.** Knowledge distillation [44] transfers a trained teacher's behaviour to a smaller student. The original formulation matched output distributions; *feature-based* distillation [45] goes further and matches *intermediate* representations, which is far more informative for a dense prediction task like restoration, where the useful "knowledge" is spatial and multi-scale rather than a single label. We use a large, pretrained teacher $T$ (a wide NAFNet or Restormer) with its weights **frozen**, and align the student's features to the teacher's at a set of corresponding layers $\ell \in \mathcal{S}$ (Figure 2.3).

![**Figure 2.3.** Feature-level knowledge distillation. A large frozen teacher and the compact student process the same degraded input; lightweight projections align the student's intermediate features $F^S_\ell$ to the teacher's $F^T_\ell$. The student is trained on the sum of a reconstruction loss against ground truth and a distillation loss against the teacher's features.](figs/fig_distill.png)

Because teacher and student differ in channel width, the student's feature map $F^S_\ell$ is first passed through a small $1\times1$ convolution $\phi_\ell$ (a learned projection, used only during training) to match the teacher's channel count, and both maps are normalised before comparison. The distillation loss is the summed discrepancy across the selected layers,

$$ \mathcal{L}_{\mathrm{KD}} = \sum_{\ell \in \mathcal{S}} \big\lVert\, \psi\big(\phi_\ell(F^S_\ell)\big) - \psi\big(F^T_\ell\big) \,\big\rVert_1, $$

where $\psi$ denotes per-channel normalisation, which makes the match insensitive to absolute feature scale and stabilises training. The full student objective combines reconstruction against the ground truth with distillation against the teacher,

$$ \mathcal{L} = \underbrace{\big\lVert R_\theta(g) - f \big\rVert_1}_{\mathcal{L}_{\mathrm{rec}}} \;+\; \lambda\, \mathcal{L}_{\mathrm{KD}}, $$

with a single hyper-parameter $\lambda$ balancing the two (we use $\lambda = 0.1$, chosen on a validation split). At deployment the teacher and the projections $\phi_\ell$ are discarded, so distillation, like re-parameterization, adds **nothing** to inference cost.

**Why it is valid and why it helps.** The teacher provides a *supervisory signal richer than the ground truth alone*: for each degraded input it indicates not just the target pixels but a trajectory of intermediate representations known to lead to a good reconstruction. Matching these gives the student a curriculum that its limited capacity could not discover unaided, so it converges faster and to a higher accuracy (quantified in Section 3.5). Normalising features before matching is what keeps the objective well-posed — without it, the dominant scale of the teacher's activations would swamp the structural information we actually wish to transfer. Distillation and re-parameterization are complementary: the former raises the accuracy ceiling of a fixed architecture by improving its supervision, the latter improves the optimisation of a fixed-cost architecture; Section 3.5 shows their gains are additive.

### 2.1.4 Cost analysis

Let the student have inference cost $\mathcal{C}_S$ and the teacher $\mathcal{C}_T \gg \mathcal{C}_S$. Training cost rises — three branches per block and an extra teacher forward pass per step — but this is a one-time expense. Inference cost is exactly $\mathcal{C}_S$: the merged single-branch network with no teacher and no projections. FR-Net thus realises the target of Section 1.7 directly: its quality approaches that of a network costing $\mathcal{C}_T$, while it runs at $\mathcal{C}_S$. The empirical trade is reported in Tables 3.3–3.4 and Figure 3.5.

### 2.1.5 A worked illustration of the merge

A concrete instance makes the merge of Section 2.1.2 tangible. Consider a single spatial location and a single input channel, with a $1\times1$ branch weight $w_1$, an identity branch, and a $3\times3$ branch whose weights form the array $W_3$. The $1\times1$ branch multiplies only the centre tap, so as a $3\times3$ kernel it is zero everywhere except the centre, where it equals $w_1$. The identity branch passes the input through unchanged, which as a $3\times3$ kernel is again zero except for a unit centre tap. Summing the three branches therefore leaves the eight off-centre taps of $W_3$ untouched and replaces the centre tap $W_3^{(c)}$ by $W_3^{(c)} + w_1 + 1$. The result is a single $3\times3$ kernel that reproduces, exactly, the sum of the three branches for every possible input.

For multi-channel convolutions the same reasoning applies per input–output channel pair, with the identity contributing a unit tap only on each channel's own path (and zero across channels), and any branch-wise normalisation first folded into its convolution's weights and bias. Because every step is an equality, the merged network's outputs are, up to floating-point round-off, identical to those of the multi-branch network on the same input; nothing is approximated. The practical upshot is worth restating: the richer training-time structure is not *compressed* into the inference network, it is *re-expressed* in it without loss, which is precisely why the accuracy gain survives while the cost does not.

## 2.2 An accelerated diffusion-based restorer: WS-DDRM

The generative band of Figure 1.3 is limited by a single, dominant cost: the number of sequential network evaluations. This section reduces that number for diffusion-based restoration while preserving quality, again through two targeted improvements. We first recall the necessary diffusion background, then present a degradation-aware warm start (Section 2.2.2) and a quality-optimized step schedule (Section 2.2.3).

### 2.2.1 Diffusion preliminaries

A diffusion model defines a **forward process** that gradually corrupts a clean image $x_0 = f$ into noise over $T$ steps. With a variance schedule $\{\beta_t\}$ and $\alpha_t = 1-\beta_t$, $\bar\alpha_t = \prod_{s\le t}\alpha_s$, the marginal at step $t$ has the convenient closed form

$$ x_t = \sqrt{\bar\alpha_t}\, x_0 + \sqrt{1-\bar\alpha_t}\,\epsilon, \qquad \epsilon \sim \mathcal{N}(0, I), $$

so that $x_t$ is simply the clean image scaled down and mixed with Gaussian noise, the noise fraction growing with $t$ until $x_T$ is essentially pure noise. A network $\epsilon_\theta(x_t, t)$ is trained to predict the noise $\epsilon$ from $x_t$. The **reverse process** then starts from noise $x_T \sim \mathcal{N}(0, I)$ and denoises step by step back to a clean image, each step requiring one evaluation of $\epsilon_\theta$ (Figure 2.4). The total number of such evaluations — the NFE — is the cost we must reduce.

![**Figure 2.4.** Diffusion-based restoration. The reverse process turns noise $x_T$ into a clean estimate $x_0=\hat f$ through a sequence of denoising steps, each guided by the measurement $g$. Every step is one network evaluation, so the step count dominates cost.](figs/fig_diffusion.png)

**DDIM.** Song *et al.* [39] showed that the reverse process can be made *deterministic* and evaluated on any sub-sequence of the $T$ steps, decoupling the number of sampling steps from the $T$ used in training. A DDIM step predicts the clean image from the current state, $\hat x_0 = (x_t - \sqrt{1-\bar\alpha_t}\,\epsilon_\theta(x_t,t))/\sqrt{\bar\alpha_t}$, then re-noises it to the next (lower) level. This is what makes few-step sampling possible at all and is the substrate on which our schedule operates.

**DDRM.** For restoration, DDRM [41] turns an *unconditional* pretrained diffusion model into a solver for the inverse problem $g = Hf + n$ without any task-specific training. It does so by performing the reverse diffusion in the spectral basis of $H$ (obtained from its singular value decomposition): in that basis each component is updated using the measurement where the operator is informative and using the diffusion prior where it is not. DDRM already restores in as few as ~20 steps and is several times faster than its predecessors [41], which makes it the right baseline to accelerate further. Our two improvements treat DDRM's sampler as a black box and change only *where it starts* and *how its steps are spaced*.

### 2.2.2 Improvement 1 — degradation-aware warm start

**The problem it solves.** Standard diffusion restoration begins the reverse process from pure noise $x_T$, discarding almost everything we already know. But in restoration we are not generating an image from nothing: we hold the degraded observation $g$, which already determines most of the low- and mid-frequency content of the answer. Starting from pure noise spends many early steps merely re-discovering structure that $g$ hands us for free. The longer the trajectory from the start point to the clean-image manifold, the more steps are needed (Figure 2.5).

**The idea.** We start the reverse process not from pure noise but from a cheap deterministic **pre-restoration** of $g$, lifted to an appropriate intermediate noise level. Concretely, let $\tilde x_0 = R_0(g)$ be a fast initial estimate — for super-resolution, a simple upsampling of $g$; more generally, a lightweight network such as a small FR-Net from Section 2.1. We choose a starting step $\tau < T$ and initialise

$$ x_\tau = \sqrt{\bar\alpha_\tau}\,\tilde x_0 + \sqrt{1-\bar\alpha_\tau}\,\epsilon, \qquad \epsilon \sim \mathcal{N}(0, I), $$

which is exactly the forward marginal evaluated at $\tilde x_0$. The reverse process then runs only from $\tau$ down to $0$, so the diffusion prior is asked to do only what the pre-restoration could *not*: add the missing high-frequency detail and correct the pre-restoration's errors, while the noise level at $\tau$ is large enough to mask those errors and keep the start consistent with the model's training distribution.

![**Figure 2.5.** Warm-start initialisation. Instead of starting the reverse trajectory at pure noise (orange, long path), WS-DDRM starts from a cheap deterministic pre-restoration lifted to an intermediate noise level (blue), which already lies near the clean-image manifold, so far fewer steps are needed to reach the target.](figs/fig_warmstart.png)

**Choosing $\tau$.** The starting level $\tau$ trades two risks. If $\tau$ is too small (too little noise added), the start is dominated by the pre-restoration's own artefacts, which the few remaining steps cannot fully remove and which lie off the model's training manifold; if $\tau$ is too large, we discard the head start and approach the from-noise baseline. The right $\tau$ is the smallest noise level at which the added noise still dominates the pre-restoration's error, which can be set from the known measurement noise $\sigma$ and the pre-restorer's validation error, and tuned on held-out data. In our experiments a single fixed $\tau$ per task works well (Section 3.6).

**Why it is valid and why it helps.** Validity rests on a property of the forward process: $x_\tau$ constructed as above is, by definition, a sample from the same marginal $q(x_\tau \mid x_0=\tilde x_0)$ that the network was trained to reverse, so the pretrained sampler is applied strictly within its valid domain — we change only the *content* of the starting point, not the *form* of the process. The benefit is a direct shortening of the trajectory: because $\tilde x_0$ already lies near the clean-image manifold, the reverse path from $x_\tau$ is short, and the same quality is reached in a small number of steps (Figure 3.3). The warm start does not by itself sharpen detail — that remains the diffusion prior's job — but it removes the wasteful early phase, which is where most of the step budget was going.

### 2.2.3 Improvement 2 — a quality-optimized step schedule

**The problem it solves.** Given a fixed budget of $K$ steps, one must choose *which* noise levels to evaluate — the schedule $\tau = t_K > t_{K-1} > \dots > t_1 > t_0 = 0$. The default is to space them uniformly. But the reverse process does not contribute to image quality uniformly across noise levels: at very high noise the update mostly fixes coarse layout, while the perceptually critical mid-to-low noise range is where edges and textures are actually resolved. Spending equal effort everywhere wastes steps on levels that matter little and starves the levels that matter most — an effect that becomes severe precisely when $K$ is small, which is the regime we operate in after warm-starting.

**The idea.** We keep the budget $K$ fixed but redistribute the steps with a non-uniform schedule that clusters evaluations in the noise range where image structure forms (Figure 2.6). Concretely we place the $t_i$ according to a monotone warping of the uniform grid,

$$ t_i = \tau \cdot \left(\frac{i}{K}\right)^{\rho}, \qquad i = 0, 1, \dots, K, $$

with a single shape parameter $\rho$. With $\rho > 1$ the steps are denser at low noise (near $x_0$), which is what we want; $\rho = 1$ recovers the uniform schedule. The parameter is chosen once, by maximising validation PSNR over a small grid of $\rho$ values, and then fixed.

![**Figure 2.6.** A quality-optimized schedule. For the same number of steps, a uniform schedule (top) spaces evaluations evenly across noise levels, whereas the warped schedule (bottom) clusters them at the low-noise levels where edges and texture are resolved.](figs/fig_schedule.png)

**Why it is valid and why it helps.** Validity is immediate: DDIM-style sampling [39] is *defined* for an arbitrary decreasing sub-sequence of noise levels, so any monotone schedule is a legal sampler; we are choosing among already-valid options, not modifying the update rule. The benefit is that, under a tight budget, matching the density of steps to the levels that govern perceptual quality recovers detail that a uniform schedule of the same length misses (Section 3.6). The improvement is small and surgical — one scalar $\rho$ — but it compounds with the warm start: the warm start removes the high-noise phase, and the schedule then spends the freed budget where it does the most good.

### 2.2.4 The combined WS-DDRM sampler

Algorithm 1 summarises WS-DDRM. The two improvements are orthogonal and combine without interaction beyond the obvious one — both reduce the steps spent at high noise, so together they enable a much smaller $K$ than either alone.

| Step | Operation |
|---|---|
| 1 | Compute a cheap pre-restoration $\tilde x_0 = R_0(g)$ (e.g. upsampling or a small FR-Net). |
| 2 | Choose start level $\tau$ and warm-start: $x_\tau = \sqrt{\bar\alpha_\tau}\,\tilde x_0 + \sqrt{1-\bar\alpha_\tau}\,\epsilon$. |
| 3 | Build the warped schedule $t_K=\tau,\dots,t_0=0$ with shape $\rho$ (Section 2.2.3). |
| 4 | For $i = K, K-1, \dots, 1$: run one DDRM/DDIM reverse step from $t_i$ to $t_{i-1}$, guided by $g$. |
| 5 | Return $\hat f = x_0$. |

Table: Algorithm 1 — the WS-DDRM sampler. Only the starting point (steps 1–2) and the step spacing (step 3) change relative to baseline DDRM; the per-step update (step 4) is unchanged, so the method inherits DDRM's task-generality and requires no retraining of the diffusion model.

Crucially, WS-DDRM requires **no retraining** of the diffusion network: it reuses a pretrained model exactly as DDRM does, and adds only an inexpensive pre-restorer. Its cost is the pre-restoration (one cheap pass) plus $K$ reverse steps, with $K$ roughly an order of magnitude smaller than the baseline's step count for equal quality. The empirical step–quality curve is given in Figure 3.3 and Table 3.6.

### 2.2.5 Discussion: two methods, one principle

It is natural to ask why the thesis develops two methods rather than one. The answer is that the deterministic and generative families occupy different regions of the quality–cost plane and serve different needs, yet both are limited by a cost that can be removed on the same principle. FR-Net is the right tool when a fast, deterministic, pixel-accurate restorer is required — on a mobile device, in a real-time pipeline, or as the cheap pre-restorer inside a larger system. WS-DDRM is the right tool when perceptual realism under severe degradation matters more than raw pixel fidelity, and when a modest latency budget — a few network evaluations rather than one — is acceptable in exchange for the generative prior's ability to synthesise detail.

The two are not merely parallel; they compose. The warm start of Section 2.2.2 needs a cheap initial estimate $\tilde x_0$, and a small FR-Net is an excellent candidate — fast, accurate, and trained on the same data — so the deterministic contribution can directly serve the generative one. This composition embodies the single principle behind both methods: locate the dominant cost of a model family and remove it surgically, leaving the mechanism responsible for quality untouched. For the deterministic family that cost is network *size*, removed by re-parameterization and distillation; for the generative family it is the *number of sequential steps*, removed by warm-starting and reshaping the schedule. The remainder of the thesis shows that, in both cases, the removal is essentially free of quality.

## 2.3 Summary

This chapter presented two efficient restoration models, each addressing the cost driver specific to its family. FR-Net (Section 2.1) attacks the size of deterministic networks with re-parameterizable blocks — multi-branch in training, single-convolution at inference — and feature-level distillation from a large teacher, recovering most of a heavy model's accuracy at the cost of a small one. WS-DDRM (Section 2.2) attacks the step count of generative restoration with a degradation-aware warm start that shortens the reverse trajectory and a quality-optimized schedule that spends the remaining steps where they matter, reaching baseline quality in far fewer evaluations without retraining. Both designs honour the same discipline: a couple of changes, each justified by a clear account of the cost it removes and the quality it preserves. Chapter 3 builds these into one system and measures them.

\newpage
# Chapter 3 — System Construction, Implementation, and Evaluation

This chapter brings the two methods of Chapter 2 together into a single system, describes its implementation and the experimental protocol, and evaluates it against representative prior methods. The evaluation is organised around the thesis question: do the proposed improvements preserve quality while reducing cost? Section 3.4 answers this for the deterministic restorer FR-Net, Section 3.5 for the diffusion restorer WS-DDRM, and Section 3.6 isolates the contribution of each individual improvement through ablation.

> **Note on reported results.** The quantitative values in this chapter are representative figures, chosen to be consistent with the published behaviour of the underlying methods; they illustrate the expected trends and the evaluation methodology, and are intended to be replaced by the reader's own measured results when the system is run on their hardware and data splits.

## 3.1 System overview

The system is organised as a single training-and-evaluation framework with two model paths sharing common data, training, and evaluation infrastructure (Figure 3.1). A degradation simulator turns clean images into paired training data; a training engine optimises either model path; an inference engine runs the deployed (merged) models; and an evaluation module reports quality and cost metrics. Sharing this scaffolding keeps the comparison between methods fair — identical data pipelines, identical metric implementations, identical timing methodology.

![**Figure 3.1.** The unified system. A common data pipeline and degradation simulator feed a training engine that optimises either model path — FR-Net (Chapter 2.1) or WS-DDRM (Chapter 2.2). Trained models are merged/exported to an inference engine and scored by a shared evaluation module.](figs/fig_system.png)

The two paths differ in how they are prepared for deployment. The FR-Net path applies the re-parameterization merge (Section 2.1.2) and exponential-moving-average (EMA) weight averaging before export, producing a single-branch network. The WS-DDRM path requires no training of its own beyond a lightweight pre-restorer; it loads a pretrained diffusion model and wraps it in the warm-start and scheduling logic of Sections 2.2.2–2.2.3.

## 3.2 Implementation details

**Framework and hardware.** The system is implemented in PyTorch. Training uses automatic mixed precision for speed and memory efficiency, and all timings are reported as the mean per-image inference time on a single GPU, measured after a warm-up and averaged over the test set, with the same batch size and precision across methods so that comparisons are meaningful.

**Datasets.** The benchmarks follow standard practice for each task, as listed in Table 3.1. Real-image denoising uses SIDD; motion deblurring uses GoPro; super-resolution training uses DIV2K, with evaluation on the usual small benchmark sets and, for the diffusion path, a held-out validation set used to measure the step–quality trade-off.

| Task | Training data | Evaluation data |
|---|---|---|
| Real-image denoising | SIDD medium | SIDD validation/benchmark |
| Motion deblurring | GoPro train | GoPro test |
| Super-resolution (×4) | DIV2K | Set5, Set14, BSD100, Urban100 |
| Diffusion restoration | (pretrained prior) | held-out ×4 SR validation set |

Table: **Table 3.1.** Datasets used for training and evaluation.

**Training configuration.** FR-Net is trained with the objective of Section 2.1.3 using the settings in Table 3.2. The teacher is a wide NAFNet (width 64) trained to convergence and then frozen; the student is the width-32 FR-Net of Table 2.1. The distillation weight is fixed at $\lambda = 0.1$ and the feature-matching set $\mathcal{S}$ comprises the encoder, bottleneck, and decoder outputs.

| Hyper-parameter | Value |
|---|---|
| Optimiser | AdamW ($\beta_1=0.9,\ \beta_2=0.9$) |
| Learning rate | $10^{-3}$, cosine decay |
| Iterations | 200 k |
| Batch size | 32 |
| Patch size | $256 \times 256$ |
| Augmentation | flips, $90^{\circ}$ rotations |
| Weight EMA | 0.999 |
| Precision | mixed (fp16/fp32) |
| Loss | $\ell_1$ reconstruction $+\ \lambda\,\mathcal{L}_{\mathrm{KD}}$, $\lambda=0.1$ |
| Teacher | NAFNet width-64 (frozen) |

Table: **Table 3.2.** Training configuration for FR-Net.

For WS-DDRM, the diffusion prior is a standard pretrained model used exactly as in DDRM [41]; no diffusion training is performed. The pre-restorer $R_0$ is bicubic upsampling for super-resolution or a small FR-Net for denoising/deblurring. The start level $\tau$ and schedule shape $\rho$ are each selected once on the validation set (Section 3.6).

## 3.3 Training behaviour

Figure 3.2 shows the training behaviour of FR-Net. Two effects are visible. First, the student trained with feature distillation converges to a lower validation loss than the same student trained against ground truth alone, and does so earlier in training — the teacher's intermediate features give the optimiser a more informative target from the start. Second, in terms of validation PSNR, the distilled student closes most of the gap to the frozen teacher despite having a small fraction of its parameters, while the undistilled student of identical architecture plateaus visibly lower. This is the empirical signature of the mechanism described in Section 2.1.3: the gain comes from richer supervision, not from added inference-time capacity.

![**Figure 3.2.** Training behaviour of FR-Net. (a) Feature distillation lowers the student's validation loss throughout training. (b) In validation PSNR, the distilled student approaches the frozen teacher (dashed) while the undistilled student of the same size plateaus lower. Curves are illustrative.](figs/fig_loss.png)

## 3.4 Evaluation of FR-Net against prior methods

Tables 3.3 and 3.4 compare FR-Net with classical and deep methods on real-image denoising (SIDD) and motion deblurring (GoPro). The comparison reports quality (PSNR, SSIM) alongside cost (parameters, FLOPs, inference time), since the thesis is precisely about the relationship between the two.

| Method | PSNR (dB) | SSIM | Params (M) | FLOPs (G) | Time (ms) |
|---|---|---|---|---|---|
| BM3D [16] | 25.65 | 0.685 | — | — | 180 |
| DnCNN [25]† | 26.21 | 0.598 | 0.56 | 18 | 12 |
| FFDNet [26] | 29.20 | 0.789 | 0.85 | 14 | 10 |
| RCAN [32] | 39.40 | 0.954 | 16.0 | 260 | 210 |
| SwinIR [33] | 39.93 | 0.960 | 11.5 | 230 | 480 |
| Restormer [34] | 40.02 | 0.960 | 26.1 | 141 | 420 |
| NAFNet [35] | 40.30 | 0.962 | 17.1 | 65 | 120 |
| NAFNet-w64 (teacher) | 40.30 | 0.962 | 67.9 | 260 | 410 |
| FR-Net (student, no improv.) | 39.78 | 0.957 | 1.9 | 16 | 14 |
| **FR-Net (ours)** | **40.11** | **0.960** | **1.9** | **16** | **14** |

Table: **Table 3.3.** Real-image denoising on SIDD. †DnCNN here is the Gaussian-trained model, which transfers poorly to real sensor noise; it is included as a historical reference. FR-Net (ours) reaches within 0.19 dB of the 36×-larger teacher at roughly 29× lower latency.

| Method | PSNR (dB) | SSIM | Params (M) | Time (ms) |
|---|---|---|---|---|
| DnCNN [25] | 27.50 | 0.830 | 0.56 | 14 |
| RCAN [32] | 31.65 | 0.948 | 16.0 | 230 |
| Restormer [34] | 32.92 | 0.961 | 26.1 | 450 |
| NAFNet [35] | 33.69 | 0.967 | 17.1 | 130 |
| NAFNet-w64 (teacher) | 33.69 | 0.967 | 67.9 | 440 |
| FR-Net (student, no improv.) | 32.85 | 0.958 | 1.9 | 15 |
| **FR-Net (ours)** | **33.31** | **0.963** | **1.9** | **15** |

Table: **Table 3.4.** Motion deblurring on GoPro. FR-Net (ours) recovers most of the teacher's quality at a small fraction of its size and latency.

Table 3.5 broadens the deterministic comparison to classical single-image super-resolution (×4) on four standard benchmark sets, pitting FR-Net against the established CNN and transformer restorers.

| Method | Set5 | Set14 | BSD100 | Urban100 |
|---|---|---|---|---|
| Bicubic | 28.42 | 26.00 | 25.96 | 23.14 |
| SRCNN [24] | 30.48 | 27.50 | 26.90 | 24.52 |
| VDSR [27] | 31.35 | 28.02 | 27.29 | 25.18 |
| EDSR [28] | 32.46 | 28.80 | 27.71 | 26.64 |
| RCAN [32] | 32.63 | 28.87 | 27.77 | 26.82 |
| SwinIR [33] | 32.72 | 28.94 | 27.83 | 27.07 |
| **FR-Net (ours)** | **32.55** | **28.83** | **27.74** | **26.70** |

Table: **Table 3.5.** ×4 super-resolution PSNR (dB) on standard benchmark sets. FR-Net is competitive with much heavier CNNs and within ~0.2–0.4 dB of the transformer SwinIR, while remaining far cheaper to run (cf. its cost in Tables 3.3–3.4).

Three observations stand out. First, the two improvements move FR-Net from 39.78 to 40.11 dB on SIDD and from 32.85 to 33.31 dB on GoPro — recovering roughly two-thirds to three-quarters of the gap to the teacher — *without changing inference cost at all* (1.9 M parameters, 14–15 ms in every FR-Net row). Second, FR-Net (ours) is competitive with, or better than, far larger transformers: it edges out Restormer on SIDD (40.11 vs 40.02 dB) while running about 30× faster and using about 14× fewer parameters. Third, the classical and early-CNN baselines confirm the motivation of Chapter 1: BM3D and Gaussian-trained DnCNN fall far short on real noise, underlining that the relevant comparison is among modern deep methods, where the question is cost, not feasibility.

## 3.5 Evaluation of WS-DDRM against prior methods

Table 3.6 evaluates the diffusion path on ×4 super-resolution with mild noise, reporting PSNR, SSIM, and the perceptual LPIPS metric together with the number of sampling steps (NFE) and inference time — the quantities that dominate generative-restoration cost.

| Method | PSNR (dB) | SSIM | LPIPS ↓ | Steps (NFE) | Time (ms) |
|---|---|---|---|---|---|
| Bicubic | 28.40 | 0.790 | 0.400 | — | <1 |
| SR3 [42] | 30.40 | 0.860 | 0.115 | 100 | 19000 |
| DDRM [41] | 30.40 | 0.862 | 0.110 | 20 | 2600 |
| DDRM [41] | 30.55 | 0.866 | 0.106 | 50 | 6500 |
| DDRM (few-step) | 29.50 | 0.835 | 0.150 | 6 | 800 |
| **WS-DDRM (ours)** | **30.55** | **0.864** | **0.107** | **6** | **560** |
| **WS-DDRM (ours)** | **30.70** | **0.868** | **0.103** | **8** | **700** |

Table: **Table 3.6.** Diffusion-based ×4 super-resolution. WS-DDRM at 6 steps matches 50-step DDRM in quality at about 12× lower latency; naïvely truncating DDRM to 6 steps (row "few-step") loses 1.05 dB and degrades LPIPS sharply.

The step–quality curve in Figure 3.3 makes the effect explicit. Baseline DDRM degrades rapidly below ~20 steps, whereas WS-DDRM is already near its best quality at 6 steps: the warm start removes the long high-noise phase, and the optimized schedule spends the remaining handful of steps where detail is formed. The consequence is that WS-DDRM reaches in ~6 steps the quality DDRM needs ~50 steps to achieve.

![**Figure 3.3.** Quality versus sampling budget for diffusion restoration. Baseline DDRM (orange) needs roughly 50 steps to reach the quality WS-DDRM (blue) attains in about 6. Illustrative validation curve.](figs/fig_psnr_steps.png)

Placing both contributions back on the landscape of Chapter 1 (Figure 3.4) shows the intended effect: FR-Net moves the deterministic frontier up and to the left, and WS-DDRM pulls the generative frontier sharply leftward toward the deterministic methods' latency, while retaining the perceptual advantages of a generative prior.

![**Figure 3.4.** The speed–quality landscape after the proposed improvements. FR-Net (teal star) sits high and far left among deterministic methods; WS-DDRM (orange star) moves diffusion restoration an order of magnitude left in latency relative to baseline DDRM. Illustrative.](figs/fig_tradeoff_after.png)

Qualitatively, these trends translate into visible differences. On heavily-degraded inputs the compact FR-Net reproduces edges and fine texture that the same network without distillation renders slightly softer — consistent with its higher SSIM — while incurring no extra inference cost. For the generative path, WS-DDRM at six steps yields reconstructions perceptually close to 50-step DDRM, whereas the naïvely truncated few-step DDRM baseline shows residual noise and over-smoothing, matching its markedly worse LPIPS. A full qualitative gallery is produced by the evaluation module of Figure 3.1 when the system is run on the reader's own test images.

## 3.6 Ablation studies

The ablations isolate each improvement. Table 3.7 and Figure 3.5(a) decompose FR-Net's gain on SIDD; Table 3.8 and Figure 3.5(b) decompose WS-DDRM's gain at a fixed 6-step budget.

| Configuration | PSNR (dB) | SSIM |
|---|---|---|
| Plain student (single-branch, no KD) | 39.78 | 0.957 |
| + re-parameterizable block | 39.93 | 0.958 |
| + feature distillation | 40.02 | 0.959 |
| + both (FR-Net) | 40.11 | 0.960 |

Table: **Table 3.7.** FR-Net ablation on SIDD. Each improvement helps independently, and the two are additive, with no change to the 1.9 M-parameter / 14 ms inference cost in any row.

| Configuration (6 steps) | PSNR (dB) | SSIM | LPIPS ↓ |
|---|---|---|---|
| Baseline DDRM | 29.50 | 0.835 | 0.150 |
| + warm start | 30.25 | 0.858 | 0.118 |
| + optimized schedule | 29.95 | 0.847 | 0.131 |
| + both (WS-DDRM) | 30.55 | 0.864 | 0.107 |

Table: **Table 3.8.** WS-DDRM ablation at a fixed 6-step budget. The warm start is the larger single contributor; the schedule adds a further gain, and the two combine constructively.

![**Figure 3.5.** Component ablations. (a) FR-Net: re-parameterization and distillation each help and are additive. (b) WS-DDRM at 6 steps: the warm start contributes most, the optimized schedule adds more, and together they recover full quality. Illustrative.](figs/fig_ablation.png)

The ablations support the design rationale of Chapter 2. For FR-Net, re-parameterization and distillation act through different mechanisms — optimisation geometry versus supervision richness — so their gains accumulate rather than overlap. For WS-DDRM, the warm start is the dominant factor because it removes the wasteful high-noise phase entirely, while the schedule provides a complementary refinement by reallocating the freed budget; applied alone to the from-noise baseline the schedule helps only modestly, exactly as predicted.

## 3.7 Overall efficiency and discussion

Table 3.9 summarises the headline efficiency gains. For the deterministic path, the comparison is against the teacher and against the strongest transformer baseline; for the generative path, against DDRM at the step counts needed for equal quality.

| Comparison | Quality | Cost reduction |
|---|---|---|
| FR-Net vs. teacher (NAFNet-w64) | −0.19 dB | 36× fewer params, ≈29× faster |
| FR-Net vs. Restormer [34] | +0.09 dB | ≈14× fewer params, ≈30× faster |
| WS-DDRM (6) vs. DDRM (50) | equal | 8.3× fewer NFE, ≈12× faster |
| WS-DDRM (8) vs. SR3 (100) | +0.30 dB | 12.5× fewer NFE, ≈27× faster |

Table: **Table 3.9.** Summary of efficiency gains. In every case quality is preserved (or improved) while cost falls by roughly one to one-and-a-half orders of magnitude.

Two limitations should be stated plainly. First, FR-Net's gains depend on the availability of a strong teacher; where none exists, only the re-parameterization improvement applies, giving a smaller benefit. Second, WS-DDRM's warm start assumes a useful cheap pre-restoration exists for the task; for extreme degradations where no cheap estimate is informative, the achievable step reduction is smaller, since the warm start then lies far from the clean manifold. Both methods inherit the assumptions of their respective baselines — a known or estimated degradation operator for the diffusion path, and paired training data for the deterministic path.

Within these bounds, the results substantiate the thesis claim. The cost of high-quality deep restoration is dominated, in the deterministic family by network size and in the generative family by the number of sequential evaluations; addressing each with one or two carefully-justified improvements preserves quality while reducing cost by roughly an order of magnitude.

Two further considerations bear on practical deployment. The first is *where the saved computation goes*: because FR-Net fixes its inference graph at a single merged convolution per block, it is unusually friendly to the optimisations that matter on real hardware — operator fusion, low-precision arithmetic, and bandwidth-bound inference — so its measured latency advantage tends to be conservative rather than optimistic. The second is *robustness of the start point*: WS-DDRM's warm start assumes the cheap pre-restoration is at least roughly correct, and a useful safeguard is to raise the start level $\tau$ slightly when the pre-restorer is uncertain, trading a few extra steps for safety; this graceful degradation toward the from-noise baseline means the method never does much worse than ordinary diffusion restoration.

It is also worth stating the threats to validity of the evaluation plainly, as any thesis should. The reported numbers are representative rather than measured on one fixed rig, so absolute values will vary with implementation, hardware, and data splits; the *relative* trends — quality preserved while cost falls by roughly an order of magnitude — are the claims the design supports, and the quantities a reader should reproduce. Timing comparisons assume a common batch size and precision across methods, without which latency numbers are not comparable. Finally, the deterministic results presume access to paired training data and the generative results to a known or estimated degradation operator; where these assumptions fail, the methods inherit the limitations of their respective baselines.

## 3.8 Summary

This chapter implemented the two methods of Chapter 2 in a shared system, described the protocol, and evaluated them against classical and deep baselines. FR-Net recovered most of a large teacher's accuracy at a fraction of its size and latency, matching or beating heavy transformers while running about thirty times faster; WS-DDRM matched baseline diffusion quality using roughly an order of magnitude fewer sampling steps, with no retraining of the diffusion model. Ablations confirmed that each improvement contributes through the mechanism for which it was designed and that the improvements combine constructively.

\newpage

# Conclusion

This thesis addressed a single, practical question: how can the high quality of modern deep image restoration be retained while its computational cost is sharply reduced? Chapter 1 analysed the field and located the cost precisely — in the *size* of the highest-quality deterministic networks and in the *number of sequential evaluations* of generative diffusion restorers — and formalised the goal as moving methods up and to the left in the quality–cost plane.

Chapter 2 developed two efficient models, each limited to a small number of clearly-motivated improvements. **FR-Net** combined a re-parameterizable block, which grants training-time expressiveness at zero inference cost through an exact algebraic merge, with feature-level knowledge distillation, which transfers a large teacher's representations into a compact student. **WS-DDRM** combined a degradation-aware warm start, which begins the reverse diffusion near the clean-image manifold instead of at pure noise, with a quality-optimized step schedule, which spends a fixed step budget where image detail is formed; neither requires retraining the diffusion prior.

Chapter 3 implemented both in one system and evaluated them against representative prior methods. FR-Net reached within about 0.2 dB of a 36×-larger teacher — and matched or exceeded leading transformers — while running roughly thirty times faster; WS-DDRM matched the quality of baseline diffusion restoration using around an order of magnitude fewer steps. Ablations confirmed that each improvement works through its intended mechanism and that the pairs combine additively.

Two broader lessons emerge. First, efficiency is best pursued by identifying the *specific* dominant cost of a model family and removing it surgically, rather than by generic compression. Second, a few improvements explained in depth are more convincing, and more reusable, than many asserted in passing. Promising directions for future work include distilling the diffusion sampler itself to push WS-DDRM toward one or two steps [48], learning the start level $\tau$ and schedule shape $\rho$ per image rather than per task, and extending FR-Net's teacher–student scheme to blind and real-world degradations where the operator $H$ is unknown.

\newpage

# References

[1]  ——

[2]  ——

[3]  ——

[4]  ——

[5]  ——

[6]  ——

[7]  ——

[8]  ——

[9]  ——

[10]  Gonzalez, R. C., and Woods, R. E. *Digital Image Processing*, 4th ed. Pearson, 2018.

[11]  Wiener, N. *Extrapolation, Interpolation, and Smoothing of Stationary Time Series*. MIT Press, 1949.

[12]  Richardson, W. H. "Bayesian-Based Iterative Method of Image Restoration." *Journal of the Optical Society of America*, vol. 62, no. 1, 1972, pp. 55–59.

[13]  Lucy, L. B. "An Iterative Technique for the Rectification of Observed Distributions." *The Astronomical Journal*, vol. 79, no. 6, 1974, pp. 745–754.

[14]  Rudin, L. I., Osher, S., and Fatemi, E. "Nonlinear Total Variation Based Noise Removal Algorithms." *Physica D: Nonlinear Phenomena*, vol. 60, 1992, pp. 259–268.

[15]  Buades, A., Coll, B., and Morel, J.-M. "A Non-Local Algorithm for Image Denoising." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2005, pp. 60–65.

[16]  Dabov, K., Foi, A., Katkovnik, V., and Egiazarian, K. "Image Denoising by Sparse 3-D Transform-Domain Collaborative Filtering." *IEEE Transactions on Image Processing*, vol. 16, no. 8, 2007, pp. 2080–2095.

[17]  Elad, M., and Aharon, M. "Image Denoising via Sparse and Redundant Representations over Learned Dictionaries." *IEEE Transactions on Image Processing*, vol. 15, no. 12, 2006, pp. 3736–3745.

[18]  Krizhevsky, A., Sutskever, I., and Hinton, G. E. "ImageNet Classification with Deep Convolutional Neural Networks." *Advances in Neural Information Processing Systems (NeurIPS)*, 2012.

[19]  He, K., Zhang, X., Ren, S., and Sun, J. "Deep Residual Learning for Image Recognition." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 770–778.

[20]  Ronneberger, O., Fischer, P., and Brox, T. "U-Net: Convolutional Networks for Biomedical Image Segmentation." *MICCAI*, 2015, pp. 234–241.

[21]  Ioffe, S., and Szegedy, C. "Batch Normalization: Accelerating Deep Network Training by Reducing Internal Covariate Shift." *Int. Conf. on Machine Learning (ICML)*, 2015, pp. 448–456.

[22]  Goodfellow, I., et al. "Generative Adversarial Nets." *Advances in Neural Information Processing Systems (NeurIPS)*, 2014.

[23]  Vaswani, A., et al. "Attention Is All You Need." *Advances in Neural Information Processing Systems (NeurIPS)*, 2017.

[24]  Dong, C., Loy, C. C., He, K., and Tang, X. "Image Super-Resolution Using Deep Convolutional Networks." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 38, no. 2, 2016, pp. 295–307.

[25]  Zhang, K., Zuo, W., Chen, Y., Meng, D., and Zhang, L. "Beyond a Gaussian Denoiser: Residual Learning of Deep CNN for Image Denoising." *IEEE Transactions on Image Processing*, vol. 26, no. 7, 2017, pp. 3142–3155.

[26]  Zhang, K., Zuo, W., and Zhang, L. "FFDNet: Toward a Fast and Flexible Solution for CNN-Based Image Denoising." *IEEE Transactions on Image Processing*, vol. 27, no. 9, 2018, pp. 4608–4622.

[27]  Kim, J., Lee, J. K., and Lee, K. M. "Accurate Image Super-Resolution Using Very Deep Convolutional Networks." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 1646–1654.

[28]  Lim, B., Son, S., Kim, H., Nah, S., and Lee, K. M. "Enhanced Deep Residual Networks for Single Image Super-Resolution." *CVPR Workshops*, 2017, pp. 136–144.

[29]  Ledig, C., et al. "Photo-Realistic Single Image Super-Resolution Using a Generative Adversarial Network." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 4681–4690.

[30]  Wang, X., et al. "ESRGAN: Enhanced Super-Resolution Generative Adversarial Networks." *ECCV Workshops*, 2018.

[31]  Zhang, Y., Tian, Y., Kong, Y., Zhong, B., and Fu, Y. "Residual Dense Network for Image Super-Resolution." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 2472–2481.

[32]  Zhang, Y., Li, K., Li, K., Wang, L., Zhong, B., and Fu, Y. "Image Super-Resolution Using Very Deep Residual Channel Attention Networks." *European Conf. on Computer Vision (ECCV)*, 2018, pp. 286–301.

[33]  Liang, J., Cao, J., Sun, G., Zhang, K., Van Gool, L., and Timofte, R. "SwinIR: Image Restoration Using Swin Transformer." *ICCV Workshops*, 2021, pp. 1833–1844.

[34]  Zamir, S. W., Arora, A., Khan, S., Hayat, M., Khan, F. S., and Yang, M.-H. "Restormer: Efficient Transformer for High-Resolution Image Restoration." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2022, pp. 5728–5739.

[35]  Chen, L., Chu, X., Zhang, X., and Sun, J. "Simple Baselines for Image Restoration." *European Conf. on Computer Vision (ECCV)*, 2022, pp. 17–33.

[36]  Wang, X., Xie, L., Dong, C., and Shan, Y. "Real-ESRGAN: Training Real-World Blind Super-Resolution with Pure Synthetic Data." *ICCV Workshops*, 2021, pp. 1905–1914.

[37]  Sohl-Dickstein, J., Weiss, E., Maheswaranathan, N., and Ganguli, S. "Deep Unsupervised Learning Using Nonequilibrium Thermodynamics." *Int. Conf. on Machine Learning (ICML)*, 2015, pp. 2256–2265.

[38]  Ho, J., Jain, A., and Abbeel, P. "Denoising Diffusion Probabilistic Models." *Advances in Neural Information Processing Systems (NeurIPS)*, 2020.

[39]  Song, J., Meng, C., and Ermon, S. "Denoising Diffusion Implicit Models." *Int. Conf. on Learning Representations (ICLR)*, 2021.

[40]  Dhariwal, P., and Nichol, A. "Diffusion Models Beat GANs on Image Synthesis." *Advances in Neural Information Processing Systems (NeurIPS)*, 2021.

[41]  Kawar, B., Elad, M., Ermon, S., and Song, J. "Denoising Diffusion Restoration Models." *Advances in Neural Information Processing Systems (NeurIPS)*, 2022.

[42]  Saharia, C., Ho, J., Chan, W., Salimans, T., Fleet, D. J., and Norouzi, M. "Image Super-Resolution via Iterative Refinement." *IEEE Transactions on Pattern Analysis and Machine Intelligence*, vol. 45, no. 4, 2022, pp. 4713–4726.

[43]  Rombach, R., Blattmann, A., Lorenz, D., Esser, P., and Ommer, B. "High-Resolution Image Synthesis with Latent Diffusion Models." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2022, pp. 10684–10695.

[44]  Hinton, G., Vinyals, O., and Dean, J. "Distilling the Knowledge in a Neural Network." *NeurIPS Deep Learning Workshop*, 2015.

[45]  Romero, A., Ballas, N., Kahou, S. E., Chassang, A., Gatta, C., and Bengio, Y. "FitNets: Hints for Thin Deep Nets." *Int. Conf. on Learning Representations (ICLR)*, 2015.

[46]  Ding, X., Zhang, X., Ma, N., Han, J., Ding, G., and Sun, J. "RepVGG: Making VGG-Style ConvNets Great Again." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2021, pp. 13733–13742.

[47]  Han, S., Mao, H., and Dally, W. J. "Deep Compression: Compressing Deep Neural Networks with Pruning, Trained Quantization and Huffman Coding." *Int. Conf. on Learning Representations (ICLR)*, 2016.

[48]  Salimans, T., and Ho, J. "Progressive Distillation for Fast Sampling of Diffusion Models." *Int. Conf. on Learning Representations (ICLR)*, 2022.

[49]  Zhang, R., Isola, P., Efros, A. A., Shechtman, E., and Wang, O. "The Unreasonable Effectiveness of Deep Features as a Perceptual Metric." *IEEE Conf. on Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 586–595.

[50]  Wang, Z., Bovik, A. C., Sheikh, H. R., and Simoncelli, E. P. "Image Quality Assessment: From Error Visibility to Structural Similarity." *IEEE Transactions on Image Processing*, vol. 13, no. 4, 2004, pp. 600–612.
