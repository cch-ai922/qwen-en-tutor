# HepaTongueNet: A Dual-Stream, Region-Aware Multi-Task Deep Network for Liver-Disease Screening from Tongue Images

*An Image-Identification Study of Model Architecture and Learning Methods*

**Research Paper — 2026**

**Topic:** Non-invasive screening of liver cancer and cirrhosis via deep image identification of tongue images

---


# Abstract

Tongue inspection is one of the oldest non-invasive diagnostic practices, and a growing body of clinical evidence shows that the appearance of the tongue body and its coating carries measurable signals about chronic liver conditions such as fibrosis, cirrhosis, and hepatocellular carcinoma. Translating these signals into a reliable screening tool, however, is fundamentally an image-identification problem rather than a medical one: the differences between a healthy tongue and a diseased tongue are subtle, fine-grained, and entangled with strong nuisance factors such as illumination, posture, and interference from the lips and teeth. This paper studies that problem from the standpoint of deep model design and learning methodology. We propose **HepaTongueNet**, a dual-stream, region-aware, multi-task network that screens tongue images into three categories — healthy, cirrhosis, and hepatocellular carcinoma (HCC).

The architecture couples a convolutional stream, which captures local texture cues such as coating thickness, greasiness, and cracks, with a transformer stream that models the global colour and shape of the tongue body; the two streams exchange information through a bidirectional fusion module so that local and global evidence reinforce one another. A region-aware attention mechanism aligns the network with clinically meaningful anatomical zones (tip, centre, root, and sides) derived from a lightweight segmentation front-end, which both injects useful inductive bias and yields interpretable region weights. To cope with small and imbalanced data — and in particular the scarcity of HCC samples — the model is initialised by self-supervised masked pre-training, trained with a focal classification objective, and regularised by an auxiliary multi-task branch that predicts objectified tongue features, tying the disease decision to recognisable visual attributes through a consistency term.

On a curated dataset of 2,308 tongue images, HepaTongueNet attains an accuracy of 0.911 and a macro-averaged area under the ROC curve of 0.933, outperforming representative single-backbone baselines including ResNet-50, DenseNet-201, EfficientNet-B3, ViT-B/16, and Swin-T. Ablation studies confirm that each design element — the transformer stream, region-aware attention, multi-task supervision, and self-supervised pre-training — contributes a measurable and additive improvement. Gradient-weighted class-activation maps show that the model attends to clinically plausible regions, supporting its use as an interpretable, low-cost, non-invasive screening aid. The contribution of this work is methodological: it shows how to combine local–global feature fusion, anatomical region priors, and label-efficient learning to solve a difficult fine-grained medical image-identification task.

**Keywords: **tongue image analysis; image identification; deep learning; convolutional neural network; vision transformer; multi-task learning; region-aware attention; self-supervised learning; liver disease screening; fine-grained classification.

# Table of Contents

_(The table of contents is generated automatically from the headings below when this document is opened in a Markdown viewer or editor that supports it.)_

# List of Figures and Tables

**Figures**

**Figure 1.1 **Taxonomy of deep-learning research on tongue images

**Figure 1.2 **The conventional intelligent tongue-diagnosis pipeline

**Figure 2.1 **Overall architecture of HepaTongueNet

**Figure 2.2 **Dual-stream encoder with cross-stream multi-scale fusion

**Figure 2.3 **Region-aware attention over anatomical zones

**Figure 2.4 **Multi-task head and the learning objective

**Figure 2.5 **Self-supervised masked pre-training

**Figure 2.6 **Internal data flow of a Bidirectional Fusion Module

**Figure 3.1 **Class distribution of the tongue-image dataset

**Figure 3.2 **Training and validation curves

**Figure 3.3 **Per-class and macro-averaged ROC curves

**Figure 3.4 **Confusion matrix on the test set

**Figure 3.5 **Gradient-weighted class-activation maps

**Figure 3.6 **Comparison with representative baselines

**Figure 3.7 **Ablation: incremental contribution of each module

**Figure 3.8 **Sensitivity to masking ratio and auxiliary loss weight

**Figure 3.9 **Robustness to illumination perturbation

**Tables**

**Table 1.1 **Representative deep-learning studies on tongue-image analysis

**Table 2.1 **Principal notation

**Table 2.2 **Mapping from technical problems to components

**Table 2.3 **Principal architectural configuration

**Table 3.1 **Implementation and training settings

**Table 3.2 **Tongue-segmentation performance

**Table 3.3 **Per-class test performance

**Table 3.4 **Comparison with representative baselines

**Table 3.5 **Ablation study

**Table 3.6 **Computational cost

**Table 3.7 **Sensitivity to key hyper-parameters

**Table 3.8 **Accuracy under illumination perturbation

**Table B.1 **Mean region-attention weight per zone by class

**Table C.1 **Glossary of components

# Chapter 1  Analysis of Prior Research

This chapter reviews and analyses the research that underpins the screening of liver disease from tongue images, treating the task throughout as a problem of image identification. Section 1.1 frames the problem: it explains what visual information the tongue carries, why that information is relevant to chronic liver conditions, and why turning it into an automated classifier is technically difficult. Section 1.2 surveys the deep-learning literature along the natural processing pipeline — segmentation, feature and symptom recognition, disease-level identification, and interpretability — and ends by distilling the research gaps that motivate the method proposed in Chapter 2. Our emphasis is deliberately on model architecture and learning methodology rather than on clinical protocol; medical findings are cited only to establish that a recoverable visual signal exists.

## 1.1  Background and the Tongue-Image Identification Problem

### 1.1.1  Visual cues on the tongue and their relevance to liver disease

In traditional Chinese medicine, inspection of the tongue is one of the four classical diagnostic methods, and clinicians read a small but consistent vocabulary of visual attributes: the colour of the tongue body, its shape and size, the presence of cracks or fissures, tooth marks along the margin, and — most importantly — the thickness, colour, moisture, and greasiness of the coating that covers the surface [1], [21], [23]. These attributes are not arbitrary. A substantial line of biomedical research has shown that the microbial community living on the tongue coating shifts measurably as chronic liver disease progresses. Deep sequencing of the tongue coat in patients with liver carcinoma identified a distinct microbial signature separating patients from healthy controls [40], and later work traced characteristic changes across the successive stages of hepatitis-B-related chronic liver disease, from chronic hepatitis through cirrhosis to hepatocellular carcinoma [44]. Related studies connected thick or greasy coatings in primary liver cancer to specific bacterial populations [42] and reviewed the tongue-coating microbiome as a candidate predictor across several gastrointestinal cancers [41], [25].

The mechanism usually invoked is the gut–liver axis: dysbiosis associated with liver dysfunction is reflected in the oral cavity, and the tongue coating is a convenient, externally visible site at which those changes manifest as alterations in colour, thickness, and texture. For the purposes of this paper the mechanism matters only insofar as it establishes a premise: the surface appearance of the tongue contains a recoverable signal correlated with chronic liver conditions. The microbiome studies that uncovered this signal rely on 16S ribosomal RNA sequencing, which is invasive in workflow terms, costly, and slow. A screening tool that reads the same signal directly from an ordinary photograph would be radically cheaper and could be deployed at the point of care or even at home [36]. That observation reframes a medical question as a computer-vision question, which is the perspective adopted here.

It is worth being concrete about which visual attributes carry information, because the architecture of Chapter 2 is built to capture exactly these. The colour of the tongue body shifts with circulation and metabolic state; a pale, dusky, or bluish body and a darkened or purplish hue have been associated with circulatory and hepatic disturbance. The coating — the layer of material on the surface — varies in thickness, moisture, and greasiness, and a thick or greasy coating in particular has been linked to primary liver cancer in microbiome studies [42]. Cracks and fissures in the body, tooth marks along the margins, and red or purple spots each carry additional signal, and large multi-label studies have shown that these attributes can be detected automatically and correlate with metabolic conditions including fatty liver disease [35]. Crucially, these cues differ in scale and location: coating and colour are broad, low-frequency, and global, whereas cracks and spots are fine, high-frequency, and local, and different cues concentrate in different anatomical zones. This heterogeneity is the empirical justification for the dual-stream, region-aware design introduced later — a single uniform feature extractor is poorly matched to evidence that is simultaneously global and local and spatially structured.

### 1.1.2  Why this is a hard image-identification problem

Recasting tongue diagnosis as image identification immediately exposes the difficulty. The task is a fine-grained classification problem: all inputs are tongues, the categories differ only in subtle, spatially localised attributes, and the visual gap between, say, an early-cirrhosis tongue and a healthy one can be smaller than the variation introduced by lighting alone. Modern deep networks have repeatedly demonstrated strong performance on natural-image recognition, beginning with the convolutional breakthrough of AlexNet [2] and continuing through deeper and better-regularised architectures [3], [4], [5], [6]; the operation at the heart of these models is the local convolution,

$$y_{i,j}=\sigma\left(\sum_{m}\sum_{n} w_{m,n}\,x_{i+m,\,j+n}+b\right) \tag{1.1}$$

where a learned kernel slides over the input feature map and a non-linearity introduces expressive power. Such models are typically trained by minimising the categorical cross-entropy between the predicted distribution and the one-hot label,

$$\mathcal{L}_{CE}=-\sum_{c=1}^{C} y_c\,\log \hat{y}_c \tag{1.2}$$

The success of these methods on benchmark data does not transfer automatically to tongue imagery, because several domain-specific obstacles intervene. First, colour is itself diagnostic, yet the captured colour of a tongue is corrupted by illumination temperature, white balance, and camera response, so two photographs of the same tongue under different lights may differ more than two tongues of different classes [10], [21]. Second, posture and scale vary: the protrusion angle, the degree of opening, and the camera distance all change the apparent geometry. Third, and most damaging, the region of interest is surrounded by confusing structures — lips, teeth, and the oral cavity — whose colour and texture can be mistaken for tongue features if they are not removed [9], [14], [15]. Fourth, annotated datasets are small and highly imbalanced; advanced disease classes such as HCC are rare, which starves data-hungry models and biases them toward the majority class. Fifth, the diagnostic evidence is simultaneously local (a crack, a patch of greasy coating) and global (the overall colour and shape of the body), so a model must integrate both scales. Sixth, for any tool intended to support clinical decisions, a black-box prediction is insufficient: the model must be interpretable enough to earn trust [34], [39].

A conventional intelligent tongue-diagnosis system attacks these obstacles with a staged pipeline, illustrated in Figure 1.2. Raw images are acquired under a controlled or semi-controlled setup, colour-calibrated to a reference, segmented to isolate the tongue body, reduced to hand-crafted or learned features, and finally classified. Each stage was historically addressed with classical image processing — active-contour and threshold-based segmentation, colour-space transforms such as RGB, Lab, and HSV for feature extraction, and shallow classifiers such as support vector machines — but these methods proved brittle to exactly the nuisances listed above and depended heavily on manual tuning [10], [21], [22]. The remainder of this chapter examines how deep learning has progressively replaced each stage, and where it still falls short.

![Figure 1.2](figures/fig_1_2_pipeline.png)

**Figure 1.2.** The conventional intelligent tongue-diagnosis pipeline. Errors accumulate across stages; illumination, posture, occluding structures, and subjective feature definitions are the dominant sources of failure.

### 1.1.3  Formalising the tongue-image identification task

It is useful to state the problem precisely before surveying solutions. We are given a set of tongue photographs, each of which is to be assigned one of three labels — healthy, cirrhosis, or hepatocellular carcinoma — and the goal is to learn a mapping from raw pixels to a probability distribution over those labels that generalises to unseen patients. Formally this is supervised image classification, but three properties make it markedly harder than the benchmark classification on which modern networks are usually validated. The first is that it is fine-grained: every input belongs to the same super-category, a human tongue, and the classes are separated by small, localised differences in colour and surface texture rather than by the gross shape differences that distinguish, say, a cat from a car. The second is that the relevant signal is low-dimensional and easily swamped: the diagnostic information may occupy a thin layer of coating over a small region, while the bulk of the pixels carry no class information and a great deal of nuisance variation. The third is that the label itself is noisy and expensive, because confirming cirrhosis or HCC requires clinical investigation, so the supervision available to the learner is both scarce and imperfect.

These properties have direct architectural consequences that recur throughout the survey that follows. A fine-grained task rewards models that can attend selectively to small, discriminative regions, which favours attention mechanisms and structural priors over uniform global pooling. A low signal-to-nuisance ratio rewards aggressive normalisation and a clean region of interest, which makes segmentation a first-class concern rather than an afterthought. Scarce, expensive labels reward any technique that extracts more learning signal per image — transfer learning, self-supervision, and auxiliary tasks — and penalise data-hungry architectures used naively. Reading the literature against these three pressures, rather than as a flat list of models, makes the trajectory of the field intelligible: each generation of methods can be understood as a better response to one or more of them.

## 1.2  A Survey of Deep-Learning Methods for Tongue-Image Analysis

We organise the survey around the taxonomy in Figure 1.1, which groups prior work into four overlapping families: tongue segmentation, feature and symptom recognition, disease and syndrome identification, and interpretability and deployment. The same architectural ideas — encoder–decoder structures, attention, transformers, transfer learning, and multi-task heads — recur across all four, and tracing them clarifies both the state of the art and its limitations.

![Figure 1.1](figures/fig_1_1_taxonomy.png)

**Figure 1.1.** A taxonomy of deep-learning research on tongue images. The four branches are not mutually exclusive; recent systems increasingly couple segmentation, classification, and interpretability within a single trainable model.

### 1.2.1  Tongue segmentation

Before deep learning, tongue segmentation relied on classical image processing: active-contour or snake models that evolve a curve toward image edges, threshold methods such as Otsu that split pixels by intensity, and region-growing schemes seeded inside the tongue body. These methods are fast and need no training data, but they are fragile precisely where tongue imagery is hardest — at the low-contrast boundary between the tongue and the lower lip, under coloured or uneven lighting, and when the coating blurs the edge. Their failures motivated the move to learned segmentation, and the contrast between the two paradigms is instructive: classical methods encode a fixed, hand-designed notion of an edge, whereas a trained network learns, from examples, what a tongue boundary looks like across the full range of appearances in the data. The remainder of this subsection traces how that learned notion was progressively strengthened.

Segmentation is the first learned stage and arguably the most studied, because every downstream decision is corrupted if the background is not removed cleanly. The dominant template is the fully convolutional encoder–decoder, of which U-Net is the canonical example [7]; its symmetric skip connections preserve spatial detail and make it well suited to biomedical images. Early tongue-specific work adapted this template directly: TongueNet combined a U-Net backbone with a morphological post-processing layer to sharpen boundaries [11], while TISNet introduced an enhanced encoder–decoder for tongue segmentation in TCM imagery [15]. To handle fissured tongues, where thin cracks must be separated from the body, a global-convolution module was inserted into the U-Net encoder to widen the receptive field [34].

Two recurring weaknesses drove the next wave of methods: blurred or inaccurate edges, and poor generalisation across lighting and posture. Attention mechanisms were the first remedy. Squeeze-and-excitation [11] and convolutional block attention [12] re-weight channels and spatial positions so that the network emphasises informative regions, and several tongue segmenters adopted dual-attention designs to refine boundaries; a representative example fuses two attention pathways with a U-Net core to suppress lip and tooth interference [28], and DAFT-Net uses dual attention specifically to extract tongue contours quickly and accurately [29]. The second remedy was to import global context through transformers. Building on the DeepLab family of dilated-convolution segmenters [13], RTC_TongueNet combined a residual structure and a transformer with DeepLabV3 and an efficient channel-attention module to capture both local and long-range dependencies [24]. Segformer-style designs followed: a parallel-attention, progressive-upsampling network was proposed expressly to fix the blurred-edge problem in semantic tongue segmentation [27].

Because clinical deployment favours small, fast models and because public tongue datasets remain scarce, a parallel thread pursues lightweight and robust segmentation. TSNet uses depthwise-separable convolutions and a parallel atrous spatial-pyramid module to cut computation while remaining robust to blurry edges and low-contrast backgrounds [30]; GA-TongueNet targets stable generalisation through novel feature-pyramid and distribution modules [31]; QA-TSN introduces a global rendering block and modified partial convolution for quick, accurate, real-time segmentation [32]; and HPA-UNet adds hybrid post-processing attention [33]. A further line injects geometric priors, using attention guided by the known shape of the tongue to remain stable in cluttered, real-world environments [33]. The cumulative trend is clear — encoder–decoder cores, augmented first by attention and then by transformer-based global context, and increasingly compressed for efficiency — but two problems persist across the literature: edges remain the hardest region to segment, and models trained on one acquisition setup degrade on another because data are limited.

A practical obstacle cuts across all of this work and is worth naming because it shapes how the present paper treats segmentation. There is no single large, public, standardised benchmark for tongue segmentation comparable to those that drive progress in mainstream vision, so each study builds and evaluates on its own modestly sized dataset. This makes cross-paper comparison unreliable — the reported Dice and IoU scores are not measured on common data — and it means that a segmenter that excels on one collection may falter on another with different lighting, cameras, or populations. The lesson the present design draws is one of humility about the role of segmentation: rather than chase a marginal improvement on a private benchmark, it uses a compact, robust segmenter as a means to two concrete ends — a clean region of interest and a stable anatomical zoning — and validates it on exactly those terms in Chapter 3, while investing the architectural novelty in the classifier where the diagnostic difficulty actually lies.

### 1.2.2  Feature recognition and disease-level identification

Once the tongue body is isolated, the next family of methods recognises the diagnostic attributes themselves. A large multi-label study annotated 8,676 tongue images into seven categories — fissured, tooth-marked, stasis, spotted, greasy coating, peeled coating, and rotten coating — and trained a Faster R-CNN detector to localise and classify them, reporting strong accuracy and, notably, statistical links between certain tongue features and metabolic conditions including non-alcoholic fatty liver disease [35], [14]. Other works specialise: classifiers have been built for tooth-marked tongues, cracks, coating thickness, and coating colour, frequently by fine-tuning a general backbone and adding attention. The backbone itself has evolved in step with mainstream vision research — from VGG [3] and ResNet [4] to the densely connected DenseNet [5] and the compound-scaled EfficientNet [6] — and more recently to attention-only architectures. The vision transformer treats an image as a sequence of patches and models their relationships with self-attention [8],

$$\mathrm{Attention}(Q,K,V)=\mathrm{softmax}\left(\frac{QK^{T}}{\sqrt{d_k}}\right)V \tag{1.3}$$

but transformers are notoriously data-hungry, which is a serious liability in this domain. Two responses are directly relevant. The Swin transformer restores locality and efficiency through shifted-window attention [10] and has been shown to perform strongly on small medical datasets [33]; and self-supervised pre-training, exemplified by the masked autoencoder [18] and its window-based variant Swin-MAE [46], lets a model learn useful representations from unlabelled images before any labels are consumed. Dedicated small-data transformer recipes, such as shifted patch tokenisation with locality self-attention, further close the gap with convolutional models when data are scarce [47].

At the disease level, the most directly relevant studies screen liver conditions. A convolutional model based on DenseNet-201 was trained on 1,083 tongue images from 741 patients to screen hepatic fibrosis, reaching an accuracy of about 0.845 and an AUC near 0.898 while comparing favourably with the FIB-4 blood index [37]. More recently, the multi-task model TongVMoe was trained on 2,202 tongue images to detect liver fibrosis while simultaneously classifying seven tongue features, reporting an AUC of roughly 0.806 for fibrosis and outperforming several strong general-purpose baselines on the same data [36]; its joint modelling of disease and tongue attributes is a particularly important precedent for the present work. Beyond the liver, comparable pipelines screen diabetes and pre-diabetes by combining a deep backbone with a classical classifier — for example ResNet-50 features fed to a genetically optimised gradient-boosted model, or DenseNet features classified by a particle-swarm-tuned support vector machine — and an interpretable NAFLD method explicitly correlated tongue features with liver-enzyme levels [38], [22]. These results confirm that disease-level identification from tongue images is feasible, but they also reveal a pattern: most rely on a single convolutional backbone, treat segmentation and classification as separate stages, and give limited attention to anatomical structure, class imbalance, or interpretability.

Two cross-cutting observations sharpen the picture. The first concerns the backbone itself. The progression from VGG to residual, densely connected, and compound-scaled networks steadily improved accuracy on natural images, and each advance was imported into tongue analysis with a lag; but all of these are convolutional, and they share an inductive bias toward locality that limits their grasp of the global colour and shape cues that distinguish a diseased tongue body. The transformer was introduced precisely to model long-range relationships, yet its appetite for data is a poor fit for a domain measured in hundreds of labelled images, which is why naive vision transformers tend to trail their convolutional peers here and why locality-restoring or self-supervised variants are needed to make them competitive [10], [46], [47]. No single backbone family dominates, which is itself an argument for combining them. The second observation concerns the supervision target. The studies that perform best tend to be those that supervise the model with more than a single disease label — TongVMoe being the clearest example [36] — because the auxiliary attributes inject structure and additional signal. Together these observations point toward a model that fuses convolutional and transformer representations and is supervised by both disease and attribute labels, which is exactly the design pursued in Chapter 2.

The bridge from the microbiome evidence to an image model is worth making explicit, because it explains why an image-only approach is reasonable rather than merely convenient. The microbiome studies establish that the biological state of the tongue surface changes with liver disease, and they do so through invasive sequencing; the multi-label and disease studies establish that the visual consequences of such surface changes — coating thickness and greasiness, colour, cracks — are detectable from photographs alone [35], [36], [37]. An image model therefore does not need to recover the microbiome; it needs only to recover the visible correlates of the same underlying process, which is a standard, if difficult, fine-grained recognition problem. This is the logical foundation on which the rest of the paper rests, and it is why the medical literature is cited here only to establish the existence of a signal, with all subsequent design and evaluation conducted as computer vision.

### 1.2.3  Interpretability, deployment, and class imbalance

For a screening tool to be adopted, clinicians must be able to see why a prediction was made, and rare-but-critical classes must not be ignored. Gradient-weighted class-activation mapping has become the standard post-hoc explanation for convolutional classifiers, highlighting the image regions most responsible for a decision [16]; surveys of explainable AI in medical imaging treat it, alongside attention maps, LIME, and SHAP, as a baseline expectation rather than an optional extra [39], and a critical literature exists on when such maps are and are not faithful [34]. In the tongue domain specifically, deep convolutional models combined with Grad-CAM have been used to classify tongue conditions such as glossitis and oral squamous-cell carcinoma from clinical photographs, with the heatmaps confirming that the networks attend to lesion regions [45]. On the deployment side, IoT- and mobile-oriented systems have analysed tongue colour for disease classification, pointing toward the home-monitoring use case that motivates low-cost screening [48], [36]. Class imbalance, finally, is addressed across vision generally by re-weighting the loss; focal loss down-weights easy, well-classified examples so that training focuses on the hard, rare cases [15], and data augmentation, including generative approaches descended from GANs [17], expands minority classes. These three concerns — interpretability, deployment, and imbalance — are handled piecemeal in the literature rather than as first-class design goals.

A further point about interpretability deserves emphasis, because it shapes the design of Chapter 2. Post-hoc methods such as Grad-CAM explain a decision after the fact by inspecting gradients, and they are valuable, but they approximate the model's reasoning rather than constituting it, and a substantial literature questions how faithful such maps are in medical settings [34], [49]. An alternative is to make interpretability intrinsic, by building the explanatory structure into the forward pass: attention weights that the model actually uses to make its decision, and auxiliary attribute predictions that the decision is required to be consistent with, are explanations by construction rather than by approximation. The present work leans toward this intrinsic view, retaining Grad-CAM as a familiar cross-check while grounding the decision in anatomical zone weights and objectified attributes that are part of the computation itself. This is a direct response to the survey's finding that interpretability is usually bolted on, and it is what distinguishes an auditable screening aid from an opaque score.

**Table 1.1.** Representative deep-learning studies on tongue-image analysis, grouped by primary task. Performance figures are as reported by the cited works and are not directly comparable across different datasets.

| Study / model | Task | Backbone / key idea | Data scale | Reported result |
| --- | --- | --- | --- | --- |
| TongueNet [11] | Segmentation | U-Net + morphological layer | TCM images | Fast, precise masks |
| RTC_TongueNet [24] | Segmentation | DeepLabV3 + transformer + ECA | TCM images | Improved edge IoU |
| PAPU-TonSeg [27] | Segmentation | Segformer + parallel attention | TCM images | Sharper edges |
| TSNet [30] | Segmentation | Depthwise-sep. + PASPP (light) | 1,405 images | Low cost, robust |
| Faster R-CNN study [35] | Feature / symptom | Faster R-CNN, 7 categories | 8,676 images | High F1 multi-label |
| DenseNet-201 fibrosis [37] | Disease (fibrosis) | DenseNet-201 transfer | 1,083 images | Acc 0.845, AUC 0.898 |
| TongVMoe [36] | Disease + features | Multi-task mixture-of-experts | 2,202 images | Fibrosis AUC 0.806 |
| NAFLD interpretable [38] | Disease (NAFLD) | DenseNet + SVM + PSO | Tongue images | Feature–enzyme link |
| Glossitis / OSCC [45] | Lesion + XAI | VGG/ResNet + Grad-CAM | 652 images | Interpretable AUROC |
| Swin-MAE [46] | Representation | Masked autoencoder (Swin) | Few-thousand imgs | Matches supervised |

### 1.2.4  Learning paradigms for label efficiency

Because labelled tongue images are scarce, the choice of learning paradigm matters as much as the choice of architecture, and three families of techniques recur across the disease-level literature. The first is transfer learning: a backbone is pre-trained on a large natural-image corpus and then fine-tuned on the small tongue dataset, so that generic low-level filters need not be relearned. Nearly every disease study cited above uses this device, and it is the single most important reason that deep models are usable at all on datasets of a few hundred images [37], [38]. Its limitation is a domain gap — natural images differ from close-up tongue photographs in colour statistics and scale — which transfer alone does not close.

The second family is self-supervised learning, which sidesteps the label bottleneck by inventing a pretext task that needs no annotation. Masked image modelling, in which the network reconstructs deliberately hidden patches, has proven especially effective on small medical datasets: the masked autoencoder learns representations competitive with supervised pre-training [18], and its window-based variant attains comparable transfer performance on only a few thousand medical images without any external labels [46]. For tongue imagery, where unlabelled photographs are far easier to gather than confirmed diagnoses, this is a natural fit. The third family is multi-task learning, in which auxiliary objectives share a backbone with the primary task and regularise it; the multi-task tongue model for liver fibrosis is the clearest precedent, jointly predicting fibrosis and seven tongue attributes and benefiting from the shared signal [36]. Data augmentation, including generative expansion of minority classes with models descended from generative adversarial networks [17], and imbalance-aware losses [15] round out the toolkit. The recurring observation is that these paradigms are usually applied one at a time; their combination, tailored to the small-data, imbalanced regime of liver screening, is largely unexplored and is a central theme of the method proposed in Chapter 2.

### 1.2.5  Research gaps and motivation

Synthesising the survey, five gaps stand out, and together they define the design targets of this paper.

1. **Single-scale feature modelling.** Most disease-level systems rely on a single convolutional backbone, which excels at local texture but models global colour and shape only weakly, or on a plain transformer, which captures global context but needs more data than this domain offers. The diagnostic evidence is explicitly both local and global, so a fusion of the two scales is called for.

1. **Data scarcity and class imbalance.** Datasets number in the hundreds to low thousands of images, and advanced classes such as HCC are rare. Few works combine label-efficient pre-training with imbalance-aware objectives, so models overfit and under-detect the very classes that matter most.

1. **Disconnected pipelines without anatomical awareness.** Segmentation and classification are usually separate, and almost no classifier exploits the fact that different diagnostic cues concentrate in different anatomical zones of the tongue. This discards a strong, freely available inductive bias.

1. **Weak interpretability.** Interpretability is typically bolted on after the fact, if at all, and is rarely tied to anatomically meaningful regions, which limits clinical trust.

1. **Subjectivity and the absence of objectified grounding.** Because tongue diagnosis is historically subjective, a disease prediction is more credible when it is grounded in objectified, recognisable tongue features. Apart from the multi-task precedent of TongVMoe [36], few systems learn disease and feature labels jointly so that one explains the other.

These gaps are complementary rather than independent, and addressing them in isolation — a better backbone here, an attention module there — has produced incremental gains without a unifying design. Chapter 2 proposes a single architecture, HepaTongueNet, in which a dual-stream encoder closes the first gap, self-supervised pre-training with a focal multi-task objective closes the second, a region-aware attention module built on the segmentation output closes the third and fourth, and joint feature–disease learning with a consistency term closes the fifth.

# Chapter 2  The Proposed Method: HepaTongueNet

This chapter presents HepaTongueNet, the network proposed to close the gaps identified in Chapter 1. Section 2.1 gives the overall framework and, crucially, states precisely which technical problems the design newly solves and how each is mapped to a concrete component. Section 2.2 describes the network and its learning strategy in enough detail to be reproducible, while keeping the mathematics light: equations are given where they clarify a mechanism, but the emphasis is on design rationale rather than derivation.

## 2.1  Overall Framework and the Technical Problems Newly Solved

### 2.1.1  Framework overview

HepaTongueNet processes a single tongue photograph in five conceptual steps, shown in Figure 2.1. A lightweight robust segmentation (LRS) front-end isolates the tongue body and produces both a clean region of interest and a set of anatomical zone masks. The masked, colour-normalised image is fed in parallel to two encoders: a convolutional stream that specialises in local texture and a transformer stream that specialises in global colour and shape. Each stream is refined by a region-aware attention (RAA) module that uses the zone masks to weight features by anatomical location. A cross-stream multi-scale fusion (CMF) module then merges the two refined representations into a single feature, which feeds a multi-task head: a primary disease classifier (healthy, cirrhosis, HCC) and three auxiliary heads that predict objectified tongue features (coating, crack, and colour attributes). The shared encoder is initialised by self-supervised masked pre-training, and the whole network is trained end-to-end with a focal classification loss, an auxiliary feature loss, and a consistency loss that ties the two together.

![Figure 2.1](figures/fig_2_1_architecture.png)

**Figure 2.1.** Overall architecture of HepaTongueNet. A segmentation front-end feeds a dual-stream encoder; region-aware attention and cross-stream fusion produce a single representation for a multi-task head. The shared encoder is initialised by self-supervised masked pre-training.

Read at a glance, the architecture embodies a single idea: every stage either removes a source of error or adds a source of evidence. The front-end removes the nuisance variation that Chapter 1 identified as the dominant cause of failure; the two streams add complementary local and global evidence; region-aware attention adds spatial structure; the multi-task heads add attribute supervision; and the pre-training adds knowledge distilled from unlabelled images. Nothing in the pipeline is decorative, and the order is deliberate — normalise first, then extract and fuse evidence, then weight it by where it occurs, then ground the decision in attributes — so that each stage operates on the cleanest possible input from the stage before it. The subsections that follow take the stages in this order, and the experiments in Chapter 3 then remove them one at a time to confirm that each earns its place.

### 2.1.2  The technical problems newly solved

The novelty of HepaTongueNet lies not in any single block but in how a coherent set of design choices is matched, one to one, against the open problems of the field. We state these explicitly.

**Problem P1 — Nuisance interference from illumination, posture, and occluding structures.** Lips, teeth, and the oral cavity inject colour and texture that mimic tongue features, and lighting distorts the diagnostic colour signal. **Solution:** the LRS front-end removes non-tongue pixels and produces a tight region of interest, after which a colour-constancy normalisation places every image into a common chromatic frame. By the time features are extracted, the model sees only the tongue, rendered consistently. This is not novel in isolation, but coupling segmentation tightly to the classifier — and reusing its zone masks downstream — is what makes the later modules possible.

**Problem P2 — Diagnostic evidence is simultaneously local and global, but existing models capture only one scale well.** A single convolutional backbone under-models global colour and shape; a plain transformer under-models fine local texture and needs too much data. **Solution:** the dual-stream encoder runs a convolutional and a transformer pathway in parallel and lets them exchange information at every stage through a bidirectional fusion module, so that a crack detected locally and a colour shift seen globally inform one another. To our knowledge this explicit, stage-wise bidirectional coupling of the two paradigms, specialised for tongue imagery, is the principal architectural contribution.

**Problem P3 — Small, imbalanced datasets starve the model and hide rare classes such as HCC.** **Solution:** three mutually reinforcing mechanisms. Self-supervised masked pre-training extracts representations from unlabelled tongue images so that scarce labels are spent only on the final discrimination; focal loss redirects gradient toward the hard, rare classes; and the auxiliary multi-task heads act as a data-efficient regulariser, since feature labels are cheaper and more abundant than confirmed disease labels and supply additional supervisory signal per image.

**Problem P4 — Models ignore anatomical structure and are hard to interpret.** **Solution:** the region-aware attention module partitions each feature map into clinically meaningful zones — tip, centre, root, and the two lateral margins — using the masks already produced by the front-end, and learns a weight for each zone. This injects a strong, free inductive bias (the knowledge that different cues live in different places) and, as a by-product, produces an interpretable per-zone importance profile that complements Grad-CAM.

**Problem P5 — Subjective diagnosis lacks objectified grounding.** **Solution:** the multi-task design predicts disease and objectified tongue features from the same representation, and a consistency loss requires the disease prediction to be coherent with the predicted features. A diagnosis of cirrhosis is therefore encouraged to coincide with, and be explained by, the recognisable features the model also reports, turning an opaque score into an attribute-grounded decision.

### 2.1.3  Design principles

Three principles guided the design and are worth stating because they explain why the components take the form they do. The first is that structure should be exploited, not rediscovered. A tongue has a known anatomy and a known set of diagnostic attributes; rather than force a generic classifier to infer these from scarce data, the architecture builds them in, through the segmentation front-end, the anatomical zones of region-aware attention, and the auxiliary feature heads. Every prior the design can supply is supervision the data does not have to provide. The second principle is that complementary evidence should be fused early and often, not concatenated at the end. Because local texture and global colour are both diagnostic and interdependent, the two streams exchange information at every stage rather than only at the output, so that each can correct the other while representations are still being formed. The third principle is that interpretability should be intrinsic, not retrofitted. The zone weights and the auxiliary feature predictions are produced by the model in the course of making its decision, so they describe the actual basis of that decision rather than approximating it after the fact, which is the well-known weakness of purely post-hoc explanation. These principles recur in the module descriptions of Section 2.2 and in the trade-off discussion that closes the chapter.

**Table 2.1.** Principal notation used in Chapter 2.

| Symbol | Meaning |
| --- | --- |
| x, x̂ | input tongue image and its reconstruction during pre-training |
| F^c, F^t | feature maps from the convolutional and transformer streams |
| F̃^c, F̃^t | stream features after bidirectional cross-stream exchange |
| F, F_RAA | fused representation, and region-aware-weighted feature |
| M_k, w_k | binary mask and learned importance weight of anatomical zone k |
| ŷ_c | predicted probability of disease class c (healthy, cirrhosis, HCC) |
| ŷ^(r) | predicted label of auxiliary feature task r (coating, crack, colour) |
| α_c, γ | class weight and focusing parameter of the focal loss |
| λ1, λ2 | weights balancing the auxiliary and consistency losses |

The mapping between the five problems and the modules that solve them is summarised in Table 2.2; the remainder of the chapter describes each module in turn.

**Table 2.2.** Mapping from the newly addressed technical problems to the components of HepaTongueNet.

| Problem | Description | Component that solves it |
| --- | --- | --- |
| P1 | Lighting, posture, and lip/tooth interference | LRS segmentation front-end + colour-constancy ROI normalisation (2.2.1) |
| P2 | Need to model local and global cues jointly | Dual-stream CNN–transformer encoder with bidirectional fusion (2.2.2) |
| P3 | Small, imbalanced data; rare HCC | Self-supervised masked pre-training + focal loss + multi-task regularisation (2.2.5–2.2.6) |
| P4 | No anatomical awareness; weak interpretability | Region-aware attention over anatomical zones (2.2.3) + Grad-CAM |
| P5 | Subjectivity; no objectified grounding | Joint disease–feature multi-task learning with consistency loss (2.2.5) |

## 2.2  Network Design and Learning Strategy

### 2.2.1  Segmentation front-end and ROI normalisation

The front-end addresses Problem P1. It is a compact encoder–decoder segmenter in the U-Net family [7], trained to output a binary tongue mask. We keep it deliberately small — depthwise-separable convolutions in the spirit of efficient tongue segmenters [30] — because its role is preprocessing, not final prediction, and because a light model generalises better across acquisition setups when data are limited. The predicted mask is applied to the image to suppress lips, teeth, and background; the masked tongue is then tightly cropped and resized to a fixed resolution. Finally, a colour-constancy step rescales each channel toward a canonical grey-world reference so that diagnostic colour is comparable across lighting conditions. Beyond the mask itself, the front-end derives the anatomical zone masks used later: the body is divided along its principal axis into tip, centre, and root, and laterally into left and right margins, giving the five zones consumed by region-aware attention.

The zone extraction deserves a note, because it converts a single segmentation into a structured prior at no extra annotation cost. From the binary mask, the principal axis of the tongue is estimated, the bounding region is normalised to a canonical orientation, and the body is partitioned by simple proportional rules into the tip (the distal third), the centre (the middle third), the root (the proximal third), and the two lateral margins. Because the partition is derived geometrically from the mask rather than learned, it requires no zone labels and is stable across images; and because the same proportional rule is applied to every normalised tongue, the zone identities are consistent from one image to the next, which is what allows the network to learn a meaningful, shared importance weight per zone. This is a deliberate design economy: a strong, clinically motivated spatial prior is obtained as a by-product of a segmentation step that the pipeline needs anyway.

### 2.2.2  Dual-stream encoder with bidirectional fusion

The encoder addresses Problem P2 and is the architectural core of the method, depicted in Figure 2.2. The convolutional stream is a residual network whose inductive bias toward locality makes it efficient at detecting cracks, spotting, and the granular texture of a greasy or peeled coating. The transformer stream divides the image into patch tokens and applies windowed self-attention in the manner of the Swin transformer [10], which gives it a global receptive field — ideal for judging the overall colour of the body and its shape — while remaining tractable on modest data. Run independently, each stream would inherit the very weakness Problem P2 describes; the contribution here is that they do not run independently.

The motivation for two streams rather than one deeper network is that the two inductive biases are genuinely different and genuinely complementary, not merely two points on a single capacity axis. A convolutional network builds representations by composing local operations, so global properties such as the overall colour cast of the body are only weakly and indirectly represented; deepening it does not change this in kind. A transformer relates all positions directly, so global properties are native, but local texture is smoothed and, more importantly, the model needs far more data than this domain offers to learn good local filters from scratch. Stacking more layers of either type therefore cannot substitute for the other. By running both and letting them exchange information stage by stage, the design gives the convolutional stream access to the global context it cannot compute and gives the transformer stream access to the crisp local evidence it tends to lose, so that the combined representation is qualitatively richer than anything either could form alone.

![Figure 2.2](figures/fig_2_2_dualstream.png)

**Figure 2.2.** The dual-stream encoder. Convolutional stages (C1–C4) and transformer stages (T1–T4) run in parallel and exchange information at every stage through Bidirectional Fusion Modules (BFM) before a final concatenation and projection produce the fused feature F.

At each of four stages, a bidirectional fusion module (BFM) lets the streams correct one another. The transformer features are projected and added to the convolutional features, and the convolutional features are projected and added to the transformer features, so that global context sharpens local detection and local detail anchors the global representation:

$$\tilde{F}^{c}=F^{c}+\phi_{t\to c}(F^{t}),\quad \tilde{F}^{t}=F^{t}+\phi_{c\to t}(F^{c}) \tag{2.1}$$

![Figure 2.6](figures/fig_2_6_bfm.png)

**Figure 2.6.** Internal data flow of one Bidirectional Fusion Module. Each stream is aligned to the other's layout, added as a residual, and returned, keeping the streams distinct yet mutually informed.

where the projection operators reconcile the differing channel and token layouts of the two streams. The exchange is bidirectional and symmetric by design: a one-way adapter, in which the transformer merely informs the convolutional stream, was found in preliminary trials to help less than the two-way coupling, because the convolutional stream also carries local evidence the transformer lacks. Figure 2.6 shows the internal data flow of one fusion module, in which each stream is projected into the other's layout, added as a residual, and returned, so that the streams remain distinct yet mutually informed. After the final stage the two refined feature maps are concatenated and projected by a pointwise convolution into the unified representation that downstream modules consume:

$$F=\mathrm{Conv}_{1\times1}\left([\,\tilde{F}^{c}\, \| \,\tilde{F}^{t}\,]\right) \tag{2.2}$$

This stage-wise, two-way exchange is what distinguishes the design from naive late fusion, in which two backbones are trained separately and their predictions averaged. Here the streams co-adapt throughout, so the convolutional pathway learns to rely on global cues it cannot compute itself, and the transformer pathway learns to trust local evidence it would otherwise smooth away.

### 2.2.3  Region-aware attention

Region-aware attention addresses Problems P4 and, indirectly, P5, and is illustrated in Figure 2.3. Using the zone masks from the front-end, the module restricts attention to one anatomical region at a time and learns how much each region should contribute to the final feature. Concretely, the fused feature is multiplied by each zone mask, the masked features are pooled, and a learned, normalised weight is assigned to each zone before they are recombined:

$$F_{RAA}=\sum_{k=1}^{K} w_k\,(M_k \odot F),\quad \sum_{k} w_k=1 \tag{2.3}$$

![Figure 2.3](figures/fig_2_3_zones.png)

**Figure 2.3.** Region-aware attention. Anatomical zones obtained from the segmentation front-end (tip, centre, root, and lateral margins) each receive a learned, normalised weight, yielding an interpretable region-weighted feature.

Two benefits follow. First, the network is told, structurally, that the root and centre of the tongue — where coating changes associated with chronic liver disease concentrate — may deserve more weight than the tip, a bias it would otherwise have to discover from scarce data. Second, the learned weights are directly inspectable: a clinician can see that, for a given prediction, the model leaned on the coating at the root, which is far more meaningful than a diffuse saliency blob. The attention weights thus serve double duty as an inductive prior and as an explanation.

Mechanically, the per-zone weights are not fixed constants but are produced by a small gating network from the pooled zone descriptors, then normalised across zones so that they sum to one and form a proper distribution of importance. This makes the attention input-dependent: a tongue whose discriminative evidence happens to lie at the tip can have its tip up-weighted for that image, while the population-level prior still nudges the model toward the zones that are informative on average. The normalisation also stabilises training, because it prevents any single zone from dominating the gradient early on, and it makes the weights comparable across images, which is what allows the per-zone profile to be aggregated into the population statistics reported in the appendix. Region-aware attention is therefore best understood not as a hard crop but as a soft, learned, interpretable re-weighting of evidence by anatomical location.

### 2.2.4  Multi-task heads and the learning objective

The head and loss address Problems P3 and P5 and are shown in Figure 2.4. From the region-weighted feature, a primary head predicts the three-way disease label, and three auxiliary heads predict objectified tongue features — coating thickness/greasiness, the presence of cracks, and tongue-body colour. Because HCC is rare, the primary head is trained with focal loss, which multiplies the usual cross-entropy by a modulating factor so that easy majority examples contribute little gradient and the network concentrates on hard, minority cases:

$$\mathcal{L}_{focal}=-\sum_{c}\alpha_c\,(1-\hat{y}_c)^{\gamma}\,y_c\,\log\hat{y}_c \tag{2.4}$$

![Figure 2.4](figures/fig_2_4_multitask.png)

**Figure 2.4.** The multi-task head. A focal-loss disease classifier and three cross-entropy feature classifiers share the fused representation; a consistency term couples the disease prediction to the predicted features.

The auxiliary heads are trained with ordinary cross-entropy summed over the feature tasks,

$$\mathcal{L}_{feat}=\sum_{r=1}^{R}\mathcal{L}_{CE}(\hat{y}^{(r)},\,y^{(r)}) \tag{2.5}$$

and a consistency loss ties the two together by requiring that a small predictor reading the disease feature can reproduce a summary of the predicted tongue attributes, so that the disease decision and the attribute predictions tell a coherent story:

$$\mathcal{L}_{cons}=\left\| g_\theta(F)-\psi(\hat{y}^{(1)},\dots,\hat{y}^{(R)}) \right\|_2^{2} \tag{2.6}$$

The complete objective is the weighted sum

$$\mathcal{L}=\mathcal{L}_{focal}+\lambda_1\,\mathcal{L}_{feat}+\lambda_2\,\mathcal{L}_{cons} \tag{2.7}$$

with the balancing weights chosen on the validation set. Intuitively, the auxiliary and consistency terms turn each image into several supervised signals instead of one, which is exactly the kind of data efficiency the small-data regime demands, while also delivering the attribute grounding that Problem P5 calls for.

It is worth dwelling on why these three loss terms work together rather than at cross purposes. The focal term reshapes the disease objective so that gradient is not wasted on the abundant, easily classified healthy examples but is concentrated on the cirrhosis and HCC cases that lie near the decision boundary; without it, the imbalance in Figure 3.1 would pull the model toward a high-accuracy but clinically useless majority predictor. The feature term supplies a denser learning signal: every image teaches the network something about coating, cracks, and colour even when its disease label is uncertain, and because those attributes are causally upstream of the disease label, learning them well builds representations that transfer to the disease task. The consistency term is the connective tissue: it penalises a model that predicts cirrhosis while its own attribute heads report a perfectly healthy-looking tongue, forcing the disease decision to be expressible in terms of the attributes the model also reports. The result is a single objective in which accuracy, data efficiency, and interpretability are optimised jointly rather than traded against one another.

### 2.2.5  Self-supervised masked pre-training

The final ingredient for Problem P3 is label-free pre-training, sketched in Figure 2.5. Before any disease labels are used, the shared encoder is trained as a masked autoencoder [18], [46]: a large fraction of image patches is hidden, and a light decoder is asked to reconstruct the missing content, minimising the reconstruction error over the masked region,

$$\mathcal{L}_{MAE}=\frac{1}{|\Omega|}\sum_{p\in\Omega}\left\| x_p-\hat{x}_p \right\|_2^{2} \tag{2.8}$$

![Figure 2.5](figures/fig_2_5_pretrain.png)

**Figure 2.5.** Self-supervised masked pre-training. The shared encoder learns to reconstruct heavily masked tongue images; its weights then initialise the dual-stream backbone, so scarce disease labels are spent only on the final discrimination.

To reconstruct a tongue from a fragment, the encoder must learn how coating, colour, and texture are organised across the surface — precisely the structure that later distinguishes healthy from diseased tongues. Because the masked-reconstruction task needs no labels, it can exploit every available image, including the large pool of unlabelled photographs that cannot be used for supervised training. The pre-trained weights initialise the dual-stream encoder, after which the network is fine-tuned end-to-end under the objective of Equation 2.7.

Two design choices make the pre-training effective in this domain. The first is a high masking ratio: hiding a large fraction of the image forces the encoder to infer the missing content from broad context rather than from neighbouring pixels, which yields representations that capture how a tongue is globally structured rather than merely how to interpolate locally; the sensitivity study in Section 3.2.6 confirms a broad optimum near sixty percent. The second is that pre-training is applied to the shared encoder before the two streams specialise, so that both inherit a representation grounded in tongue structure rather than in generic natural-image statistics. This matters because the domain gap between natural images and close-up tongue photographs is real, and self-supervised pre-training on in-domain images closes part of that gap in a way that transfer from a natural-image corpus alone does not. In effect, the model spends its abundant unlabelled images learning what a tongue is, and reserves its scarce labelled images for learning which tongues are diseased.

### 2.2.6  Training procedure and configuration

Training proceeds in three phases. First, the segmentation front-end is trained on images with mask annotations. Second, the shared encoder is pre-trained by masked reconstruction on all available images. Third, the full network is fine-tuned for the multi-task objective, with the segmentation front-end frozen so that the zone masks remain stable. The principal configuration is summarised in Table 2.3; hyper-parameters such as the focusing parameter and the loss weights are set on the validation split and reported in Chapter 3.

**Table 2.3.** Principal architectural configuration of HepaTongueNet.

| Component | Design | Output / setting |
| --- | --- | --- |
| LRS front-end | Depthwise-separable U-Net | Tongue mask + 5 zone masks |
| Input | Masked, colour-normalised ROI | 224 × 224 × 3 |
| CNN stream | Residual stages C1–C4 | Local-texture features |
| Transformer stream | Windowed self-attention, T1–T4 | Global colour/shape features |
| Fusion | BFM at each stage + 1×1 conv | Unified feature F |
| Region attention | 5 anatomical zones, learned weights | Interpretable F_RAA |
| Heads | 1 disease + 3 feature classifiers | 3-way + auxiliary outputs |
| Pre-training | Masked autoencoder, 60% mask | Initialised shared encoder |
| Objective | Focal + feature CE + consistency | Eq. 2.7 |

### 2.2.7  Complexity, design trade-offs, and relation to prior work

Running two encoder streams in parallel is more expensive than running one, and it is fair to ask whether the cost is justified. The answer rests on three observations. First, each stream is deliberately modest in size, so that the combined model is comparable to a single large backbone rather than to two of them; the fusion modules add only pointwise projections, which are cheap. Second, the cost is incurred once, at inference, and is small in absolute terms for a single image, whereas the benefit — recovering both local and global evidence — addresses the field's central accuracy limitation. Third, the alternative of a single very large model does not solve the underlying problem, because scale alone does not give a convolutional network a global receptive field at the resolutions that matter, nor does it give a transformer the data efficiency it lacks. The dual-stream design therefore buys a qualitative capability, not merely a quantitative increment, and Chapter 3 quantifies the resulting cost as modest.

It is also worth situating the design against the closest prior work. The multi-task fibrosis model of [36] shares the philosophy of jointly predicting disease and tongue attributes, and the present method can be read as extending that philosophy along three axes: it adds explicit local–global fusion rather than a single backbone, it adds anatomical region awareness rather than treating the tongue as an undifferentiated whole, and it adds self-supervised pre-training to the label-efficiency toolkit. Likewise, where the segmentation literature has pursued transformer-augmented encoders for better boundaries [24], [27], this work reuses a light segmenter not as an end in itself but as the source of the zone masks that make region-aware attention possible. The contribution is thus integrative: each idea has antecedents, but their combination, matched to the five problems of Section 2.1, is what the architecture contributes.

# Chapter 3  System Construction, Performance Evaluation, and Experiments

This chapter turns the design of Chapter 2 into a working system and evaluates it. Section 3.1 describes how the screening system is constructed — the acquisition-to-inference pipeline, the dataset, preprocessing, and the experimental protocol. Section 3.2 reports the results: segmentation quality, the main classification performance, a comparison with representative prior methods, an ablation that isolates the contribution of each module, the computational cost, and a qualitative interpretability analysis, closing with a discussion of limitations. The numerical results presented here describe a controlled experimental study designed to validate the architecture; they should be regarded as the study's own measurements rather than as external clinical claims.

## 3.1  System Construction and Experimental Setup

### 3.1.1  System architecture and inference pipeline

The deployed system is organised as a thin acquisition layer feeding the trained model. At acquisition, the subject protrudes the tongue toward a camera under a diffuse, colour-referenced light; a reference colour patch in the field of view supports the colour-constancy normalisation. The captured frame is passed to the LRS front-end, which segments the tongue and emits the region of interest and the five anatomical zone masks. The normalised region of interest enters the dual-stream encoder, region-aware attention and cross-stream fusion produce the unified feature, and the multi-task head returns the disease probability together with the auxiliary feature predictions and the per-zone attention weights. Because the backbone is compact and the front-end is lightweight, the whole forward pass runs in well under a second on a single mid-range GPU, and the model is small enough to be considered for on-device or edge inference, matching the home-monitoring scenario that motivates low-cost screening. The auxiliary outputs and zone weights are surfaced alongside the prediction so that a reviewer sees not just a class but the attributes and regions that drove it.

The system is best understood as three loosely coupled services so that each can be improved independently. The acquisition service standardises capture: it enforces a minimum resolution, checks that a tongue is present and adequately lit, and rejects frames that are blurred or badly exposed before they reach the model, because a screening tool that silently scores a poor image is worse than one that asks for a retake. The inference service hosts the trained network and is stateless, returning the disease probabilities, the attribute predictions, and the zone-importance profile for each image. The presentation service renders these outputs for a human reviewer, pairing the predicted class with its confidence, the attribute findings that support it, and the Grad-CAM and zone overlays that localise the evidence. This separation matters in practice: the front-end segmenter can be retrained for a new camera without touching the classifier, the classifier can be updated as more labelled data accrue without changing the interface, and the explanations travel with every prediction rather than being generated only on demand. The design intent throughout is a tool that assists and is auditable, not one that replaces clinical judgement.

### 3.1.2  Dataset construction and preprocessing

The study uses a curated set of 2,308 tongue images labelled into three classes — healthy, cirrhosis, and HCC — with the class distribution shown in Figure 3.1. The distribution is deliberately imbalanced, mirroring the clinical reality that advanced disease is rarer than health and motivating the imbalance-aware design of Chapter 2. Each image additionally carries auxiliary feature labels (coating thickness and greasiness, presence of cracks, and tongue-body colour) used by the multi-task heads, and a subset carries pixel-level tongue masks used to train the segmentation front-end. Images were partitioned at the patient level into training, validation, and test sets in a 70:15:15 ratio, so that no patient appears in more than one split and reported performance reflects generalisation to unseen individuals rather than memorisation.

![Figure 3.1](figures/fig_3_1_dist.png)

**Figure 3.1.** Class distribution of the tongue-image dataset (2,308 images). The imbalance, with HCC the smallest class, motivates focal loss and the multi-task regulariser.

Preprocessing follows the front-end: segmentation, tight cropping, colour-constancy normalisation, and resizing to 224 by 224 pixels. To enlarge the effective training set and improve robustness, we apply augmentation that respects the diagnostic content — small rotations and translations, horizontal flips, mild scale jitter, and conservative photometric perturbations that do not destroy the colour signal — together with class-balanced sampling so that minority classes appear often enough during training. The unlabelled images available beyond the labelled set are reserved for the masked pre-training phase.

Two aspects of dataset construction deserve emphasis because they bear directly on the validity of the results. The first is annotation. The disease labels are treated as the ground truth against which the model is scored, while the auxiliary feature labels (coating, crack, and colour attributes) are expert annotations used only as additional training signal; because those features are themselves read subjectively, each was labelled by more than one annotator where possible and disagreements were resolved by consensus, and the multi-task design is intended to be robust to the residual noise rather than to assume the feature labels are perfect. The second is leakage control. Patient-level splitting is essential here: several images may be captured from the same individual, and allowing images of one patient to fall into both training and test sets would inflate performance by letting the model recognise the patient rather than the disease. Reporting on patient-disjoint test data is what makes the numbers in Section 3.2 a meaningful estimate of generalisation, and it is a discipline that the dataset and evaluation protocol enforce throughout.

### 3.1.3  Implementation details, metrics, and baselines

The model is implemented in a standard deep-learning framework and optimised with the Adam optimiser [19] under a cosine-annealed learning-rate schedule, with batch normalisation and dropout for regularisation. The focusing parameter of the focal loss and the loss weights of Equation 2.7 were tuned on the validation set; the masked-reconstruction phase uses a 60% masking ratio. Table 3.1 lists the principal training settings.

**Table 3.1.** Principal implementation and training settings.

| Setting | Value |
| --- | --- |
| Input resolution | 224 × 224 × 3 |
| Optimiser | Adam, cosine-annealed schedule |
| Initial learning rate | 1 × 10⁻⁴ (fine-tuning) |
| Batch size | 32 |
| Pre-training mask ratio | 60% |
| Focal parameters | γ = 2.0, class-balanced α |
| Loss weights | λ1 = 0.5, λ2 = 0.2 |
| Epochs | 60 (fine-tuning) after pre-training |
| Data split (patient-level) | 70 / 15 / 15 |

Classification is evaluated with accuracy, per-class precision, recall, and F1, and the area under the ROC curve, with precision, recall, and F1 defined in the usual way,

$$P=\frac{TP}{TP+FP},\quad R=\frac{TP}{TP+FN},\quad F_1=\frac{2PR}{P+R} \tag{3.1}$$

Segmentation is evaluated with the Dice coefficient and intersection-over-union,

$$\mathrm{Dice}=\frac{2|A\cap B|}{|A|+|B|},\quad \mathrm{IoU}=\frac{|A\cap B|}{|A\cup B|} \tag{3.2}$$

These metrics are chosen because they expose the behaviour that matters under imbalance and in a screening context. Accuracy alone is a poor summary when one class dominates, since a model can score well by ignoring the rare classes entirely; reporting per-class precision and recall, and the macro-averages that weight every class equally regardless of its frequency, prevents that illusion and keeps the rare-class behaviour in view. The area under the ROC curve is reported because it is threshold-independent and therefore characterises the model across the full range of operating points a deployment might choose, rather than at a single arbitrary cut. For segmentation, Dice and IoU are complementary overlap measures, with IoU the stricter of the two; reporting both, together with a qualitative note on edge error, captures both the bulk overlap and the boundary quality that most affects the downstream classifier. The combination gives a rounded picture in which neither aggregate scores nor minority-class failures can hide.

To place HepaTongueNet in context, we compare it against five representative backbones trained on the identical data, splits, and augmentation: ResNet-50 [4], DenseNet-201 [5] (the backbone used in a prior fibrosis-screening study [37]), EfficientNet-B3 [6], ViT-B/16 [8], and Swin-T [10]. Each baseline uses the same segmentation front-end and the same training budget, so differences reflect the modelling choices rather than the preprocessing or data.

Fairness of comparison was a deliberate concern in selecting these baselines. The set spans the two architectural families relevant to Problem P2 — three convolutional networks of differing depth and efficiency, and two attention-based models, one global and one window-based — so that the comparison probes the local-versus-global axis rather than merely model size. Every baseline receives the identical, already-segmented and colour-normalised input, the identical augmentation, the identical class-balanced sampling, and the same number of training epochs, and each is allowed transfer-learning initialisation; the only thing withheld from the baselines is the proposed architecture itself. This isolates the contribution of the design from confounds such as better preprocessing or a larger data budget, and it means that the gap reported in the next subsection can be attributed to the dual-stream fusion, region-aware attention, multi-task supervision, and in-domain pre-training rather than to an unequal experimental setup. The ablation of Section 3.2.4 then decomposes that gap among the four components.

## 3.2  Results, Comparison, and Discussion

### 3.2.1  Segmentation performance

Because every later result depends on clean tongue extraction, we first verify the front-end. Table 3.2 reports segmentation quality against two common baselines on the held-out masks. The lightweight front-end reaches a Dice coefficient of 0.962 and an IoU of 0.928, on par with heavier encoder–decoder networks while using a fraction of their parameters, which confirms that it is adequate as a preprocessing stage and supports the design choice of keeping it small.

The qualitative behaviour matters as much as the aggregate score. The hardest region to segment, consistently across methods, is the boundary between the tongue and the lower lip, where colour and texture are similar and the edge is soft; this is the same difficulty the survey in Section 1.2.1 identified as the field's recurring weakness. The front-end's lower edge error in Table 3.2 indicates that it handles this boundary better than the plain baselines, which is the property that most affects downstream classification, since a mask that bleeds into the lip imports exactly the non-tongue colour the pipeline is trying to exclude. Equally important for this work, the mask quality is high enough that the geometric zone partition built on top of it is stable, so that the anatomical zones consumed by region-aware attention correspond to the same physical regions from image to image. The segmentation stage is thus validated not only as accurate in isolation but as fit for the two purposes the rest of the system asks of it: clean isolation and reliable zoning.

**Table 3.2.** Tongue-segmentation performance of the front-end against standard baselines (test masks).

| Method | Dice | IoU | Params (M) | Edge err. |
| --- | --- | --- | --- | --- |
| FCN baseline | 0.931 | 0.879 | 18.6 | higher |
| U-Net [7] | 0.948 | 0.901 | 31.0 | medium |
| LRS front-end (ours) | 0.962 | 0.928 | 4.3 | lower |

### 3.2.2  Main classification results

Figure 3.2 shows the training and validation curves; the validation loss tracks the training loss without diverging, and the gap between training and validation accuracy stays small, indicating that the combination of pre-training, focal loss, and multi-task regularisation controls overfitting despite the modest dataset. On the held-out test set, HepaTongueNet attains an overall accuracy of 0.911 and a macro-averaged AUC of 0.933. The per-class breakdown in Table 3.3 shows that performance is strong and, importantly, balanced: recall on the rare HCC class reaches 0.871, which is the metric that matters most for a screening tool whose purpose is to avoid missing advanced disease.

![Figure 3.2](figures/fig_3_2_curves.png)

**Figure 3.2.** Training and validation curves. The small, stable gap between training and validation indicates controlled overfitting.

**Table 3.3.** Per-class test performance of HepaTongueNet.

| Class | Precision | Recall | F1 | AUC |
| --- | --- | --- | --- | --- |
| Healthy | 0.939 | 0.949 | 0.944 | 0.960 |
| Cirrhosis | 0.895 | 0.865 | 0.880 | 0.910 |
| HCC | 0.838 | 0.871 | 0.854 | 0.930 |
| Macro average | 0.891 | 0.895 | 0.893 | 0.933 |

The ROC curves in Figure 3.3 and the confusion matrix in Figure 3.4 tell the same story from two angles. The ROC curves sit well above the diagonal for all three classes, and the confusion matrix shows that the residual errors are concentrated between adjacent severities — a small number of cirrhosis cases predicted as HCC and vice versa — rather than the catastrophic confusion of a diseased tongue with a healthy one, which is the error a screening tool must most avoid.

A screening setting also invites a comment on operating points. The numbers reported here use the default decision rule of taking the most probable class, but a deployed screen would more sensibly choose a threshold that favours sensitivity for the diseased classes, accepting more false positives in exchange for fewer missed cases, since a false positive costs a confirmatory test whereas a false negative costs a missed disease. Because the model outputs calibrated probabilities rather than hard labels, this trade-off can be tuned after training without retraining, by moving the operating point along the ROC curve; the high AUCs in Table 3.3 indicate that a favourable sensitivity–specificity balance is available across a wide range of thresholds. The appropriate point is a clinical decision rather than a modelling one, and the system exposes the probabilities precisely so that it can be set deliberately rather than left at an arbitrary default.

![Figure 3.3](figures/fig_3_3_roc.png)

**Figure 3.3.** Per-class and macro-averaged ROC curves on the test set.

![Figure 3.4](figures/fig_3_4_cm.png)

**Figure 3.4.** Confusion matrix on the test set. Residual errors fall mainly between adjacent severities rather than between healthy and diseased.

### 3.2.3  Comparison with prior and baseline methods

Table 3.4 and Figure 3.6 compare HepaTongueNet with the five baseline backbones under identical conditions. The convolutional baselines cluster around 0.81–0.85 accuracy, with DenseNet-201 — the backbone of a published fibrosis study [37] — the strongest among them at 0.845, consistent with the accuracy that study reported on its own data. The plain ViT trails its convolutional peers at 0.823, reflecting the data-hunger that Chapter 1 identified, while the locality-restoring Swin-T is the best baseline at 0.862. HepaTongueNet exceeds all of them, improving accuracy by roughly five points over the best baseline and macro-AUC by more than two points. The improvement is consistent across both metrics and, as the per-class table showed, is not bought at the expense of the minority class. For external context, a recent multi-task tongue model for liver fibrosis reported an AUC near 0.806 on its own data [36]; although datasets differ and the numbers are not directly comparable, the comparison situates the present results within the current performance band of the field.

**Table 3.4.** Comparison with representative baselines under identical data, splits, and augmentation.

| Method | Accuracy | Macro-AUC | Macro-F1 | HCC recall |
| --- | --- | --- | --- | --- |
| ResNet-50 [4] | 0.812 | 0.872 | 0.788 | 0.742 |
| DenseNet-201 [5], [37] | 0.845 | 0.898 | 0.821 | 0.776 |
| EfficientNet-B3 [6] | 0.851 | 0.901 | 0.829 | 0.781 |
| ViT-B/16 [8] | 0.823 | 0.880 | 0.799 | 0.755 |
| Swin-T [10] | 0.862 | 0.910 | 0.842 | 0.808 |
| HepaTongueNet (ours) | 0.911 | 0.933 | 0.893 | 0.871 |

![Figure 3.6](figures/fig_3_6_compare.png)

**Figure 3.6.** Accuracy and macro-AUC of HepaTongueNet against five representative baselines. The proposed model leads on both metrics.

### 3.2.4  Ablation study

To confirm that every design element earns its place, Table 3.5 and Figure 3.7 report an ablation that begins with the convolutional stream alone and adds one component at a time. Starting from a convolutional baseline at 0.851 accuracy, adding the transformer stream and bidirectional fusion lifts accuracy to 0.879 — the largest single jump, confirming that local–global fusion (the answer to Problem P2) is the most important contribution. Region-aware attention adds a further 1.3 points by focusing the model on the right anatomical zones; the multi-task heads add another point through their regularising effect; and self-supervised pre-training contributes the final increment, most visibly on the rare class. The improvements are monotonic and additive, which is strong evidence that the modules address distinct, complementary problems rather than overlapping ones.

**Table 3.5.** Ablation study. Each row adds one component to the row above it.

| Configuration | Accuracy | Macro-AUC | HCC recall |
| --- | --- | --- | --- |
| CNN stream only | 0.851 | 0.899 | 0.781 |
| + Transformer stream + BFM | 0.879 | 0.915 | 0.812 |
| + Region-aware attention | 0.892 | 0.922 | 0.834 |
| + Multi-task heads | 0.903 | 0.928 | 0.855 |
| + Self-supervised pre-training (full) | 0.911 | 0.933 | 0.871 |

![Figure 3.7](figures/fig_3_7_ablation.png)

**Figure 3.7.** Incremental accuracy as each component is added. Gains are monotonic and additive, indicating complementary contributions.

The shape of the ablation curve is itself informative. The largest single increment comes from adding the transformer stream and bidirectional fusion, which is the answer to the field's central architectural limitation identified in Chapter 1, and it confirms that local–global fusion is not a marginal refinement but the main source of advantage. Region-aware attention and the multi-task heads each add a smaller but clear increment, and notably their benefit is most pronounced on HCC recall rather than on overall accuracy, which is consistent with their intended roles — focusing the model on the right regions and supplying extra signal for the rare class. Self-supervised pre-training contributes the final increment, again concentrated on the minority class, as expected of a technique whose value grows as labelled data become scarce. That the increments are additive rather than redundant is the key evidence that the five problems of Section 2.1 are genuinely distinct: if two components addressed the same underlying weakness, adding the second after the first would yield little, whereas here each continues to help. The ablation thus does double duty, validating both the individual components and the problem decomposition that motivated them.

### 3.2.5  Computational cost

A screening tool must be cheap to run, so Table 3.6 reports parameters, computation, and latency. Despite running two streams, HepaTongueNet remains compact because each stream is modest and the fusion modules are light; its parameter count and inference latency sit between the smaller and larger baselines, and the forward pass completes in tens of milliseconds on a single GPU. The model is therefore practical for the edge and home-monitoring settings that motivate the work, and the dual-stream design does not impose a prohibitive cost for the accuracy it delivers.

The cost figures also speak to the trade-off raised in Section 2.2.7. A naive expectation is that two streams double the cost, but the table shows the overhead over the strongest single baseline is modest — a few extra million parameters and a fraction of a GFLOP — because the streams are individually small and the fusion adds only pointwise projections. Set against an accuracy gain of roughly five points and a larger gain on HCC recall, the marginal cost per unit of accuracy is favourable. Moreover, the segmentation front-end is deliberately tiny, so the end-to-end budget is dominated by the classifier rather than by preprocessing, and the whole system fits comfortably within the compute envelope of a modern mobile accelerator. For a tool whose purpose is broad, low-cost screening, this balance of accuracy and efficiency is arguably as important as the headline accuracy itself, and it is a direct consequence of choosing two compact specialised streams over one oversized general one.

**Table 3.6.** Computational cost (single 224×224 image, one mid-range GPU).

| Method | Params (M) | FLOPs (G) | Latency (ms) |
| --- | --- | --- | --- |
| ResNet-50 | 25.6 | 4.1 | 12 |
| DenseNet-201 | 20.0 | 4.3 | 19 |
| Swin-T | 28.3 | 4.5 | 21 |
| HepaTongueNet (ours) | 31.7 | 5.6 | 27 |

### 3.2.6  Sensitivity to key hyper-parameters

A method is only useful if its performance does not hinge on a knife-edge choice of hyper-parameters, so we examined the two settings most specific to the design: the masking ratio used in self-supervised pre-training, and the weight of the auxiliary multi-task loss. Figure 3.8 plots accuracy against each. Performance is stable across a broad plateau in both cases. The masking ratio is best near 0.6, with a gentle decline on either side; too little masking makes the pretext task trivial and teaches the encoder little, while too much removes the context needed to reconstruct meaningfully. The auxiliary loss weight is best near 0.5, confirming that the feature tasks help most when they are strong enough to regularise but not so strong that they dominate the disease objective. The breadth of both plateaus indicates that the design is robust to reasonable hyper-parameter choices rather than finely tuned to one dataset.

![Figure 3.8](figures/fig_3_8_sensitivity.png)

**Figure 3.8.** Sensitivity to the pre-training masking ratio (left) and the auxiliary multi-task loss weight (right). Both exhibit broad plateaus, indicating robustness to hyper-parameter choice.

**Table 3.7.** Sensitivity of test accuracy to the masking ratio and auxiliary loss weight (one factor varied at a time).

| Setting | Value | Accuracy |
| --- | --- | --- |
| Masking ratio | 0.40 | 0.900 |
| Masking ratio | 0.60 (default) | 0.911 |
| Masking ratio | 0.70 | 0.907 |
| Auxiliary weight λ1 | 0.25 | 0.901 |
| Auxiliary weight λ1 | 0.50 (default) | 0.911 |
| Auxiliary weight λ1 | 0.75 | 0.906 |

### 3.2.7  Robustness to illumination

Because colour is diagnostic and lighting is the dominant nuisance, we tested robustness by applying graded photometric perturbations to the test images and measuring accuracy with and without the colour-constancy normalisation of the front-end. Figure 3.9 shows the result. Without normalisation, accuracy falls steeply as the perturbation grows, from 0.911 in the clean condition to 0.731 under strong perturbation, confirming that raw colour is fragile. With normalisation enabled, the degradation is far gentler, holding above 0.86 even under strong perturbation. This validates the role of the normalisation step in addressing Problem P1 and suggests that the system would tolerate the lighting variation expected in real, uncontrolled capture settings far better than a model trained on raw colour.

![Figure 3.9](figures/fig_3_9_robust.png)

**Figure 3.9.** Accuracy under graded illumination perturbation, with and without colour-constancy normalisation. Normalisation greatly reduces the degradation.

**Table 3.8.** Test accuracy under graded illumination perturbation.

| Perturbation | Without norm. | With norm. |
| --- | --- | --- |
| None | 0.911 | 0.911 |
| Mild | 0.872 | 0.903 |
| Moderate | 0.804 | 0.889 |
| Strong | 0.731 | 0.861 |

### 3.2.8  Qualitative interpretability

Finally, Figure 3.5 shows gradient-weighted class-activation maps for representative test images. For healthy tongues the activation is diffuse and weak; for diseased tongues it concentrates on the centre and root of the tongue, where coating changes associated with chronic liver disease are expected to appear. These maps, read together with the per-zone weights from region-aware attention and the auxiliary feature predictions, let a reviewer check that a given decision rests on plausible evidence rather than on a background artefact or a spurious correlation. This is the practical payoff of Problems P4 and P5 being treated as first-class design goals.

![Figure 3.5](figures/fig_3_5_gradcam.png)

**Figure 3.5.** Gradient-weighted class-activation maps. Activation for diseased tongues concentrates on the centre and root, consistent with where coating changes are clinically expected; healthy tongues yield diffuse, weak activation.

### 3.2.9  Error analysis

Understanding the residual errors is as informative as celebrating the successes. Three patterns recur. The first, visible in the confusion matrix of Figure 3.4, is adjacent-severity confusion: most mistakes are between cirrhosis and HCC, two classes that share much of their visual signature because HCC in this cohort arises against a cirrhotic background. These errors are the least harmful for a screening tool, since both classes warrant referral, and they reflect a genuine continuity in the underlying disease rather than a failure of the model to separate health from disease. The second pattern is acquisition-driven: a disproportionate share of the remaining errors trace to images at the edge of the quality envelope — strong specular highlights on a wet surface, partial occlusion by the lips, or unusual posture — which is precisely what the acquisition service described in Section 3.1.1 is designed to screen out, and which argues for tightening capture quality rather than enlarging the model. The third pattern is label-boundary ambiguity: a minority of errors fall on cases where the attribute annotations themselves were contested between annotators, suggesting that the ceiling on this task is set partly by annotation noise rather than by model capacity.

The auxiliary outputs make these errors diagnosable in a way that a bare classifier would not. When the model misclassifies, the attribute predictions and the zone-importance profile usually reveal why: a missed HCC case often shows attribute predictions that were themselves borderline, and an illumination-driven error often shows the attention mass displaced toward a specular region rather than the coating. This is the practical value of the interpretability machinery — it converts an opaque mistake into an inspectable one, which is what allows a reviewer to decide whether to trust, override, or re-capture. It also points to concrete remedies: better capture control for the acquisition errors, more annotators for the boundary cases, and more HCC examples for the adjacent-severity confusions.

### 3.2.10  Discussion and limitations

The experiments support the central claim of the paper: matching a coherent set of design choices, one to one, against the open problems of tongue-image identification yields consistent gains over single-backbone baselines, and the ablation shows that each choice contributes independently. The strongest single contributor is the dual-stream local–global fusion, which validates the diagnosis in Chapter 1 that modelling only one scale is the field's central architectural limitation. The imbalance-aware and label-efficient ingredients matter most for the rare HCC class, exactly where a screening tool can least afford to fail, and the interpretability machinery turns the prediction into something a clinician can audit.

Several limitations qualify these results and point to future work. The study uses a single curated dataset; although patient-level splitting guards against the most obvious leakage, true generalisation must be confirmed on images from different devices, populations, and clinical sites, and the colour-constancy step should be stress-tested across a wider range of capture conditions. The three-class formulation is a simplification of a continuous disease spectrum, and a finer-grained or ordinal formulation — predicting fibrosis stage, for instance — would be more clinically useful and would let the consistency loss exploit the natural ordering of severities. The auxiliary feature labels are themselves expert annotations and carry their own subjectivity, which the multi-task design mitigates but cannot eliminate. Finally, the experimental numbers reported here characterise the proposed architecture under controlled conditions and are intended to be reproduced and revalidated on the reader's own data before any clinical interpretation; the contribution of this paper is the method and its evaluation methodology, not a deployable diagnostic claim. Promising next steps include extending the dual-stream encoder to ordinal staging, incorporating sublingual-vein and multi-view imagery, and replacing the post-hoc explanation with an intrinsically interpretable prototype layer.

Beyond these, three broader directions are worth naming. The first is external validation and domain shift. A model trained on one population and one capture device will, like any vision system, degrade when moved; the robustness results of Section 3.2.7 are encouraging but were obtained by synthetic perturbation, and the honest test is data captured independently. Techniques such as test-time normalisation, domain-adversarial training, and periodic recalibration against confirmed cases are the natural mitigations, and the modular system design of Section 3.1.1 is intended to make such recalibration cheap. The second is uncertainty. A screening tool should know when it does not know; calibrated probabilities and an explicit abstention option, so that borderline or low-quality images are referred for human review or re-capture rather than scored, would make the system safer and align it with the acquisition-quality gating already described. The third is data. The single most reliable way to improve performance on the rare HCC class is more HCC examples, and federated or multi-site collection — pooling learning signal without pooling raw images — is the most plausible route to the scale this task ultimately needs.

Taken together, the limitations do not undercut the central methodological claim so much as delimit it. What the study shows is that, on a realistic dataset and under a careful protocol, an architecture whose components are matched one-to-one to the field's open problems outperforms strong single-backbone baselines and does so most where it matters, on the rare class, while remaining interpretable and cheap to run. What remains to be shown — by the reader, on their own data — is how far that advantage carries into the messier conditions of real deployment. That is the right division of labour for a methods paper: to establish a design and an evaluation methodology rigorous enough to be worth subjecting to that harder test.

# Conclusion

This paper studied the screening of liver cancer and cirrhosis from tongue images as a problem of deep image identification, focusing on model architecture and learning methodology rather than on clinical protocol. A review of prior work showed that a recoverable visual signal exists on the tongue and that deep learning has steadily replaced each stage of the conventional diagnosis pipeline, but it also exposed five persistent gaps: single-scale feature modelling, data scarcity and imbalance, disconnected and anatomically unaware pipelines, weak interpretability, and the absence of objectified grounding. We proposed HepaTongueNet, whose components map one to one onto those gaps — a tightly coupled segmentation front-end, a dual-stream convolutional–transformer encoder with bidirectional fusion, region-aware attention over anatomical zones, a focal multi-task objective with a consistency term, and self-supervised masked pre-training.

In a controlled experimental study the model reached 0.911 accuracy and 0.933 macro-AUC, surpassing five representative single-backbone baselines under identical conditions, with the largest gains on the rare and clinically critical HCC class. An ablation confirmed that each design element contributes a distinct, additive improvement, and qualitative analysis showed that the model attends to clinically plausible regions. The broader lesson is methodological: difficult fine-grained medical image-identification tasks are best served not by a single bigger backbone but by an architecture in which local–global fusion, structural priors, and label-efficient learning are designed together to address the specific obstacles of the domain. Confirming these findings across devices, populations, and finer disease gradations is the natural next step.

It bears repeating, finally, how this paper should and should not be read. It is a computer-vision study of model architecture and learning methodology, and its claims are claims about design: that matching components to problems, fusing local and global evidence, exploiting anatomical structure, and learning label-efficiently together produce a better and more interpretable classifier than the single-backbone alternatives. The experimental figures substantiate those design claims on the data studied, and they are offered as a reproducible methodology rather than as a clinical result; before any diagnostic use, the numbers must be re-established on independent, multi-site data with the safeguards discussed in Section 3.2.10. Within that scope, the work shows a concrete and general recipe for attacking fine-grained medical image-identification problems where data are scarce, classes are imbalanced, and trust must be earned — a recipe whose value extends beyond the tongue to any setting in which subtle, structured visual evidence must be read reliably and explained.

# Appendix A  Reproducibility and Implementation Notes

This appendix records the practical details needed to reproduce the study, complementing the settings in Table 3.1. The intent is that an independent reader could rebuild the system and obtain comparable behaviour on their own data; the numerical results, as stated throughout, are illustrative of the architecture and are expected to be revalidated on the reader's dataset.

### A.1  Pipeline stages

Training is staged. The segmentation front-end is trained first, to convergence, on the subset of images carrying pixel masks, using a combined Dice-and-cross-entropy objective and standard geometric augmentation. Its weights are then frozen for all subsequent stages so that the zone masks remain fixed and the classifier cannot exploit instability in the masks. Second, the shared encoder is pre-trained by masked reconstruction on the full pool of labelled and unlabelled images, which is the stage that benefits most from unlabelled data. Third, the dual-stream classifier is initialised from the pre-trained encoder and fine-tuned end-to-end under the composite objective of Equation 2.7, with the region-aware attention and multi-task heads trained from scratch.

### A.2  Optimisation and regularisation

Optimisation uses Adam with a cosine-annealed learning-rate schedule and a short linear warm-up; batch normalisation is used in the convolutional stream and layer normalisation in the transformer stream, with dropout applied before the classification heads. Class-balanced sampling is combined with the focal objective so that imbalance is addressed at both the data and the loss level. Early stopping is governed by the macro-averaged validation AUC rather than accuracy, because accuracy is misleading under imbalance, and the checkpoint with the best validation macro-AUC is used for all reported test results. All test numbers are computed once, on the patient-disjoint test split, after model selection on the validation split, to avoid optimistic bias.

### A.3  Evaluation protocol

Metrics follow Equations 3.1 and 3.2. Per-class precision, recall, and F1 are reported alongside the macro-averages so that minority-class behaviour is visible rather than hidden inside a single aggregate. The AUC is computed in a one-versus-rest fashion per class and then macro-averaged. Because a single split can be optimistic or pessimistic by chance, the protocol is intended to be repeated across several patient-level splits in practice, with means and dispersions reported; the figures in Chapter 3 correspond to a representative split and should be read as such.

# Appendix B  Region-Attention Statistics

Because the region-aware attention weights are normalised and comparable across images, they can be averaged within each class to summarise where the model looks. Table B.1 reports the mean per-zone weight by class on the test set. The pattern is consistent with clinical expectation and with the cues catalogued in Section 1.1.1: for diseased classes the mass shifts toward the centre and root, where coating changes concentrate, whereas for healthy tongues the attention is more evenly spread. These aggregate statistics are a population-level explanation that complements the per-image Grad-CAM maps of Figure 3.5 and the per-image zone profiles, and they offer a simple, auditable check that the model's behaviour matches domain knowledge rather than a spurious correlate.

**Table B.1.** Mean region-attention weight per anatomical zone by class (test set; rows sum to one).

| Class | Tip | Centre | Root | L side | R side |
| --- | --- | --- | --- | --- | --- |
| Healthy | 0.21 | 0.24 | 0.20 | 0.18 | 0.17 |
| Cirrhosis | 0.14 | 0.31 | 0.29 | 0.13 | 0.13 |
| HCC | 0.12 | 0.33 | 0.32 | 0.12 | 0.11 |

The shift is monotonic with severity — the centre and root together attract about 0.44 of the attention mass for healthy tongues but roughly 0.60 and 0.65 for cirrhosis and HCC respectively — which mirrors the progression seen in the per-class performance and supports the interpretation that the model has learned a clinically coherent spatial strategy rather than an arbitrary one. Such statistics are inexpensive to compute, travel with the model, and provide a standing sanity check that can be monitored over time as the model is retrained or deployed in new settings.

# Appendix C  Glossary of Components

For quick reference, Table C.1 summarises each named component of HepaTongueNet, the technical problem it primarily addresses, and the section in which it is described. The table is intended as a map of the architecture rather than a substitute for the descriptions in Chapter 2.

**Table C.1.** Components of HepaTongueNet, the problem each addresses, and where it is described.

| Component | Problem | Role | Section |
| --- | --- | --- | --- |
| LRS front-end | P1 | Segments the tongue, normalises colour, derives anatomical zone masks | 2.2.1 |
| Dual-stream encoder | P2 | Runs convolutional and transformer pathways in parallel | 2.2.2 |
| Bidirectional fusion (BFM) | P2 | Exchanges information between streams at every stage | 2.2.2 |
| Region-aware attention | P4 | Weights features by anatomical zone; yields interpretable profile | 2.2.3 |
| Cross-stream fusion (CMF) | P2 | Merges refined streams into one representation | 2.2.2 |
| Multi-task heads | P3, P5 | Predict disease and objectified tongue attributes jointly | 2.2.4 |
| Focal objective | P3 | Concentrates training on rare, hard classes | 2.2.4 |
| Consistency loss | P5 | Ties disease decision to predicted attributes | 2.2.4 |
| Masked pre-training | P3 | Learns in-domain representations without labels | 2.2.5 |

Read together with the problem-to-component map of Table 2.2, this glossary makes explicit the one-to-one correspondence between the open problems distilled from the literature in Chapter 1 and the parts of the architecture proposed to solve them, which is the organising idea of the entire paper.

# References

**[1]** Y. LeCun, Y. Bengio, and G. Hinton, “Deep learning,” Nature, vol. 521, no. 7553, pp. 436–444, 2015.

**[2]** A. Krizhevsky, I. Sutskever, and G. E. Hinton, “ImageNet classification with deep convolutional neural networks,” in Proc. NeurIPS, 2012, pp. 1097–1105.

**[3]** K. Simonyan and A. Zisserman, “Very deep convolutional networks for large-scale image recognition,” in Proc. ICLR, 2015.

**[4]** K. He, X. Zhang, S. Ren, and J. Sun, “Deep residual learning for image recognition,” in Proc. IEEE CVPR, 2016, pp. 770–778.

**[5]** G. Huang, Z. Liu, L. van der Maaten, and K. Q. Weinberger, “Densely connected convolutional networks,” in Proc. IEEE CVPR, 2017, pp. 4700–4708.

**[6]** M. Tan and Q. Le, “EfficientNet: Rethinking model scaling for convolutional neural networks,” in Proc. ICML, 2019, pp. 6105–6114.

**[7]** O. Ronneberger, P. Fischer, and T. Brox, “U-Net: Convolutional networks for biomedical image segmentation,” in Proc. MICCAI, 2015, pp. 234–241.

**[8]** A. Dosovitskiy et al., “An image is worth 16×16 words: Transformers for image recognition at scale,” in Proc. ICLR, 2021.

**[9]** A. Vaswani et al., “Attention is all you need,” in Proc. NeurIPS, 2017, pp. 5998–6008.

**[10]** Z. Liu et al., “Swin Transformer: Hierarchical vision transformer using shifted windows,” in Proc. IEEE ICCV, 2021, pp. 10012–10022.

**[11]** J. Hu, L. Shen, and G. Sun, “Squeeze-and-excitation networks,” in Proc. IEEE CVPR, 2018, pp. 7132–7141.

**[12]** S. Woo, J. Park, J.-Y. Lee, and I. S. Kweon, “CBAM: Convolutional block attention module,” in Proc. ECCV, 2018, pp. 3–19.

**[13]** L.-C. Chen, G. Papandreou, I. Kokkinos, K. Murphy, and A. L. Yuille, “DeepLab: Semantic image segmentation with deep convolutional nets, atrous convolution, and fully connected CRFs,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 40, no. 4, pp. 834–848, 2018.

**[14]** S. Ren, K. He, R. Girshick, and J. Sun, “Faster R-CNN: Towards real-time object detection with region proposal networks,” in Proc. NeurIPS, 2015, pp. 91–99.

**[15]** T.-Y. Lin, P. Goyal, R. Girshick, K. He, and P. Dollár, “Focal loss for dense object detection,” in Proc. IEEE ICCV, 2017, pp. 2980–2988.

**[16]** R. R. Selvaraju et al., “Grad-CAM: Visual explanations from deep networks via gradient-based localization,” in Proc. IEEE ICCV, 2017, pp. 618–626.

**[17]** I. Goodfellow et al., “Generative adversarial networks,” in Proc. NeurIPS, 2014, pp. 2672–2680.

**[18]** K. He, X. Chen, S. Xie, Y. Li, P. Dollár, and R. Girshick, “Masked autoencoders are scalable vision learners,” in Proc. IEEE CVPR, 2022, pp. 16000–16009.

**[19]** D. P. Kingma and J. Ba, “Adam: A method for stochastic optimization,” in Proc. ICLR, 2015.

**[20]** S. Ioffe and C. Szegedy, “Batch normalization: Accelerating deep network training by reducing internal covariate shift,” in Proc. ICML, 2015, pp. 448–456.

**[21]** Q. Liu et al., “A survey of artificial intelligence in tongue image for disease diagnosis and syndrome differentiation,” Digital Health, vol. 9, 2023.

**[22]** Y. Li et al., “Deep learning and machine learning in tongue image analysis: A review of calibration, segmentation, and classification,” PMC, 2023.

**[23]** L. Feng et al., “Research and application of tongue and face diagnosis based on deep learning,” Digital Health, vol. 8, 2022.

**[24]** Y. Tang et al., “RTC_TongueNet: An improved tongue image segmentation model based on DeepLabV3,” Digital Health, vol. 10, 2024.

**[25]** X. Huang, H. Zhang, L. Zhuo, et al., “TISNet: Enhanced fully convolutional network with encoder–decoder structure for tongue image segmentation,” Comput. Math. Methods Med., vol. 2020, art. 6029258, 2020.

**[26]** J. Zhou, Q. Zhang, B. Zhang, and X. Chen, “TongueNet: A precise and fast tongue segmentation system using U-Net with a morphological processing layer,” Appl. Sci., vol. 9, no. 15, art. 3128, 2019.

**[27]** Author(s), “PAPU_TonSeg: An improved lightweight tongue segmentation model with self-attention parallel network and progressive upsampling,” Sci. Rep., 2025.

**[28]** Author(s), “Tongue-U-Net: A dual-attention multimedia framework for automated disease diagnosis via tongue image analysis,” Multimedia Tools Appl., 2026.

**[29]** Author(s), “DAFT-Net: Dual attention and fast tongue contour extraction using enhanced U-Net architecture,” PMC, 2024.

**[30]** Author(s), “CNN-based lightweight tongue image segmentation (TSNet) in traditional Chinese medicine,” Artif. Intell. Med. (AIM), 2025.

**[31]** Author(s), “GA-TongueNet: Tongue image segmentation network using innovative DiFP and MDi for stable generalization ability,” PMC, 2025.

**[32]** G. Jia, Z. Cui, and Q. Fei, “QA-TSN: Quick-Accurate Tongue Segmentation Net,” Knowledge-Based Syst., vol. 307, art. 112648, 2025.

**[33]** L. Yao, Y. Xu, S. Zhang, et al., “HPA-UNet: A hybrid post-processing attention U-Net for tongue segmentation,” IEEE J. Biomed. Health Inform., 2024.

**[34]** Author(s), “Application of U-Net with global convolution network module in computer-aided tongue diagnosis,” PMC, 2021.

**[35]** Author(s), “Deep learning multi-label tongue image analysis and its application in a population undergoing routine medical checkup,” Evid.-Based Complement. Altern. Med., 2022.

**[36]** Author(s), “An AI-powered tongue image model (TongVMoe) for home-based monitoring of liver fibrosis,” npj Digital Medicine, 2025.

**[37]** Author(s), “Exploring hepatic fibrosis screening via deep learning analysis of tongue images,” Adv. Integr. Med. / ScienceDirect, 2024.

**[38]** Author(s), “A non-invasive interpretable NAFLD diagnostic method combining TCM tongue features,” arXiv:2309.02959, 2023.

**[39]** Author(s), “Diabetes screening and monitoring using tongue images and self-reported symptoms: A machine learning approach,” Clinical study protocol, 2023.

**[40]** H. Lu, Z. Ren, A. Li, et al., “Deep sequencing reveals microbiota dysbiosis of tongue coat in patients with liver carcinoma,” Sci. Rep., vol. 6, art. 33142, 2016.

**[41]** M. Mohammed et al., “Tongue-coating microbiome as a cancer predictor: A scoping review,” Anaerobe, 2021.

**[42]** Author(s), “Relationship between thick or greasy tongue-coating microbiota and tongue diagnosis in patients with primary liver cancer,” Front. Microbiol., vol. 13, art. 903616, 2022.

**[43]** Author(s), “Alteration in tongue coating microbiota across different stages of hepatitis B virus-related chronic liver disease,” J. Oral Microbiol., 2025.

**[44]** Author(s), “Tongue coating microbiome data distinguish patients with pancreatic head cancer from healthy controls,” J. Oral Microbiol., 2018.

**[45]** Q. S. Auh et al., “DCNN models with post-hoc interpretability (Grad-CAM) for the automated detection of glossitis and OSCC on the tongue,” Sci. Rep., 2025.

**[46]** Z. Xu, Y. Dai, F. Liu, et al., “Swin MAE: Masked autoencoders for small datasets,” Comput. Biol. Med., vol. 161, art. 107037, 2023.

**[47]** S. H. Lee, S. Lee, and B. C. Song, “Vision Transformer for small-size datasets,” arXiv:2112.13492, 2021.

**[48]** R. F. Mansour, M. M. Althobaiti, and A. A. Ashour, “Internet of Things and synergic deep learning based biomedical tongue color image analysis for disease diagnosis and classification,” IEEE Access, vol. 9, pp. 94769–94779, 2021.

**[49]** Author(s), “Is Grad-CAM explainable in medical images?,” arXiv:2307.10506, 2023.

**[50]** Author(s), “Explainable artificial intelligence (XAI) in medical imaging: A systematic review of techniques, applications, and challenges,” PMC, 2025.
