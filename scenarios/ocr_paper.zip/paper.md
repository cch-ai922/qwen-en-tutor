---
title: "Efficient On-Device Text-Line Character Recognition via Hidden-Level Knowledge Distillation and Sensitivity-Aware 4-Bit Quantization"
author: "—"
date: "2026"
---

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

## Abstract {.unnumbered}

Optical character recognition (OCR) on mobile phones has become a core building block for document capture, translation, accessibility, and augmented reality. However, the most accurate text-line recognition models are convolution–transformer hybrids whose parameter counts and memory footprints exceed what is comfortable for on-device, offline inference. This thesis presents a complete and reproducible recipe for shrinking such a model to a size and latency suitable for a mid-range smartphone while losing as little accuracy as possible.

The approach has three stages. First, a high-capacity *teacher* and a compact *student* are built from the **same** architectural family—a DenseNet feature extractor, a Vision-Transformer (ViT) encoder, and a Connectionist-Temporal-Classification (CTC) decoder—so that their internal representations are directly comparable. Second, the teacher transfers knowledge to the student through **hidden-level knowledge distillation**. Within this stage we introduce two clearly delimited improvements: (i) a *CTC-confidence-weighted* hidden-state loss that concentrates the transfer on the frames that actually carry characters rather than the many "blank" frames produced by CTC, and (ii) a *multi-stage adaptive hidden-alignment* scheme that matches teacher and student at several depths through lightweight, normalization-equipped projectors. Third, the distilled student is compressed to **4-bit weights**. Here too we add two improvements: (i) *sensitivity-aware mixed-precision* quantization that keeps a small number of demonstrably fragile layers at 8-bit while quantizing the bulk of the network to group-wise 4-bit, and (ii) *quantization-aware knowledge distillation* (QA-KD) that reuses the full-precision student as a self-teacher to recover the accuracy lost to rounding.

On a suite of six standard scene-text benchmarks, the teacher reaches 93.1% average word accuracy. The compact student recovers 90.8% with distillation—4.0 points above an identically sized model trained from labels alone—and the final 4-bit model retains 89.8%, only 1.0 point below the full-precision student, versus a 5.4-point drop for naive 4-bit post-training quantization. The deployed model occupies 2.7 MB, runs a text line in 18.5 ms, and peaks at 31 MB of memory on a mid-range mobile SoC. The contribution of this thesis is not a single new operator but a carefully reasoned, end-to-end framework in which each of the four improvements is motivated, isolated, and measured.

**Keywords:** on-device OCR, text-line recognition, knowledge distillation, feature distillation, network quantization, 4-bit quantization, CTC, Vision Transformer, model compression.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Chapter 1. Introduction and Analysis of Prior Research

## 1.1 Background and motivation

Reading text from images is one of the oldest and most widely deployed applications of pattern recognition. Modern phones use it to digitize receipts, translate menus and signs in real time, narrate documents for visually impaired users, index photographs by their textual content, and drive a growing class of "scan-and-act" features. Two properties make the mobile setting distinctive. First, the recognition must frequently run **offline**: a traveler photographing a sign in a foreign country, or a user scanning a sensitive document, cannot or should not depend on a server round-trip. Second, the inference budget is severe. A foreground feature competing for the same battery, thermal envelope, and memory as the camera pipeline and the rest of the operating system cannot afford a hundred-megabyte model or a multi-hundred-millisecond latency per text line.

The accuracy of text recognition has advanced dramatically over the last decade, driven by the same architectural progression that reshaped computer vision as a whole: from early convolutional networks [1; 2; 3], through residual [4] and densely connected [5] backbones, to the attention-based Transformer [6] and its vision variant, the Vision Transformer (ViT) [7]. In text recognition specifically, the decisive idea was to treat a cropped text line as a *sequence* and to learn the alignment between image columns and output characters automatically, rather than segmenting characters by hand. Connectionist Temporal Classification (CTC) [8] provided exactly this alignment-free training signal, and the convolutional-recurrent network CRNN [9] popularized the recipe that still underlies most production systems: a convolutional feature extractor, a sequence model, and a CTC (or attention) decoder.

It is worth recalling how far the problem has travelled, because the history explains why modern recognizers are shaped the way they are. Classical optical character recognition operated on clean, high-contrast documents and proceeded in explicit stages: binarize the page, segment it into lines, segment each line into individual characters, normalize each character, extract hand-engineered features (projection profiles, zoning, structural strokes), and classify each glyph independently with a template matcher or a shallow classifier. This pipeline worked well on scanned print but broke down on *scene* text—photographs of signs, packaging, and handwriting—where lighting, perspective, font variety, and background clutter make reliable character segmentation effectively impossible. The crucial conceptual shift was to abandon explicit character segmentation altogether and to recognize the line *holistically as a sequence*, letting the model learn where characters begin and end as a by-product of learning to read. This is the shift that CTC [8] formalized and that CRNN [9] turned into a practical, end-to-end-trainable system, and every recognizer discussed in this thesis is a descendant of it.

The difficulty is that the architectural choices that maximize accuracy—deeper backbones, wider transformers, attention-based decoders with language modeling—also maximize cost. The strongest published recognizers carry tens of millions of parameters and assume a server-class accelerator. Closing the gap between *what is most accurate* and *what fits on a phone* is the problem this thesis addresses. The gap is not small: a difference between a 90-MB model that answers in a few hundred milliseconds on a datacenter GPU and a 3-MB model that must answer in tens of milliseconds on a battery-powered NPU is roughly two orders of magnitude in both storage and compute, and it cannot be bridged by any single trick. It requires a coordinated strategy that addresses representation quality and numerical precision at the same time, which is the organizing principle of this work.

![Accuracy versus parameter count for representative text-recognition models. Stronger models cluster toward the upper right (more parameters). The goal of this work is a model that sits in the upper left: small enough for a phone, accurate enough to be useful. Reported figures are representative values drawn from the literature and from our own measurements; see Chapter 3 for the exact protocol.](figures/fig_pareto.png){width=78%}

## 1.2 The on-device recognition problem

A model that is merely "small" is not automatically deployable. On-device deployment imposes four coupled constraints that a desktop benchmark hides:

1. **Storage and download size.** Application bundles are size-sensitive; users abandon large downloads, and app stores penalize them. A recognizer competing for space with everything else in an app should occupy a few megabytes, not tens.
2. **Working memory.** Peak runtime memory, not just model size, determines whether a model can run alongside the camera buffer without being evicted. Activations during a forward pass can dominate the weight footprint.
3. **Latency.** Interactive use—live translation overlays, viewfinder text capture—demands tens of milliseconds per line, not hundreds, so that several lines can be processed within a single video frame budget.
4. **Energy and heat.** Sustained inference must not drain the battery or trigger thermal throttling, which would in turn degrade latency.

These constraints cannot be satisfied by training a smaller model from scratch and hoping for the best: small models trained on labels alone consistently underperform, because they lack the inductive guidance that a larger model's learned representation provides. Nor can they be satisfied by compression alone applied to a large model without care, because aggressive low-bit quantization of a model not prepared for it collapses accuracy. The central thesis of this work is that the two techniques—**knowledge distillation** to make a small model *learn well*, and **low-bit quantization** to make it *run cheaply*—must be designed together, around a shared architecture, to reach the upper-left corner of Figure 1.1.

## 1.3 Analysis of prior research

This section reviews the three bodies of work this thesis builds on—recognition architectures, knowledge distillation, and quantization—and identifies the specific gaps the proposed method targets.

### 1.3.1 Text-line recognition architectures

Early deep recognizers paired a convolutional backbone with a recurrent sequence model and a CTC decoder; CRNN [9] is the canonical example and remains a strong, lightweight baseline. To handle curved and perspective-distorted text, *rectification* front-ends were introduced: RARE [10] and its successor ASTER [11] learn a thin-plate-spline transformation that straightens the line before recognition. A parallel line of work replaced CTC with **attention decoders** that emit characters autoregressively and can implicitly learn a language model; SAR [13], the recursive recurrent model R2AM [14], and the 2-D attention decoder MASTER [15] follow this route, while SRN [20] and ABINet [19] add explicit semantic reasoning or iterative language correction on top.

More recently the field moved toward **transformer backbones**. ViTSTR [16] showed that a plain ViT, fed image patches, can recognize text competitively with far less architectural machinery. SVTR [17] introduced a hierarchical, convolution-infused transformer designed specifically for the long, thin aspect ratio of text lines and demonstrated excellent accuracy-to-size ratios, including very small variants. PARSeq [18] unified context-free and context-aware decoding through permutation training and reported state-of-the-art accuracy.

Two observations from this literature shape our design. First, **hybrid backbones win on efficiency**: a convolutional stem that reduces spatial resolution cheaply, followed by a transformer that models long-range context, repeatedly outperforms pure-convolution or pure-transformer designs at a fixed budget [17]. DenseNet [5] is an especially parameter-efficient stem because its feature-reuse pattern delivers strong representations with few channels. Second, **CTC remains the most deployment-friendly decoder**: it is non-autoregressive, decodes a whole line in a single forward pass, and avoids the step-by-step latency of attention decoders—exactly the property an interactive mobile feature needs [8; 9]. We therefore adopt a **Dense + ViT + CTC** backbone, combining a DenseNet stem, a compact ViT encoder, and a CTC head. The accuracy ceiling of this family is well established; the open question this thesis answers is how to *shrink and quantize* it without losing that accuracy.

It is useful to make the decoder trade-off explicit, because it drives the rest of the thesis. An **attention decoder** emits one character at a time, conditioning each step on the characters already produced. This autoregressive loop is what lets such models learn an implicit language model and excel on ambiguous or occluded text, but it also means the decoder must run $n$ sequential steps to emit an $n$-character string, and each step depends on the previous one, so the work cannot be parallelized across output positions at inference time. On a mobile accelerator, where launching many small dependent kernels is expensive, this sequential dependency is precisely the wrong cost profile. A **CTC decoder**, by contrast, produces all per-frame distributions in one parallel forward pass and then collapses them with a cheap, deterministic rule; there is no learned recurrence at the output and no per-character kernel launch. The price is the absence of an explicit language model, which costs CTC a few points on the hardest, most ambiguous lines—a gap this thesis accepts deliberately in exchange for single-pass latency, and partially compensates for through better representation learning. Table 1.1 summarizes the families discussed above along the axes that matter for on-device deployment.

Table: Representative text-line recognition approaches and the properties that matter for on-device deployment. "AR" = autoregressive. Sizes and accuracies are representative values from the literature; exact comparison figures appear in Chapter 3.

| Approach | Backbone | Decoder | Decoding | Rel. size | Strengths | Weaknesses on device |
|---|---|---|---|---|---|---|
| CRNN [9] | CNN + BiLSTM | CTC | Single-pass | Small | Fast, simple, robust | Lower accuracy on irregular text |
| RARE / ASTER [10; 11] | CNN + rectifier | Attention (AR) | Sequential | Large | Handles curved/perspective text | Rectifier + AR loop add latency |
| SAR / MASTER [13; 15] | CNN (+2-D attn) | Attention (AR) | Sequential | Large | Strong on irregular text | High compute, sequential decode |
| ABINet / SRN [19; 20] | CNN/Transformer | Attention + LM | Iterative | Large | Explicit language reasoning | Extra LM passes, heavy |
| ViTSTR [16] | ViT | Linear/CTC-like | Single-pass | Medium | Architecturally simple | Needs strong pre-training |
| SVTR [17] | Hybrid Transformer | CTC | Single-pass | Small–med | Excellent accuracy/size | — (close to our target family) |
| PARSeq [18] | ViT | Permuted AR | Sequential | Large | State-of-the-art accuracy | AR decode, large footprint |
| **Dense+ViT+CTC (ours)** | DenseNet + ViT | CTC | Single-pass | Tunable | Single-pass, distillable, quantizable | No explicit LM (by choice) |

The table makes the design rationale concrete: the approaches in the upper-accuracy tier almost all rely on autoregressive attention decoding, sometimes with additional rectification or language-model passes, and carry large footprints. The approaches that are genuinely cheap to run on device are the single-pass CTC families. Our contribution is not to invent a new point in this table but to take the cheap, single-pass CTC family and raise its accuracy—through distillation—and shrink its footprint—through quantization—until it occupies the otherwise-empty corner of small *and* accurate.

### 1.3.2 Knowledge distillation

Knowledge distillation (KD) trains a small "student" to imitate a large "teacher." The original formulation [21] matches the teacher's softened output probabilities (logits), transferring the "dark knowledge" encoded in the relative scores of wrong classes. Subsequent work showed that matching *intermediate representations* often transfers more: FitNets [22] regress student features onto teacher features through a learned projection; attention transfer [23] matches spatial attention maps; relational KD [24] and similarity-preserving KD [27] match the geometry of feature relationships rather than features directly; contrastive representation distillation [25] maximizes mutual information between teacher and student embeddings; and the "overhaul" study [26] analyzes where and how feature distillation should be applied. In sequence models, TinyBERT [28] and patient KD [29] distilled transformer hidden states and attention layer-by-layer, establishing that *hidden-level* distillation is particularly effective for transformer encoders.

Two gaps are relevant here. First, most feature-distillation methods were designed for classification, where every spatial location is informative. A CTC-based recognizer is different: its output sequence is dominated by the **blank** symbol, and the corresponding hidden states carry little character information. Distilling all frames uniformly therefore spends most of the transfer budget on uninformative positions. Second, transformer-oriented hidden distillation [28; 29] typically assumes a one-to-one layer correspondence and matched widths, which does not hold when a student is much narrower and shallower than its teacher. The first section of Chapter 2 addresses exactly these two gaps.

It helps to organize this literature along the standard axis of *what* signal is transferred, because our two improvements live in the feature-based category and inherit its assumptions. **Response-based** distillation transfers the teacher's output distribution—the original logit matching of [21]—and is architecture-agnostic but shallow, since it ignores everything the teacher computed internally. **Feature-based** distillation transfers intermediate activations: FitNets [22] regress one student layer onto one teacher layer; the overhaul study [26] examines exactly which layer, which transform, and which distance to use; and the transformer-specific methods [28; 29] extend this to hidden states and attention maps at every layer. **Relation-based** distillation transfers the *structure* among examples or positions rather than their values—relational KD [24] matches pairwise distances and angles, similarity-preserving KD [27] matches the Gram matrix of activations, and contrastive distillation [25] matches mutual information. A second axis distinguishes **offline** distillation (a fixed, pre-trained teacher, as in this thesis) from **online** distillation (teacher and student trained together) and **self-distillation** (a model teaching a later or quantized version of itself—exactly the mechanism our QA-KD stage reuses in Chapter 2). Table 1.2 places the main methods in this scheme.

Table: A taxonomy of knowledge-distillation methods, organized by the signal transferred. The methods this thesis builds on are feature-based (hidden-state) and, in the quantization stage, self-distillation.

| Category | Signal transferred | Representative methods | Relevance to this work |
|---|---|---|---|
| Response-based | Softened output logits | Hinton et al. [21] | Used as an auxiliary, blank-aware term |
| Feature-based | Intermediate activations / hidden states | FitNets [22], AT [23], Overhaul [26], TinyBERT [28], PKD [29] | **Core** — the hidden-level transfer we improve |
| Relation-based | Geometry among features/examples | RKD [24], SP-KD [27], CRD [25] | Related; not adopted, to keep the recipe simple |
| Self-distillation | A model teaches its own (later/quantized) copy | (mechanism) | **Core** — reused in QA-KD (Chapter 2, Sec. 2.3.4) |

Our design sits squarely in the feature-based row: we transfer hidden states, not merely logits, because the student and teacher share an architecture and their hidden states are therefore directly comparable. The two improvements of Section 2.2 are refinements *within* this category—one about which positions to weight, one about which depths to match—rather than a move to a different category. This is a deliberate choice: feature-based hidden distillation is the best-understood and most reliable signal for same-family transformer encoders, and building on it keeps the method easy to reason about and reproduce.

### 1.3.3 Network quantization

Quantization reduces the numerical precision of weights and activations. The extreme of binary and ternary weights [30; 31] established feasibility but at a steep accuracy cost. The practical mainstream is integer quantization with **quantization-aware training** (QAT), in which the forward pass simulates rounding while gradients flow through a straight-through estimator: the integer-arithmetic-inference framework [32], DoReFa-Net [33], PACT [34] (which learns activation clipping), and LSQ [35] (which learns the quantization step size) are landmarks. **Post-training quantization** (PTQ) avoids retraining: AdaRound [36] optimizes the rounding direction layer-by-layer, while the recent GPTQ [37] and AWQ [38] push large models to low bit-widths by accounting for the second-order or activation-aware importance of weights, and LLM.int8() [39] isolates outlier channels. **Mixed-precision** methods recognize that layers differ in sensitivity and assign bit-widths accordingly, either by hardware-aware search (HAQ [40]) or by a Hessian-based sensitivity measure (HAWQ [41]).

The lesson from this literature is twofold. *Uniform* low-bit quantization is wasteful and brittle, because a handful of layers are disproportionately sensitive [40; 41], and *4-bit* in particular tends to be the precision at which a naively quantized model begins to fail noticeably. At the same time, the accuracy lost to 4-bit rounding is largely recoverable if the quantized model is *fine-tuned with a strong supervisory signal* [35]. The second section of Chapter 2 combines these two lessons—sensitivity-driven bit allocation and distillation-based recovery—into a 4-bit recipe tailored to the Dense + ViT + CTC recognizer.

Three design axes from this literature recur in Chapter 2 and are worth naming precisely. The first is **granularity**: a quantizer can share one scale across an entire tensor (per-tensor, cheapest, most brittle), one scale per output channel (per-channel), or one scale per contiguous group of weights (group-wise, the choice we adopt at group size 128). Finer granularity costs a little storage for the extra scales but dramatically reduces the damage a single outlier weight does to its neighbors, which matters acutely at 4 bits where only fifteen levels are available. The second is **timing**: post-training quantization (PTQ) quantizes a finished model using only a small calibration set and no gradient updates—fast and data-light but limited at low bit-widths—whereas quantization-aware training (QAT) simulates rounding during training so the weights can adapt to it, recovering far more accuracy at the cost of a training run. The third is **uniformity of precision across layers**: a model can use the same bit-width everywhere (uniform) or assign different bit-widths to different layers (mixed-precision) according to their measured sensitivity. Our recipe combines the favorable end of all three axes for the low-bit regime—group-wise granularity, a short QAT-style fine-tune, and a mixed-precision allocation—because at 4 bits no single one of them suffices. Table 1.3 organizes the main methods along these axes.

Table: A taxonomy of quantization methods along the three axes used in this thesis. The proposed recipe (last row) combines group-wise granularity, mixed precision, and a distillation-supervised QAT fine-tune.

| Method | Granularity | Timing | Precision allocation | Note |
|---|---|---|---|---|
| BinaryConnect / XNOR [30; 31] | Per-tensor | QAT | Uniform (1-bit) | Feasibility at extreme cost |
| Integer-only [32], DoReFa [33] | Per-tensor/channel | QAT | Uniform | Practical INT8 baseline |
| PACT [34] | Per-tensor | QAT | Uniform | Learns activation clipping |
| LSQ [35] | Per-tensor/channel | QAT | Uniform | Learns the step size (we reuse this) |
| AdaRound [36] | Per-layer | PTQ | Uniform | Optimizes rounding direction |
| GPTQ [37], AWQ [38] | Group/channel | PTQ | Uniform | Outlier/second-order aware (LLMs) |
| LLM.int8() [39] | Per-channel | PTQ | Mixed (outliers in 16-bit) | Isolates outlier channels |
| HAQ [40], HAWQ [41] | Per-layer | QAT/PTQ | **Mixed** | Search- or Hessian-driven allocation |
| **Proposed (ours)** | **Group-wise** | **QAT fine-tune** | **Mixed (KL probe)** | Distillation-supervised recovery |

### 1.3.4 Efficient backbones and a note on the comparison set

Orthogonal to distillation and quantization, efficient backbone families such as MobileNet [42; 43] and EfficientNet [44] reduce cost through depthwise-separable convolutions and compound scaling. These are complementary to our work—our student could in principle use such a stem—but we keep a DenseNet stem so that the student remains in the same architectural family as the teacher, which is what makes hidden-level distillation natural. Throughout, our experiments are conducted on the standard public training data, MJSynth/Synth90k [45] and SynthText [46], and evaluated on the established benchmarks IIIT5K [47], Street View Text (SVT) [48], and the ICDAR 2013 and 2015 sets [49; 50], following the protocol detailed in Chapter 3.

## 1.4 Problem statement

The problem this thesis solves can be stated precisely. Given (a) a Dense + ViT + CTC teacher trained to high accuracy and (b) the four mobile constraints of Section 1.2, produce a recognizer that:

- shares the teacher's architecture family but is small enough to deploy (single-digit-megabyte storage, tens-of-megabytes peak memory);
- recovers as much of the teacher's accuracy as possible through distillation rather than from labels alone; and
- survives compression to 4-bit weights with minimal additional accuracy loss.

The difficulty is concentrated in two places. In **distillation**, the CTC blank problem and the teacher–student dimension mismatch make naive hidden-state matching inefficient. In **quantization**, the non-uniform sensitivity of layers and the fragility of 4-bit rounding make naive PTQ inadequate. The proposed improvements (two per stage) are each aimed at one of these difficulties.

These two difficulties are worth stating as concrete failure modes, because the improvements of Chapter 2 are defined precisely as their remedies. The distillation failure mode is *misallocated transfer*: a generic hidden-matching loss spends most of its budget on the abundant blank frames and on forcing a single bottleneck to carry the teacher's entire multi-level structure, so the student learns the easy part well and the hard part poorly. The quantization failure mode is *uniform fragility*: treating every layer and every weight identically at 4 bits lets a few sensitive layers and a few outlier weights dominate the error, and offers no mechanism to recover from the rounding that remains. Each of the four improvements targets exactly one facet of these two failure modes—confidence weighting and multi-stage alignment for misallocated transfer, sensitivity-aware mixed precision and QA-KD for uniform fragility—which is why the ablations in Chapter 3 can isolate them cleanly.

## 1.5 Research objectives and contributions

The objectives of this thesis are:

1. **A coherent, shared-architecture framework.** Design teacher and student in the same Dense + ViT + CTC family so that representations are directly comparable and distillation is natural (Chapter 2, Section 1; system view in Chapter 3).
2. **Two targeted improvements to hidden-level distillation** (Chapter 2, Section 1):
   - *CTC-confidence-weighted hidden distillation*, which weights the per-frame hidden-state loss by one minus the teacher's blank probability, focusing the transfer on character-bearing frames.
   - *Multi-stage adaptive hidden alignment*, which distills at several depths through lightweight projectors with feature normalization, removing the need for matched widths or one-to-one layer correspondence.
3. **Two targeted improvements to 4-bit quantization** (Chapter 2, Section 2):
   - *Sensitivity-aware mixed-precision quantization*, which measures each layer's quantization sensitivity and keeps a small, fragile subset at 8-bit while the rest use group-wise 4-bit.
   - *Quantization-aware knowledge distillation (QA-KD)*, which fine-tunes the quantized student under the supervision of the full-precision student, recovering most of the rounding loss.
4. **A thorough on-device evaluation** against prior models, reporting per-benchmark accuracy, model size, latency, peak memory, and energy, together with ablations that isolate the contribution of each of the four improvements (Chapter 3).

The improvements are deliberately modest in number and conventional in their building blocks; the contribution is the *reasoned combination* and the *measured isolation* of each, not a claim of a fundamentally new operator.

## 1.6 Organization of the thesis

Chapter 2 presents the proposed method in two sections: Section 2.2 covers the teacher/student design and hidden-level distillation with its two improvements; Section 2.3 covers the 4-bit quantization recipe with its two improvements. Chapter 3 describes system construction and the on-device pipeline, implementation details, datasets and metrics, the main comparison against prior models, ablation studies that isolate each improvement, on-device cost measurements, and a discussion of limitations. Chapter 4 concludes. A list of 50 references follows.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Chapter 2. Proposed Method

## 2.1 Overview

The method proceeds in three stages, illustrated in Figure 2.1. A high-capacity **teacher** is trained first. A compact **student**, drawn from the same architectural family, is then trained with **hidden-level knowledge distillation** from the teacher (Section 2.2). Finally the distilled student is compressed to **4-bit weights** through a sensitivity-aware, distillation-assisted procedure (Section 2.3). Keeping teacher and student in one family is the design decision that ties the whole method together: because their feature spaces are structurally comparable, hidden-state distillation needs only a thin projector to bridge them, and because the student is already a good full-precision model after distillation, it can serve as its own teacher during quantization.

![The proposed three-stage pipeline. A Dense+ViT+CTC teacher is distilled into a compact student of the same family through hidden-level knowledge distillation, and the student is then quantized to 4-bit for on-device deployment.](figures/fig_framework.png){width=92%}

For reference, Table 2.0 collects the notation used throughout this chapter. The symbols are introduced again where they first appear, but gathering them in one place makes the equations easier to follow.

Table: Notation used in Chapter 2.

| Symbol | Meaning |
|---|---|
| $x,\,y$ | Input line image and its target string |
| $T$ | Number of CTC time frames (encoder output length) |
| $\mathcal{A}$ | Character alphabet (36 symbols); $|\mathcal{A}|+1$ includes blank |
| $\mathbf{p}_t$ | Per-frame output distribution at frame $t$ |
| $H^{t},\,H^{s}$ | Teacher / student hidden-state sequences at a stage |
| $d_t,\,d_s$ | Teacher / student hidden widths |
| $\phi,\,\phi_s$ | Training-only projector(s) mapping student width to teacher width |
| $\bar{\cdot}$ | Per-feature standardization (zero mean, unit variance) |
| $w_k$ | CTC-confidence weight at frame $k$ (Eq. 2.5) |
| $\mathcal{S},\,\alpha_s$ | Set of matching stages and their learnable gate weights |
| $\tau$ | Distillation temperature |
| $s,\,z,\,b$ | Quantization scale, zero-point, and bit-width |
| $g$ | Quantization group size (128) |
| $\Omega_\ell$ | Measured 4-bit sensitivity of layer $\ell$ (Eq. 2.11) |
| $\lambda_{\mathrm{kd}},\,\lambda_{\mathrm{hid}}$ | Loss weights for the logit and hidden terms |

## 2.2 Section 1 — Teacher/Student Design and Hidden-Level Knowledge Distillation

### 2.2.1 The Dense + ViT + CTC backbone

Both teacher and student use the recognition backbone of Figure 2.2. A grayscale text-line image of fixed height (32 pixels) and variable width $W$ is processed by a **DenseNet** stem [5]. Dense connectivity—where each layer receives the concatenated feature maps of all preceding layers in its block—achieves strong representations with few channels because features are reused rather than relearned; this parameter efficiency is exactly what a mobile student needs. The stem reduces the height to one and the width by a factor of four to eight, producing a feature map that is reshaped into a sequence of $T$ column tokens, each a $C$-dimensional vector.

It is worth being precise about *why* the DenseNet stem is the right choice for the student, because it is one of the two architectural commitments that make the whole method work. In a dense block, the $\ell$-th layer takes as input the concatenation of all preceding feature maps $[x_0, x_1, \dots, x_{\ell-1}]$ and produces a small number of new feature maps (the *growth rate*), which are appended to the running concatenation. Two consequences follow. First, every layer has direct access to the raw stem features and to every intermediate representation, so gradients flow to early layers without attenuation and features computed once are never recomputed—this is the "feature reuse" that lets a DenseNet match a much wider plain CNN at a fraction of the parameters. Second, the growth rate is a single, interpretable knob for capacity: the teacher uses growth 32 and four blocks, the student growth 16 and three blocks (Table 2.1), so the student's stem is narrower and shallower but *structurally identical*, which is precisely what makes its intermediate features comparable to the teacher's for the distillation of Section 2.2.7.

These tokens enter a **ViT encoder** [7]: a stack of $L$ identical layers, each a multi-head self-attention (MHSA) block followed by a position-wise feed-forward network (FFN), with residual connections and layer normalization. Self-attention lets every column attend to every other column, which supplies the long-range context needed to disambiguate characters from their neighbors (for instance "rn" versus "m"). Because the line has already been collapsed to a 1-D sequence, the encoder is one-dimensional and inexpensive relative to a full image transformer.

Concretely, each encoder layer computes multi-head self-attention over the $T$ column tokens: the tokens are projected to queries, keys, and values, attention weights are formed from scaled query–key dot products, and the value vectors are mixed accordingly, after which a two-layer feed-forward network applies a position-wise nonlinearity. Residual connections and layer normalization wrap both sub-blocks. The cost of self-attention is quadratic in the sequence length $T$, but for a single text line collapsed to height one, $T$ is on the order of a few dozen tokens, so the quadratic term is small in absolute terms—another reason the encoder is cheap relative to a 2-D vision transformer that must attend over hundreds or thousands of patches. The student halves the teacher's depth (6 versus 12 layers), width (192 versus 384), and head count (3 versus 6); because attention and FFN both scale with width, this is most of the difference between the student's 4.8 M and the teacher's 28.4 M parameters.

A linear layer maps each encoder output to a distribution over the character alphabet plus a special **blank** symbol, and a **CTC** head [8] interprets the resulting per-frame distributions. CTC is non-autoregressive: the entire line is decoded in a single forward pass, with no recurrent or step-by-step generation, which is the property that makes the model fast enough for interactive on-device use.

![The Dense+ViT+CTC recognition backbone, shared in topology by teacher and student. The DenseNet stem extracts features, the ViT encoder models context across columns, and the CTC head decodes the per-frame character distributions without explicit segmentation.](figures/fig_arch.png){width=95%}

### 2.2.2 Teacher and student configurations

Teacher and student differ only in width and depth, not in kind. The teacher uses a deeper DenseNet stem, a wider ViT (more layers, larger hidden width, more heads), and therefore a much larger parameter count; the student trims all of these. Table 2.1 lists the two configurations. Because the two share the same stages and the same token semantics, a student hidden state at a given stage has a clear teacher counterpart, which is what the distillation of Section 2.2.6–2.2.7 exploits.

The specific numbers in Table 2.1 were chosen to make the student land in the single-digit-megabyte regime demanded by Section 1.2 while keeping enough capacity to benefit from distillation. Halving the encoder depth and width is the largest lever: since both the attention projections and the feed-forward layers scale with the square of the width, cutting width from 384 to 192 reduces those layers roughly four-fold, and halving the layer count halves them again. Narrowing the DenseNet growth rate from 32 to 16 shrinks the stem proportionally. The result is a 4.8 M-parameter model—about one-sixth of the teacher—whose FP32 footprint (18.4 MB) is still too large for comfortable deployment but which, after the 4-bit quantization of Section 2.3, reaches 2.7 MB. We did not search this configuration exhaustively; it is a deliberately round, reproducible choice that sits at a sensible point on the accuracy–size curve, consistent with the thesis's aim of a clear and repeatable recipe rather than a heavily tuned single result.

Table: Teacher and student configurations. Both follow the Dense+ViT+CTC topology of Figure 2.2; they differ only in width and depth.

| Component | Teacher | Student |
|---|---|---|
| DenseNet stem | 4 dense blocks, growth 32 | 3 dense blocks, growth 16 |
| Feature channels $C$ | 512 | 192 |
| ViT layers $L$ | 12 | 6 |
| ViT hidden width $d$ | 384 | 192 |
| Attention heads | 6 | 3 |
| FFN expansion | 4× | 3× |
| Parameters | 28.4 M | 4.8 M |
| FP32 size | 108.3 MB | 18.4 MB |

### 2.2.3 The CTC objective

Let $x$ be a line image and $\mathbf{p}=(\mathbf{p}_1,\dots,\mathbf{p}_T)$ the per-frame distributions produced by the CTC head, where $\mathbf{p}_t \in \mathbb{R}^{|\mathcal{A}|+1}$ ranges over the alphabet $\mathcal{A}$ plus blank. CTC defines the probability of a target string $y$ by summing over all frame-level alignments $\pi$ that collapse to $y$ under the standard mapping $\mathcal{B}$ (which removes repeats and then blanks):

$$ p(y \mid x) \;=\; \sum_{\pi \,\in\, \mathcal{B}^{-1}(y)} \;\prod_{t=1}^{T} \mathbf{p}_t[\pi_t] \qquad\qquad (2.1) $$

and the training loss is the negative log-likelihood, computed efficiently by the forward–backward algorithm:

$$ \mathcal{L}_{\mathrm{CTC}} \;=\; -\,\log p(y \mid x). \qquad\qquad (2.2) $$

The key structural fact we exploit later is that, in a trained CTC model, the most probable symbol at the majority of frames is **blank**: characters occupy only a fraction of the $T$ frames, and the rest act as separators. This is visible directly in the per-frame blank probability and motivates the weighting introduced in Section 2.2.6.

A short note on why the sum in (2.1) is tractable, since it underlies the whole training procedure. The set $\mathcal{B}^{-1}(y)$ of frame-level alignments that collapse to a length-$n$ string $y$ is exponentially large in $T$, so summing over it explicitly is infeasible. CTC instead computes the sum with a dynamic-programming recursion—the forward–backward algorithm—over an augmented target in which a blank is inserted between every pair of characters and at both ends. Defining forward variables $\alpha_t(u)$ (the total probability of all alignments that have produced the first $u$ symbols of this augmented target by frame $t$) and the symmetric backward variables $\beta_t(u)$, the recursion fills a $T \times (2n+1)$ table in $O(T\,n)$ time, and the likelihood $p(y\mid x)$ is read off the final column. The gradient with respect to each per-frame distribution follows from the same $\alpha,\beta$ products. The practical consequence for this thesis is twofold: training is cheap and fully parallel across frames, and—because the recursion concentrates probability mass on a sparse set of "spike" frames where characters are emitted, with blank dominating elsewhere—the trained model exhibits exactly the peaky, blank-heavy frame distribution that Section 2.2.6 turns to its advantage.

### 2.2.4 Baseline distillation: logit transfer

The classical distillation signal [21] matches softened output distributions. With temperature $\tau>1$, define the softened teacher and student per-frame distributions $\mathbf{p}^{t,\tau}_k$ and $\mathbf{p}^{s,\tau}_k$ at frame $k$. The logit-distillation loss is the temperature-scaled Kullback–Leibler divergence averaged over frames:

$$ \mathcal{L}_{\mathrm{kd}} \;=\; \frac{\tau^2}{T}\sum_{k=1}^{T} \mathrm{KL}\!\left(\mathbf{p}^{t,\tau}_{k}\;\big\|\;\mathbf{p}^{s,\tau}_{k}\right). \qquad\qquad (2.3) $$

Logit transfer alone is a useful but limited signal for a CTC recognizer, for two reasons that recur throughout this section: the frame index is shared by teacher and student only approximately (their stems may downsample to slightly different $T$), and the divergence is dominated by the easy, high-confidence blank frames. We therefore treat (2.3) as an auxiliary term and place the emphasis on hidden-level transfer.

### 2.2.5 Hidden-level distillation: formulation

Hidden-level (feature) distillation matches *internal representations* rather than outputs [22; 26; 28]. Let $H^{t}\in\mathbb{R}^{T\times d_t}$ and $H^{s}\in\mathbb{R}^{T\times d_s}$ be the sequences of hidden states at a chosen encoder stage in teacher and student. Because $d_s \neq d_t$ in general, a learnable projector $\phi(\cdot)$ maps the student width to the teacher width. The basic hidden loss is a per-frame squared error after projection:

$$ \mathcal{L}_{\mathrm{hid}}^{\text{base}} \;=\; \frac{1}{T}\sum_{k=1}^{T}\big\lVert\, \bar H^{t}_{k} - \overline{\phi(H^{s}_{k})}\,\big\rVert_2^{2}, \qquad\qquad (2.4) $$

where $\bar{\cdot}$ denotes per-feature standardization (subtract mean, divide by standard deviation across the channel dimension). Standardization is important: teacher and student hidden states can differ greatly in scale, and matching raw magnitudes would make the loss dominated by scale rather than by the *pattern* of activation we actually want to transfer. Equation (2.4) is our starting point; the next two subsections describe the two improvements we make to it.

Three design choices in (2.4) deserve a brief justification, since each is a small decision that recurs in the improvements that follow. The *projector* $\phi$ is deliberately minimal—a single linear map—rather than a multi-layer network, because its only job is to reconcile the width mismatch $d_s \neq d_t$; a more expressive projector risks absorbing the teacher–student discrepancy itself, letting the student off the hook from actually matching the teacher's representation. The *distance* is a squared error after standardization rather than, say, a cosine or a relational loss, because once both sides are standardized the squared error directly penalizes pattern mismatch and is stable to optimize alongside the CTC loss. The *direction* of the projection—student up to teacher width, rather than teacher down to student width—matters because projecting the teacher down would discard information before the student ever sees it, whereas projecting the student up asks the smaller model to express the teacher's full pattern within a learned linear embedding. These are not deep choices, but stating them makes the formulation reproducible and explains why the two improvements modify the *weighting* and the *number of matching points* rather than this core distance.

### 2.2.6 Improvement 1 — CTC-confidence-weighted hidden distillation

**Motivation.** As noted in Section 2.2.3, most frames of a CTC recognizer are blank. Their hidden states encode "no character here," which is easy and largely redundant. Equation (2.4) spends an equal share of its budget on every frame, so the abundant blank frames dominate the loss and the scarce character frames—precisely the ones that determine accuracy—are under-weighted. This is the CTC-specific blind spot of generic feature distillation.

**Method.** We weight each frame's contribution by how much character information the *teacher* believes it carries. Let $p^{t}_{\mathrm{blank}}(k)$ be the teacher's blank probability at frame $k$. Define a frame weight

$$ w_k \;=\; \max\!\big(\epsilon,\; 1 - p^{t}_{\mathrm{blank}}(k)\big), \qquad\qquad (2.5) $$

where the floor $\epsilon$ (we use $\epsilon=0.1$) keeps blank frames from being ignored entirely, since the transition regions around characters still carry useful shape information. The weighted hidden loss normalizes by the total weight so that its scale is independent of line length and of how many characters the line contains:

$$ \mathcal{L}_{\mathrm{hid}} \;=\; \frac{\displaystyle\sum_{k=1}^{T} w_k\,\big\lVert \bar H^{t}_{k} - \overline{\phi(H^{s}_{k})}\big\rVert_2^{2}} {\displaystyle\sum_{k=1}^{T} w_k}. \qquad\qquad (2.6) $$

The same weights are applied to the logit term (2.3), turning it into a blank-aware divergence that no longer rewards the student merely for confidently predicting blank on empty frames. Figure 2.3 visualizes the effect: weight concentrates on the character-bearing frames and is suppressed in the blank gaps between them.

![CTC-confidence weighting. The teacher's per-frame character confidence $w_k=1-p^{t}_{\mathrm{blank}}(k)$ is high on frames that carry characters (teal) and low in the blank gaps (gray). Weighting the hidden-distillation loss by $w_k$ focuses the transfer where it matters.](figures/fig_conf_weight.png){width=82%}

**Why it helps, stated plainly.** The improvement does not change *what* is transferred (teacher hidden states) but *where the transfer budget is spent*. By reallocating that budget from the many easy blank frames to the few informative character frames, the student receives a stronger gradient exactly on the positions that decide whether a character is read correctly. The ablation in Section 3.7 shows this single change accounts for a clear, isolated accuracy gain.

### 2.2.7 Improvement 2 — Multi-stage adaptive hidden alignment

**Motivation.** Equation (2.6) matches one stage. But teacher and student differ in *depth*, and a single matching point forces all of the teacher's multi-level structure—low-level stroke features near the stem, high-level contextual features near the head—through one bottleneck. Transformer-distillation methods that assume one-to-one layer correspondence [28; 29] do not apply, because the student has half as many layers and a different width. We need a matching scheme that (a) transfers structure at several depths and (b) tolerates mismatched widths and counts.

**Method.** We select a small set of matching stages $\mathcal{S}$—the DenseNet output, two intermediate ViT depths, and the pre-head representation—and pair each student stage with a teacher stage at a comparable relative depth. Each pair $s\in\mathcal{S}$ gets its own lightweight projector $\phi_s$ (a single linear map plus standardization), so widths need not match and no teacher layer must align one-to-one with a student layer. The stage losses are combined by learnable, softmax-normalized gates $\alpha_s$, which let the model decide how much to weight each depth rather than fixing the weights by hand:

$$ \mathcal{L}_{\mathrm{hid}}^{\text{multi}} \;=\; \sum_{s\in\mathcal{S}} \alpha_s\, \mathcal{L}_{\mathrm{hid}}^{(s)}, \qquad \alpha_s \;=\; \frac{\exp(g_s)}{\sum_{s'\in\mathcal{S}}\exp(g_{s'})}, \qquad\qquad (2.7) $$

where $\mathcal{L}_{\mathrm{hid}}^{(s)}$ is the confidence-weighted loss (2.6) evaluated at stage $s$ and $g_s$ are free scalar parameters. The projectors and gates add a negligible number of parameters and, crucially, are used **only during training**—they are discarded before deployment, so the on-device student is exactly the backbone of Table 2.1. Figure 2.4 shows the arrangement.

![Multi-stage adaptive hidden alignment. Teacher and student are matched at several depths through per-stage projectors with feature standardization; learnable gates $\alpha_s$ weight the stages. The projectors and gates are training-only and add no inference cost.](figures/fig_multistage.png){width=92%}

**Why it helps, stated plainly.** A single matching point asks the student to absorb the teacher's entire representational hierarchy at one location; multiple matching points let each part of the student learn from the corresponding part of the teacher. The adaptive gates avoid a brittle hand-tuned weighting and let the easier stages (which converge quickly) cede emphasis to the harder ones. The two improvements are complementary: confidence weighting decides *which frames* to emphasize within a stage, and multi-stage alignment decides *which depths* to match across the network.

### 2.2.8 Combined training objective

The student is trained with the ground-truth CTC loss, the blank-aware logit term, and the multi-stage confidence-weighted hidden term:

$$ \mathcal{L}_{\mathrm{student}} \;=\; \mathcal{L}_{\mathrm{CTC}} \;+\; \lambda_{\mathrm{kd}}\,\mathcal{L}_{\mathrm{kd}} \;+\; \lambda_{\mathrm{hid}}\,\mathcal{L}_{\mathrm{hid}}^{\text{multi}}. \qquad\qquad (2.8) $$

We use $\lambda_{\mathrm{kd}}=0.5$ and $\lambda_{\mathrm{hid}}=1.0$ throughout; Section 3.7 reports a small sensitivity study around these values. Figure 2.5 (in Section 2.2 context) and the overview of Figure 2.6 connect this stage to the quantization that follows. The teacher is frozen during student training, so distillation adds only forward-pass cost on the teacher and no teacher gradients.

The full training loop for the student is summarized in Algorithm 2.1. Each step runs the frozen teacher and the trainable student on the same batch, reads the teacher's per-frame blank probabilities to form the confidence weights, projects and standardizes the student's hidden states at each matching stage, and combines the three losses. The only trainable additions beyond the student itself are the per-stage projectors $\phi_s$ and the gate logits $g_s$, all of which are discarded after training.

> **Algorithm 2.1 — Student training with hidden-level distillation**
> **Input:** frozen teacher $\mathcal{T}$; student $\mathcal{S}$; projectors $\{\phi_s\}$; gate logits $\{g_s\}$; weights $\lambda_{\mathrm{kd}},\lambda_{\mathrm{hid}}$; temperature $\tau$; floor $\epsilon$
> **for** each minibatch $(x,y)$ **do**
> &nbsp;&nbsp; $(\mathbf{p}^t, \{H^{t}_s\}) \leftarrow \mathcal{T}(x)$ &nbsp; *(no gradient)*
> &nbsp;&nbsp; $(\mathbf{p}^s, \{H^{s}_s\}) \leftarrow \mathcal{S}(x)$
> &nbsp;&nbsp; $w_k \leftarrow \max(\epsilon,\,1-p^{t}_{\mathrm{blank}}(k))$ for all frames $k$ &nbsp; *(Eq. 2.5)*
> &nbsp;&nbsp; $\mathcal{L}_{\mathrm{CTC}} \leftarrow \mathrm{CTC}(\mathbf{p}^s, y)$ &nbsp; *(Eq. 2.2)*
> &nbsp;&nbsp; $\mathcal{L}_{\mathrm{kd}} \leftarrow$ confidence-weighted, temperature-scaled KL$(\mathbf{p}^t \| \mathbf{p}^s)$ &nbsp; *(Eqs. 2.3, 2.5)*
> &nbsp;&nbsp; **for** each stage $s\in\mathcal{S}$ **do** $\mathcal{L}^{(s)}_{\mathrm{hid}} \leftarrow$ weighted MSE$\big(\bar H^{t}_s,\ \overline{\phi_s(H^{s}_s)}\big)$ &nbsp; *(Eq. 2.6)*
> &nbsp;&nbsp; $\alpha_s \leftarrow \mathrm{softmax}(g)_s$; &nbsp; $\mathcal{L}^{\mathrm{multi}}_{\mathrm{hid}} \leftarrow \sum_s \alpha_s \mathcal{L}^{(s)}_{\mathrm{hid}}$ &nbsp; *(Eq. 2.7)*
> &nbsp;&nbsp; $\mathcal{L} \leftarrow \mathcal{L}_{\mathrm{CTC}} + \lambda_{\mathrm{kd}}\mathcal{L}_{\mathrm{kd}} + \lambda_{\mathrm{hid}}\mathcal{L}^{\mathrm{multi}}_{\mathrm{hid}}$ &nbsp; *(Eq. 2.8)*
> &nbsp;&nbsp; update $\mathcal{S},\{\phi_s\},\{g_s\}$ by AdamW on $\nabla\mathcal{L}$
> **return** student $\mathcal{S}$ (projectors and gates discarded)

**A note on the projector cost.** Each projector $\phi_s$ is a single linear map from the student width $d_s$ to the teacher width $d_t$ at that stage, so it contributes $d_s \times d_t$ parameters—on the order of a few tens of thousands per stage for our configuration, summed over the four matching stages of $\mathcal{S}$. This is negligible relative to the 4.8 M-parameter student, and because the projectors and the four gate scalars exist only to compute the training loss, they are removed before export. The deployed student is therefore *bit-for-bit* the backbone of Table 2.1, with no distillation machinery left behind—an important property for a method whose entire purpose is to minimize on-device cost.

![Hidden-level knowledge distillation, assembled. The frozen teacher supplies softened logits (a blank-aware KD term) and standardized hidden states at several stages (the multi-stage confidence-weighted term); ground-truth labels supply the CTC term.](figures/fig_kd_overview.png){width=88%}

## 2.3 Section 2 — Efficient 4-Bit Quantization

The distilled student of Section 2.2 is accurate and already eight times smaller than the teacher, but at 18.4 MB and FP32 arithmetic it is still heavier than we want. This section compresses its weights to 4 bits. We first state the quantization mechanics, then explain why a naive 4-bit scheme is inadequate for this model, and then present the two improvements.

### 2.3.1 Quantization preliminaries

Uniform affine quantization maps a real value $x$ to a $b$-bit integer through a scale $s$ and zero-point $z$:

$$ q \;=\; \mathrm{clip}\!\left(\Big\lfloor \tfrac{x}{s} \Big\rceil + z,\; q_{\min},\; q_{\max}\right), \qquad \hat{x} \;=\; s\,(q - z), \qquad\qquad (2.9) $$

where $\lfloor\cdot\rceil$ is round-to-nearest and $\hat{x}$ is the dequantized approximation used in arithmetic. For symmetric weight quantization ($z=0$) at $b$ bits, the integer range is $[-(2^{b-1}-1),\,2^{b-1}-1]$, i.e. 15 levels at $b=4$, and the scale is set from the weight magnitude,

$$ s \;=\; \frac{\max_i |w_i|}{2^{\,b-1}-1}. \qquad\qquad (2.10) $$

A single scale for an entire weight tensor (**per-tensor** quantization) is coarse: one large outlier weight inflates $s$ and crushes the resolution available to all the others. **Group-wise** quantization instead partitions each weight matrix into contiguous groups of $g$ values (we use $g=128$) and assigns each group its own scale, so a local outlier only degrades its own group. Group-wise scales cost a small amount of storage (one FP16 scale per group) but recover much of the accuracy lost at 4 bits, and they are well supported by mobile INT4 kernels.

A small worked example makes the outlier problem concrete. Suppose a group of weights lies in $[-0.10, 0.12]$ but for one stray value of $0.95$. Under symmetric per-tensor 4-bit quantization the scale is set by the maximum magnitude, $s = 0.95 / 7 \approx 0.136$, so every "normal" weight near $\pm 0.1$ rounds to integer level $0$ or $\pm 1$—effectively one bit of resolution for the weights that actually matter, while the single outlier consumes the whole dynamic range. Group-wise quantization confines that damage: only the 128-weight group containing the outlier suffers the coarse scale, while every other group sets its scale from its own modest range (here $s \approx 0.12/7 \approx 0.017$) and keeps roughly three usable bits. The storage overhead is one 16-bit scale per 128 weights, i.e. about $16/128 = 0.125$ bits per weight, which raises the effective weight cost from 4.0 to about 4.125 bits—a small price for a large robustness gain. This is the mechanism behind the "+group-wise" step in the quantization ablation of Section 3.7.

### 2.3.2 Why naive 4-bit quantization is inadequate here

Applying per-tensor 4-bit post-training quantization to the distilled student drops average word accuracy from 90.8% to 84.4%—a 6.4-point loss that erases most of the benefit distillation provided. Two causes dominate. First, **not all layers tolerate 4 bits equally.** The DenseNet stem (which sees raw pixels and has small, high-impact kernels) and the CTC head (whose logits are read directly by the decoder) are far more sensitive than the bulk of the ViT layers; quantizing them to 4 bits injects error at the two ends of the network where it propagates most. Second, **post-training rounding has no chance to compensate.** Each weight is rounded in isolation, and the accumulated error is never corrected by training. The two improvements below address these two causes directly.

### 2.3.3 Improvement 1 — Sensitivity-aware mixed-precision quantization

**Motivation.** If a few layers are responsible for most of the 4-bit loss, then spending a slightly higher bit-width on *only those layers* should recover most of the accuracy at almost no size cost. The question is how to identify them without an expensive search.

**Method.** We use a simple, direct sensitivity probe. For each quantizable layer $\ell$, we quantize *that layer alone* to 4 bits (leaving all others at full precision) and measure how much the model's output distribution changes on a small calibration set, using the average per-frame KL divergence from the full-precision output:

$$ \Omega_\ell \;=\; \frac{1}{N}\sum_{n=1}^{N}\frac{1}{T_n}\sum_{k=1}^{T_n} \mathrm{KL}\!\left(\mathbf{p}^{\mathrm{fp}}_{n,k}\;\big\|\;\mathbf{p}^{(\ell)}_{n,k}\right). \qquad\qquad (2.11) $$

A large $\Omega_\ell$ means layer $\ell$ is fragile under 4-bit quantization. We then sort layers by $\Omega_\ell$ and keep the most sensitive ones at 8 bits, subject to a size budget; all remaining layers use group-wise 4-bit. Figure 2.6 shows the measured profile: the DenseNet stem, the first ViT layer, and the CTC head stand out, while the middle ViT layers are quantization-robust. Keeping just those three groups at 8 bits costs a fraction of a megabyte but removes the bulk of the naive-4-bit loss.

![Per-layer quantization sensitivity $\Omega_\ell$ measured by Equation (2.11). The DenseNet stem, the first ViT layer, and the CTC head (red, above threshold) are kept at 8 bits; the quantization-robust middle layers (teal) use group-wise 4-bit.](figures/fig_sensitivity.png){width=88%}

This is the classic mixed-precision insight [40; 41] reduced to its simplest, most transparent form: a one-shot, per-layer KL probe rather than a Hessian computation or a reinforcement-learning search. The simplicity is deliberate—the goal is a recipe that is easy to reproduce and reason about, consistent with the thesis's emphasis on clear, logical improvement over mathematical depth.

The probe is summarized in Algorithm 2.2. It is *one-shot* in the sense that each layer is measured exactly once, in isolation, against the full-precision reference; there is no iterative search and no retraining inside the loop. For a network of $L$ quantizable layers this costs $L+1$ forward passes over a small calibration set of a few hundred lines—seconds of compute—after which the bit assignment is fixed.

> **Algorithm 2.2 — One-shot per-layer sensitivity probe**
> **Input:** full-precision student $\mathcal{S}_{\mathrm{fp}}$; calibration set $\{x_n\}_{n=1}^{N}$; size budget $B$
> compute reference outputs $\mathbf{p}^{\mathrm{fp}}_{n} \leftarrow \mathcal{S}_{\mathrm{fp}}(x_n)$ for all $n$
> **for** each quantizable layer $\ell$ **do**
> &nbsp;&nbsp; quantize layer $\ell$ alone to 4-bit; keep all other layers full-precision
> &nbsp;&nbsp; $\Omega_\ell \leftarrow \frac{1}{N}\sum_n \frac{1}{T_n}\sum_k \mathrm{KL}\big(\mathbf{p}^{\mathrm{fp}}_{n,k}\,\|\,\mathbf{p}^{(\ell)}_{n,k}\big)$ &nbsp; *(Eq. 2.11)*
> &nbsp;&nbsp; restore layer $\ell$ to full precision
> sort layers by $\Omega_\ell$ (descending)
> assign 8-bit to the most-sensitive layers until the size budget $B$ is reached; 4-bit (group-wise) to the rest
> **return** per-layer bit-width assignment

In our network the probe consistently flags three groups—the DenseNet stem, the first ViT layer, and the CTC head—as the high-$\Omega_\ell$ outliers, matching the intuition of Section 2.3.2 that the layers at the pixel-facing and logit-facing ends of the network are the fragile ones. Keeping exactly those at 8-bit is what the "+sensitivity MP" step of the ablation measures.

### 2.3.4 Improvement 2 — Quantization-aware knowledge distillation (QA-KD)

**Motivation.** Even with mixed precision, group-wise 4-bit weights still introduce rounding error that no amount of clever scale selection fully removes. The remedy is to let the network *adapt* to its own quantization through training—but training a 4-bit model from labels alone is unstable and discards the representational knowledge we worked to instill. We instead reuse distillation a second time.

**Method.** We initialize a quantization-aware copy of the student from the full-precision distilled weights and fine-tune it with simulated quantization in the forward pass. Gradients pass through the rounding operation via the straight-through estimator, and the quantization step sizes are themselves learned, as in LSQ [35]:

$$ \frac{\partial \hat{x}}{\partial x} \approx \mathbf{1}_{[q_{\min}\le \lfloor x/s\rceil \le q_{\max}]}, \qquad s \leftarrow s - \eta\,\frac{\partial \mathcal{L}}{\partial s}. \qquad\qquad (2.12) $$

Crucially, the supervisory signal during this fine-tuning is **the full-precision student acting as a self-teacher**, combined with the ground-truth CTC loss:

$$ \mathcal{L}_{\mathrm{QA\text{-}KD}} \;=\; \mathcal{L}_{\mathrm{CTC}} \;+\; \lambda_{\mathrm{kd}}\,\mathcal{L}_{\mathrm{kd}}^{\,\mathrm{fp}\to q} \;+\; \lambda_{\mathrm{hid}}\,\mathcal{L}_{\mathrm{hid}}^{\,\mathrm{fp}\to q}, \qquad\qquad (2.13) $$

where the KD and hidden terms are exactly those of Section 2.2 but with the *full-precision student* as teacher and the *quantized student* as student. Because the two networks are architecturally identical, the hidden states align one-to-one with no projector needed (an identity map), which makes this self-distillation especially clean and stable. Figure 2.7 shows the arrangement.

![Quantization-aware knowledge distillation (QA-KD). The 4-bit student is initialized from the full-precision student and fine-tuned with learned step sizes; the frozen full-precision student supervises it through the same KD and hidden losses, now with identity alignment.](figures/fig_qakd.png){width=82%}

**Why it helps, stated plainly.** Quantization-aware fine-tuning lets the weights move to values that round well, and the self-teacher keeps the quantized network anchored to the representation the full-precision model already learned, so the fine-tuning recovers accuracy instead of drifting. Using the model's own full-precision version as teacher means no extra large model is needed at this stage and the alignment is exact.

### 2.3.5 The full quantization pipeline

The complete procedure is summarized in Figure 2.8: train the teacher; distill the student with the two Section-2.2 improvements; run the one-shot sensitivity probe to assign bit-widths; and fine-tune the mixed-precision 4-bit student with QA-KD. The output is an INT4 model with a handful of INT8 layers, group-wise scales, and—after folding the training-only projectors away—exactly the backbone of Table 2.1, now occupying 2.7 MB. Table 2.2 previews the size and accuracy at each stage; the full measurements appear in Chapter 3.

For completeness, Algorithm 2.3 states the QA-KD fine-tune. It differs from Algorithm 2.1 in three ways: the student carries simulated quantizers with learnable step sizes, the teacher is the *frozen full-precision student* rather than the large teacher, and the hidden alignment is an identity map because the two networks are architecturally identical, so no projectors are needed.

> **Algorithm 2.3 — Quantization-aware knowledge distillation (QA-KD)**
> **Input:** full-precision student $\mathcal{S}_{\mathrm{fp}}$ (frozen self-teacher); bit assignment from Alg. 2.2
> initialize quantized student $\mathcal{S}_{q}$ from $\mathcal{S}_{\mathrm{fp}}$; attach group-wise quantizers with learnable steps $s$
> **for** each minibatch $(x,y)$ **do**
> &nbsp;&nbsp; $(\mathbf{p}^{\mathrm{fp}}, \{H^{\mathrm{fp}}\}) \leftarrow \mathcal{S}_{\mathrm{fp}}(x)$ &nbsp; *(no gradient)*
> &nbsp;&nbsp; $(\mathbf{p}^{q}, \{H^{q}\}) \leftarrow \mathcal{S}_{q}(x)$ &nbsp; *(simulated quantization in forward pass)*
> &nbsp;&nbsp; $\mathcal{L} \leftarrow \mathcal{L}_{\mathrm{CTC}}(\mathbf{p}^{q},y) + \lambda_{\mathrm{kd}}\,\mathrm{KL}(\mathbf{p}^{\mathrm{fp}}\|\mathbf{p}^{q}) + \lambda_{\mathrm{hid}}\,\mathrm{MSE}(\bar H^{\mathrm{fp}}, \bar H^{q})$ &nbsp; *(Eq. 2.13)*
> &nbsp;&nbsp; update weights and step sizes $s$ via STE: $\partial\hat x/\partial x \approx \mathbf{1}_{[\,q_{\min}\le \lfloor x/s\rceil \le q_{\max}\,]}$ &nbsp; *(Eq. 2.12)*
> **return** quantized student $\mathcal{S}_{q}$; export INT4/INT8 weights and group scales

Because the fine-tune starts from an already-accurate model and is supervised by that same model, it converges in only eight epochs at a reduced learning rate (Table 3.2), in contrast to the thirty epochs used to train the student from scratch—another reflection of the principle that reusing the representation we already paid for is cheaper than relearning it.

![The end-to-end pipeline: teacher training, hidden-level distillation, sensitivity analysis, mixed-precision 4-bit quantization with QA-KD, and INT4 export for deployment.](figures/fig_pipeline.png){width=95%}

Table: Model state after each stage of the pipeline (average word accuracy over the six benchmarks; see Chapter 3).

| Stage | Bit-width | Size | Avg. word acc. |
|---|---|---|---|
| Teacher | FP32 | 108.3 MB | 93.1% |
| Student, labels only | FP32 | 18.4 MB | 86.8% |
| Student, distilled (Sec. 2.2) | FP32 | 18.4 MB | 90.8% |
| Student, naive 4-bit PTQ | 4-bit | 2.6 MB | 84.4% |
| Student, proposed 4-bit (Sec. 2.3) | 4/8-bit | 2.7 MB | 89.8% |

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Chapter 3. System Construction, Implementation, and Experiments

## 3.1 On-device system architecture

A recognizer does not run in isolation; it sits inside a pipeline that turns a camera frame into text. Figure 3.1 shows the on-device system. An input image (from the camera or gallery) is first passed to a lightweight text-line **detector** that proposes line regions; each region is cropped, rectified, and normalized to the fixed 32-pixel height expected by the recognizer. The **INT4 recognizer of this thesis** consumes each line and emits per-frame character distributions, which a **CTC decoder** turns into a string with a confidence score. The result is handed to the application layer—search indexing, text-to-speech, translation, and so on. Everything runs locally; no network call is involved, which is what makes the pipeline usable offline and private by construction.

![The on-device recognition system. Detection, cropping/normalization, the INT4 recognizer (this work), and CTC decoding all run locally. The recognizer is the focus of this thesis; the surrounding stages are standard.](figures/fig_system.png){width=92%}

This thesis concentrates on the recognizer, which is the accuracy- and cost-determining stage. Detection and rectification are treated as fixed, standard components so that the comparisons isolate the recognizer's contribution.

## 3.2 Implementation details

The models are implemented in PyTorch for training and exported through an INT4-capable mobile inference runtime for deployment. Group-wise 4-bit weights with INT8-accumulating matrix multiplies are supported by current mobile NPU and CPU kernels, which is why we choose group-wise (rather than per-channel-only) quantization and a group size of 128 that aligns with those kernels. The training-only projectors and gates of Section 2.2.7 are removed before export, so the deployed graph is exactly the backbone of Table 2.1. CTC decoding uses greedy decoding by default (fastest) with optional beam search; all reported accuracies use greedy decoding to reflect the cheapest deployable setting.

On-device measurements are taken on a mid-range mobile system-on-chip representative of mainstream phones, single-threaded on the NPU where INT4 kernels are available and on the CPU otherwise, with the model and a warm cache, averaged over many single-line inferences. We report the recognizer alone (excluding detection) so that the numbers reflect the component this thesis optimizes.

**Where the footprint goes.** It is worth separating the three quantities that the four mobile constraints of Section 1.2 actually depend on, because they scale differently. *On-disk size* is dominated by the weights: at FP32 the 4.8 M-parameter student occupies $4.8\text{M} \times 4\,\text{bytes} \approx 18.4$ MB; at the proposed mixed 4/8-bit precision the same weights occupy about 2.7 MB, the small excess over a pure-4-bit 2.6 MB coming from the few 8-bit layers and the group scales. *Peak working memory* is governed not by weights alone but by the largest activation tensors held simultaneously during the forward pass; because the ViT encoder operates on a single collapsed sequence of $T$ tokens rather than a 2-D feature map, these activations are modest, which is why the deployed peak memory (31 MB) is only an order of magnitude above the weight size rather than two. *Latency and energy* track the number of multiply–accumulate operations and, importantly, the *precision* at which they run: INT4 and INT8 matrix multiplies move fewer bytes and use cheaper arithmetic units than FP32, so quantization improves latency and energy even beyond what the size reduction alone would suggest. This is the reason the INT4 model in Section 3.9 is not merely smaller but also faster and more energy-efficient than the INT8 model, despite both having the same architecture.

## 3.3 Datasets

Following standard practice in scene-text recognition, the models are trained on large **synthetic** corpora and evaluated on **real** benchmark test sets. Training uses MJSynth/Synth90k [45] and SynthText [46], which together provide millions of rendered word images with known labels and cost nothing to annotate. Evaluation uses six widely reported real benchmarks, summarized in Table 3.1: IIIT5K [47], Street View Text (SVT) [48], ICDAR 2013 (IC13) [49], ICDAR 2015 (IC15) [50], and the perspective and curved sets SVTP and CUTE80. IIIT5K, SVT, and IC13 are "regular" (mostly horizontal) text; IC15, SVTP, and CUTE80 are "irregular" (perspective, curved, low-quality) and are markedly harder, which is why per-dataset reporting matters.

Table: Evaluation benchmarks. "Regular" sets are mostly horizontal; "irregular" sets contain perspective, curved, or degraded text and are substantially harder.

| Benchmark | Type | Test images | Difficulty |
|---|---|---|---|
| IIIT5K [47] | Regular | 3,000 | Easy–moderate |
| SVT [48] | Regular | 647 | Moderate (low-res, outdoor) |
| IC13 [49] | Regular | 1,015 | Easy |
| IC15 [50] | Irregular | 2,077 | Hard (perspective, blur) |
| SVTP | Irregular | 645 | Hard (perspective) |
| CUTE80 | Irregular | 288 | Hard (curved) |

The distillation set (used to train the student and for QA-KD) is drawn from the same synthetic corpora; importantly, distillation does not require *labeled* data—the teacher's outputs and hidden states are themselves the supervisory signal—so in practice the distillation pool could be enlarged with unlabeled real lines, an option we note but do not exploit in the controlled comparison.

A word on why the field trains on synthetic data and tests on real data, since the protocol can look unusual to readers outside scene-text recognition. Hand-labeling enough real cropped word images to train a modern recognizer is prohibitively expensive, whereas synthetic engines such as MJSynth [45] and SynthText [46] can render millions of word images with perfect labels, varied fonts, colors, blur, and backgrounds at essentially zero annotation cost. Models trained on this synthetic distribution transfer surprisingly well to real photographs, and the community has standardized on the six real test sets of Table 3.1 as the common yardstick, which is what makes cross-paper comparison meaningful. We follow this protocol exactly so that our teacher and baselines occupy the same evaluation frame as the prior models in Table 3.3. The split into "regular" and "irregular" sets is not cosmetic: the regular sets measure raw reading accuracy on clean horizontal text, while the irregular sets stress the model's tolerance to perspective, curvature, and degradation—the conditions under which a compact, language-model-free CTC student is most challenged, and therefore the conditions under which the value of distillation is easiest to see.

## 3.4 Evaluation metrics

We report four families of metrics, matching the four mobile constraints of Section 1.2:

- **Word accuracy.** The fraction of test images whose predicted string exactly matches the ground truth, case-insensitive over the 36-symbol alphabet (digits and letters), the standard scene-text metric. This is the primary accuracy number.
- **Character-level error.** To capture partial correctness we also use the normalized edit distance; we report accuracy-oriented results in the text and use the edit distance in error analysis (Section 3.11).
- **Footprint.** Parameter count and on-disk model size (MB).
- **On-device cost.** Latency per text line (ms), peak runtime memory (MB), and energy per inference (mJ), measured as in Section 3.2.

## 3.5 Training setup

Table 3.2 lists the main hyperparameters. The teacher and student are trained with AdamW and a cosine learning-rate schedule; the QA-KD fine-tuning stage is short and uses a smaller learning rate, since it starts from an already-good full-precision model. Standard scene-text augmentations (mild rotation, perspective warp, blur, and noise) are applied during training but not at test time.

Table: Training hyperparameters. The QA-KD stage is a short fine-tune from the full-precision student.

| Setting | Teacher / Student | QA-KD fine-tune |
|---|---|---|
| Optimizer | AdamW | AdamW |
| Learning rate | 5×10⁻⁴ (cosine) | 5×10⁻⁵ (cosine) |
| Weight decay | 0.01 | 0.01 |
| Batch size | 384 | 384 |
| Epochs | 30 | 8 |
| Input size | 32 × (≤256) | 32 × (≤256) |
| Alphabet | 36 + blank | 36 + blank |
| Max label length | 25 | 25 |
| KD weight $\lambda_{\mathrm{kd}}$ | 0.5 | 0.5 |
| Hidden weight $\lambda_{\mathrm{hid}}$ | 1.0 | 1.0 |
| Temperature $\tau$ | 2.0 | 2.0 |

Figure 3.2 shows the training dynamics. The student trained with distillation tracks the teacher's validation accuracy far more closely than a label-only student would, and its loss—comprising the CTC, blank-aware KD, and multi-stage hidden terms—decreases smoothly, indicating that the auxiliary distillation terms do not destabilize CTC training.

![Training dynamics. The teacher and the distilled student both converge smoothly; the student's validation word accuracy rises toward the teacher's, reflecting effective knowledge transfer.](figures/fig_training.png){width=78%}

## 3.6 Main results: comparison against prior models

Table 3.3 is the central comparison. It reports per-benchmark and average word accuracy, parameter count, and FP32 size for representative prior recognizers and for our models. The prior numbers are representative values consistent with the published literature and our re-measurements under the common evaluation protocol; they are intended to position our models, not to re-adjudicate prior work. Figure 3.3 visualizes the per-benchmark accuracies for the most relevant comparison points.

Table: Main comparison on six scene-text benchmarks (word accuracy, %). "Avg" is the unweighted mean over the six sets. Sizes are FP32 except where noted. Prior figures are representative values under the common protocol.

| Model | Params | Size | IIIT5K | SVT | IC13 | IC15 | SVTP | CUTE | Avg |
|---|---|---|---|---|---|---|---|---|---|
| CRNN [9] | 8.3 M | 31.7 MB | 84.5 | 80.8 | 88.0 | 61.0 | 65.0 | 61.5 | 73.5 |
| ASTER [11] | 27.0 M | 103 MB | 93.4 | 89.5 | 91.8 | 76.1 | 78.5 | 79.5 | 84.8 |
| SVTR-T [17] | 6.0 M | 22.9 MB | 94.4 | 90.1 | 95.0 | 82.0 | 82.9 | 85.4 | 88.3 |
| PARSeq [18] | 23.8 M | 90.8 MB | 97.0 | 93.6 | 96.2 | 82.9 | 88.9 | 92.2 | 91.8 |
| **Teacher (ours)** | 28.4 M | 108.3 MB | 97.2 | 95.2 | 97.1 | 87.8 | 89.9 | 91.3 | **93.1** |
| Student, labels only | 4.8 M | 18.4 MB | 94.0 | 89.5 | 93.0 | 80.5 | 80.8 | 83.0 | 86.8 |
| **Student, distilled (FP)** | 4.8 M | 18.4 MB | 96.3 | 93.0 | 95.8 | 85.2 | 86.5 | 88.2 | **90.8** |
| Student, naive 4-bit | 4.8 M | 2.6 MB | 92.0 | 86.5 | 90.8 | 78.0 | 78.5 | 80.6 | 84.4 |
| **Student, proposed 4-bit** | 4.8 M | 2.7 MB | 95.6 | 92.1 | 95.0 | 84.0 | 85.3 | 86.9 | **89.8** |

![Per-benchmark word accuracy for representative prior models and our teacher and final 4-bit student. The 4-bit student stays close to much larger full-precision models, especially on the regular sets, and remains competitive on the harder irregular sets.](figures/fig_perdataset.png){width=95%}

Three readings of Table 3.3 are worth stating explicitly. First, **distillation closes most of the small-model gap**: the distilled full-precision student reaches 90.8% average accuracy, 4.0 points above the identically sized label-only student (86.8%) and within 2.3 points of the 28.4 M-parameter teacher, while being roughly six times smaller. Second, **the proposed 4-bit model is competitive with full-precision prior models many times its size**: at 2.7 MB it reaches 89.8% average accuracy, ahead of CRNN and ASTER and close to SVTR-T, despite being an order of magnitude smaller on disk. Third, **the quantization method matters enormously at 4 bits**: naive post-training quantization of the same student loses 6.4 points (to 84.4%), whereas the proposed recipe loses only 1.0 point relative to the full-precision student. The remaining gap to PARSeq (91.8%) is concentrated on the irregular sets and is the expected price of an order-of-magnitude size reduction and a non-autoregressive, language-model-free decoder chosen for on-device speed.

It is instructive to separate the regular and irregular subsets, since they tell slightly different stories. Averaging the three regular sets (IIIT5K, SVT, IC13), the proposed 4-bit student scores about 94.2%, only ~1.0 point below the full-precision student (95.0%) and within ~1.5 points of PARSeq (95.6%)—on clean horizontal text the compact 4-bit model is, for practical purposes, as good as recognizers many times its size. Averaging the three irregular sets (IC15, SVTP, CUTE80), the proposed student scores about 85.4% against PARSeq's 88.0%: the gap that remains is almost entirely here, on perspective and curved text, exactly where an explicit rectifier or an autoregressive language model would help most and where our deliberately minimal single-pass CTC student gives up the most. This decomposition matters for a deployment decision: an application dominated by document-like, roughly horizontal capture loses almost nothing by adopting the 2.7 MB model, whereas one that must read heavily distorted scene text in the wild should weigh the few-point accuracy difference against the order-of-magnitude savings in size, latency, and energy. The figure that accompanies this table (Figure 3.3) shows the same pattern visually: the bars for our 4-bit student sit essentially on top of the larger models for the regular sets and fall slightly below them for the irregular sets.

## 3.7 Ablation studies

The ablations isolate the contribution of each of the four improvements by adding them one at a time.

**Distillation (Figure 3.4).** Starting from a label-only student (86.8%), adding the blank-aware logit term raises accuracy to 88.2%; adding uniform hidden distillation raises it to 89.3%; adding the **CTC-confidence weighting** (Improvement 1) raises it to 90.1%; and adding **multi-stage adaptive alignment** (Improvement 2) brings the full method to 90.8%. Each improvement contributes a clear, separable gain—about 0.8 and 0.7 points respectively—and neither subsumes the other, confirming that "which frames" and "which depths" are complementary questions.

![Ablation of the distillation components (full-precision student). Each component adds a clear, separable gain; the two proposed improvements (confidence weighting and multi-stage alignment) contribute the final 1.5 points together.](figures/fig_abl_kd.png){width=82%}

**Quantization (Figure 3.5).** Starting from the full-precision student (90.8%), naive per-tensor 4-bit PTQ falls to 84.4%; switching to group-wise scales recovers to 86.5%; adding **sensitivity-aware mixed precision** (Improvement 1) recovers to 88.3%; and adding **QA-KD** (Improvement 2) reaches 89.8%. The two quantization improvements together recover 3.3 of the 6.4 points lost by naive PTQ, with group-wise scaling contributing the remainder—again, each step is individually measurable.

![Ablation of the 4-bit quantization components. Group-wise scaling, sensitivity-aware mixed precision (Improvement 1), and QA-KD (Improvement 2) each recover a measurable share of the accuracy lost by naive post-training quantization.](figures/fig_abl_quant.png){width=82%}

**Loss-weight sensitivity.** Table 3.4 shows that the method is not delicate with respect to the loss weights of Equation (2.8): varying $\lambda_{\mathrm{hid}}$ and $\lambda_{\mathrm{kd}}$ over a reasonable range moves average accuracy by only a few tenths of a point, so no fine tuning is required to reproduce the result.

Table: Sensitivity to the distillation loss weights (full-precision student, average word accuracy %).

| $\lambda_{\mathrm{hid}}$ \\ $\lambda_{\mathrm{kd}}$ | 0.25 | 0.5 | 1.0 |
|---|---|---|---|
| 0.5 | 90.3 | 90.5 | 90.4 |
| 1.0 | 90.6 | **90.8** | 90.6 |
| 2.0 | 90.5 | 90.6 | 90.3 |

**Consolidated view of the four improvements.** Table 3.4b gathers the two ablation chains into a single accounting so that the contribution of each of the four improvements can be read at a glance. The distillation chain moves a label-only student from 86.8% to 90.8% (a 4.0-point gain), of which the two proposed improvements supply 1.5 points and the baseline logit and uniform-hidden terms supply the other 2.5. The quantization chain then moves the full-precision student to a deployable 4-bit model while surrendering only 1.0 point (90.8% → 89.8%), where a naive baseline would have surrendered 6.4; the two proposed quantization improvements account for 3.3 of the 5.4 recovered points, with group-wise scaling supplying the remaining 2.1. No single improvement dominates, and—crucially for the thesis's claim of *separable, measured* gains—each one is individually visible in a controlled comparison against the variant immediately below it.

Table: Consolidated contribution of each component. The distillation chain is measured at full precision; the quantization chain starts from the distilled full-precision student. "Δ" is the gain over the row above.

| Stage | Variant | Avg. acc. (%) | Δ |
|---|---|---|---|
| Distillation | Student, labels only | 86.8 | — |
| | + blank-aware logit KD | 88.2 | +1.4 |
| | + uniform hidden distillation | 89.3 | +1.1 |
| | **+ CTC-confidence weighting (Impr. 1)** | 90.1 | **+0.8** |
| | **+ multi-stage alignment (Impr. 2)** | 90.8 | **+0.7** |
| Quantization | Naive per-tensor 4-bit PTQ | 84.4 | −6.4 |
| | + group-wise scales | 86.5 | +2.1 |
| | **+ sensitivity-aware mixed precision (Impr. 1)** | 88.3 | **+1.8** |
| | **+ QA-KD (Impr. 2)** | 89.8 | **+1.5** |

## 3.8 Robustness to bit-width

To show that the gain is specific to the difficult low-bit regime rather than a general offset, Figure 3.6 sweeps the weight bit-width for naive PTQ and for the proposed method. At 8 and 6 bits the two are nearly indistinguishable—quantization is easy there—but at 4 bits the proposed method is 5.4 points higher, and the gap widens further at 3 bits. This is the expected signature of a method that targets the regime where naive quantization breaks down: it buys little where quantization is already easy and a great deal where it is hard.

![Word accuracy versus weight bit-width. Naive PTQ and the proposed method agree at 8 and 6 bits but diverge sharply at 4 bits and below, where the sensitivity-aware allocation and QA-KD do their work.](figures/fig_bitwidth.png){width=72%}

## 3.9 On-device cost

Table 3.5 and Figure 3.7 report the deployed cost of the student at three precisions. Moving from FP32 to the proposed 4-bit model shrinks the on-disk size by 6.8× (18.4 MB → 2.7 MB), cuts latency per line by 2.2× (41 ms → 18.5 ms), reduces peak memory by 3.1× (96 MB → 31 MB), and more than halves energy per inference (210 mJ → 92 mJ). The 4-bit model is faster and lighter than the INT8 model while giving up only a small amount of accuracy, which is precisely the trade the on-device setting calls for.

The relationship between the precisions repays a closer look against the four constraints of Section 1.2. On *storage*, the progression 18.4 → 4.9 → 2.7 MB tracks the weight precision almost linearly, as expected. On *latency*, the gains are sub-linear in the bit-width because a forward pass is not purely weight-bound: fixed costs (layer-norm, attention softmax, the CTC collapse, kernel-launch overhead) do not shrink with precision, so the 41 → 24 → 18.5 ms progression flattens at the low-bit end. On *memory*, the 96 → 42 → 31 MB reduction comes partly from smaller weights and partly from lower-precision activation buffers, and it is what allows the recognizer to coexist with the camera pipeline rather than being evicted under memory pressure. On *energy*, the 210 → 128 → 92 mJ reduction matters for sustained use: a viewfinder feature that reads several lines per video frame, for minutes at a time, lives or dies by per-inference energy, and halving it directly extends how long the feature can run before the device throttles. Taken together, the proposed INT4 model is the only one of the three configurations that satisfies all four constraints simultaneously—small enough to ship, light enough to coexist, fast enough to feel interactive, and cool enough to sustain.

Table: On-device cost of the student model at three precisions (recognizer only, mid-range mobile SoC, single text line).

| Precision | Size | Latency / line | Peak memory | Energy / inference |
|---|---|---|---|---|
| FP32 | 18.4 MB | 41.0 ms | 96 MB | 210 mJ |
| INT8 | 4.9 MB | 24.0 ms | 42 MB | 128 mJ |
| **INT4 (proposed)** | **2.7 MB** | **18.5 ms** | **31 MB** | **92 mJ** |

![On-device cost of the student at FP32, INT8, and the proposed INT4. The 4-bit model is the smallest, fastest, and most energy-efficient of the three.](figures/fig_ondevice.png){width=98%}

## 3.10 Putting it together

Read jointly, the experiments support the thesis's central claim. Distillation lets a 4.8 M-parameter student behave like a model far larger than itself (Section 3.6); the two distillation improvements each add separable accuracy (Section 3.7); the sensitivity-aware, distillation-assisted 4-bit recipe preserves almost all of that accuracy while naive quantization does not (Sections 3.7–3.8); and the resulting model meets all four mobile constraints simultaneously (Section 3.9). No single step is responsible—the result comes from designing distillation and quantization together around one architecture.

It is worth contrasting this combined strategy with the obvious alternatives, because the comparison explains why both stages are necessary rather than just one. *Training a small model from scratch on labels alone* is the simplest option and is exactly the 86.8% label-only student of Table 3.3; it forgoes the 4.0 points that distillation supplies and still needs compression afterward. *Applying INT8 quantization only* to the distilled student yields the 4.9 MB / 90.6%-class configuration of Section 3.9—accurate, but nearly twice the size and a third slower than the INT4 model, leaving easy savings on the table. *Quantizing a large model directly to 4-bit*, skipping distillation, starts from the teacher's accuracy but inherits the teacher's parameter count, so even at 4 bits it remains far larger than a phone budget allows and discards the entire point of having a compact student. *Naive 4-bit PTQ of the distilled student*—the cheapest compression—collapses to 84.4% (Section 3.7), erasing most of the distillation benefit. Only the combination used here, distillation to build a strong small model followed by a sensitivity-aware, distillation-assisted 4-bit recipe to compress it without losing that strength, reaches the small-*and*-accurate corner. The two techniques are not interchangeable and not merely additive: distillation makes a small model worth quantizing, and the careful quantization makes the distilled model deployable.

## 3.11 Qualitative and error analysis

Inspecting failures clarifies where the remaining gap lives. On the regular sets (IIIT5K, IC13) the 4-bit student is essentially indistinguishable from the full-precision student; the few errors are shared by both and involve genuinely ambiguous glyphs or annotation noise. On the irregular sets the 4-bit student's additional errors cluster in two places: severe perspective distortion, where the CTC model's lack of an explicit rectification stage and language model costs it relative to PARSeq, and very low-resolution lines, where fine stroke detail is lost before the recognizer sees it. Errors are predominantly single-character substitutions between visually similar glyphs (for example 0/O, 1/l/I, 5/S), which the normalized edit distance shows are "near misses" rather than wholesale failures—consistent with a small, fast model that reads shapes well but lacks a strong language prior to correct them.

It is useful to group the residual failures into four recurring categories, because each points to a different (and, in principle, separately addressable) cause. *Confusable-glyph substitutions* are the largest category and are exactly the cases a language model would fix: a human reads "l1lI" correctly from word context, but a context-free CTC decoder cannot. *Distortion failures* occur on steeply slanted or curved lines where, without rectification, the column-to-character correspondence that CTC relies on is locally violated; these are concentrated on SVTP and CUTE80 and explain most of the irregular-set gap in Table 3.3. *Resolution failures* arise when the input line is so small that strokes merge before the stem can separate them—an input-quality limit no recognizer-side change can fully overcome, and one shared by the full-precision model. *Quantization-specific failures*, finally, are the ones unique to the 4-bit model and absent in the full-precision student; reassuringly, these are rare and almost always borderline cases where the full-precision model was itself only marginally confident, which is the signature of a quantization recipe that preserves the decision boundary rather than distorting it. The first three categories are inherited from the architecture and the input, not introduced by compression; only the fourth is the "cost" of going to 4 bits, and it is small.

The confidence-weighting analysis of Figure 2.3 also explains a qualitative observation: because the hidden transfer concentrated on character frames, the student's per-frame confidence on character positions is noticeably better calibrated than that of the label-only student, which is useful downstream because the application layer (Figure 3.1) uses the confidence score to decide when to ask the user to re-capture.

## 3.12 Discussion and limitations

Several limitations bound the claims. The experiments use a 36-symbol Latin alphabet; large-alphabet scripts (for example Chinese, Japanese, or Korean) enlarge the CTC head, which is one of the quantization-sensitive layers identified in Section 2.3.3, so the mixed-precision budget would need revisiting for those scripts. The reported on-device numbers are for a single representative SoC class; absolute latency and energy will vary with the specific NPU and its INT4 kernel quality, although the *relative* improvements should hold. The comparison treats detection and rectification as fixed; an end-to-end system would need to account for their cost and error propagation. Finally, the prior-model figures are representative rather than freshly re-trained for every baseline, so Table 3.3 should be read as a positioning of our models within the known landscape rather than as a controlled re-benchmark of all prior work. None of these qualifications affects the internal ablations (Sections 3.7–3.8), which compare variants of our own model under identical conditions and are where the four improvements are actually isolated.

## 3.13 Reproducibility and practical guidance

Because the contribution of this thesis is a *recipe* rather than a single trained artifact, it is worth stating what a practitioner needs to reproduce it and what choices are safe to vary. The architecture is fully specified by Table 2.1; the training schedule by Table 3.2; and the four improvements by the equations and algorithm boxes of Chapter 2. The data protocol is the field-standard synthetic-train / real-test setup of Section 3.3, which requires no proprietary corpus. Three practical points are worth emphasizing. First, the loss-weight study of Table 3.4 shows the method is insensitive to $\lambda_{\mathrm{kd}}$ and $\lambda_{\mathrm{hid}}$ within a wide band, so these need not be retuned. Second, the sensitivity probe of Algorithm 2.2 is deterministic given a calibration set and costs only $L+1$ forward passes, so the mixed-precision assignment can simply be recomputed for any new architecture rather than copied from this thesis; the three layers it selects here (stem, first ViT layer, CTC head) are a reasonable starting guess but should be verified by the probe. Third, the QA-KD stage is short (eight epochs) and stable precisely because it starts from, and is supervised by, the full-precision student—skipping the full-precision distillation and trying to train a 4-bit model directly is the one shortcut that does *not* work, as the naive-4-bit and label-only rows of Table 3.3 jointly illustrate. The intended takeaway for a practitioner is that the gains reported here come from following the four steps in order, not from delicate hyperparameter tuning at any single step.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# Chapter 4. Conclusion

This thesis presented an end-to-end recipe for running a text-line character recognizer on a mobile phone: build a high-capacity Dense+ViT+CTC teacher and a compact student of the same family, transfer the teacher's knowledge through hidden-level distillation, and compress the student to 4-bit weights. Rather than claim a single new mechanism, the work makes four deliberately modest, clearly delimited improvements and measures each in isolation. In distillation, CTC-confidence weighting spends the transfer budget on character-bearing frames instead of the abundant blank frames, and multi-stage adaptive alignment matches teacher and student at several depths through training-only projectors that tolerate mismatched widths. In quantization, a one-shot per-layer sensitivity probe drives a mixed-precision allocation that protects the few fragile layers, and quantization-aware knowledge distillation reuses the full-precision student as a self-teacher to recover the rounding loss.

The combined effect is a 4.8 M-parameter, 2.7 MB model that reads a text line in 18.5 ms within 31 MB of memory and retains 89.8% average word accuracy across six benchmarks—4.0 points of which come from distillation that a label-only model of the same size cannot reach, and 5.4 points of which come from the quantization recipe that a naive 4-bit baseline throws away. The broader lesson is methodological: on mobile, distillation and quantization should not be treated as independent post-hoc steps but designed together around a shared architecture, so that the small model both *learns well* and *rounds well*.

Future work follows directly from the limitations of Section 3.12: extending the sensitivity-aware budget to large-alphabet scripts, folding a lightweight rectification or language prior into the student to close the irregular-text gap without sacrificing CTC's single-pass speed, and quantizing activations as aggressively as weights to unlock further latency on integer-only accelerators.

```{=openxml}
<w:p><w:r><w:br w:type="page"/></w:r></w:p>
```

# References

[1] Y. LeCun, L. Bottou, Y. Bengio, and P. Haffner, "Gradient-based learning applied to document recognition," *Proceedings of the IEEE*, vol. 86, no. 11, pp. 2278–2324, 1998.

[2] A. Krizhevsky, I. Sutskever, and G. E. Hinton, "ImageNet classification with deep convolutional neural networks," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2012, pp. 1097–1105.

[3] K. Simonyan and A. Zisserman, "Very deep convolutional networks for large-scale image recognition," in *International Conference on Learning Representations (ICLR)*, 2015.

[4] K. He, X. Zhang, S. Ren, and J. Sun, "Deep residual learning for image recognition," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 770–778.

[5] G. Huang, Z. Liu, L. van der Maaten, and K. Q. Weinberger, "Densely connected convolutional networks," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2017, pp. 4700–4708.

[6] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, Ł. Kaiser, and I. Polosukhin, "Attention is all you need," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2017, pp. 5998–6008.

[7] A. Dosovitskiy, L. Beyer, A. Kolesnikov, D. Weissenborn, X. Zhai, T. Unterthiner, M. Dehghani, M. Minderer, G. Heigold, S. Gelly, J. Uszkoreit, and N. Houlsby, "An image is worth 16×16 words: Transformers for image recognition at scale," in *International Conference on Learning Representations (ICLR)*, 2021.

[8] A. Graves, S. Fernández, F. Gomez, and J. Schmidhuber, "Connectionist temporal classification: Labelling unsegmented sequence data with recurrent neural networks," in *Proc. International Conference on Machine Learning (ICML)*, 2006, pp. 369–376.

[9] B. Shi, X. Bai, and C. Yao, "An end-to-end trainable neural network for image-based sequence recognition and its application to scene text recognition," *IEEE Trans. Pattern Analysis and Machine Intelligence (TPAMI)*, vol. 39, no. 11, pp. 2298–2304, 2017.

[10] B. Shi, X. Wang, P. Lyu, C. Yao, and X. Bai, "Robust scene text recognition with automatic rectification," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 4168–4176.

[11] B. Shi, M. Yang, X. Wang, P. Lyu, C. Yao, and X. Bai, "ASTER: An attentional scene text recognizer with flexible rectification," *IEEE Trans. Pattern Analysis and Machine Intelligence (TPAMI)*, vol. 41, no. 9, pp. 2035–2048, 2019.

[12] J. Baek, G. Kim, J. Lee, S. Park, D. Han, S. Yun, S. J. Oh, and H. Lee, "What is wrong with scene text recognition model comparisons? Dataset and model analysis," in *Proc. IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019, pp. 4715–4723.

[13] H. Li, P. Wang, C. Shen, and G. Zhang, "Show, attend and read: A simple and strong baseline for irregular text recognition," in *Proc. AAAI Conference on Artificial Intelligence (AAAI)*, 2019, pp. 8610–8617.

[14] C.-Y. Lee and S. Osindero, "Recursive recurrent nets with attention modeling for OCR in the wild," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 2231–2239.

[15] N. Lu, W. Yu, X. Qi, Y. Chen, P. Gong, R. Xiao, and X. Bai, "MASTER: Multi-aspect non-local network for scene text recognition," *Pattern Recognition*, vol. 117, p. 107980, 2021.

[16] R. Atienza, "Vision Transformer for fast and efficient scene text recognition," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2021, pp. 319–334.

[17] Y. Du, Z. Chen, C. Jia, X. Yin, T. Zheng, C. Li, Y. Du, and Y.-G. Jiang, "SVTR: Scene text recognition with a single visual model," in *Proc. International Joint Conference on Artificial Intelligence (IJCAI)*, 2022, pp. 884–890.

[18] D. Bautista and R. Atienza, "Scene text recognition with permuted autoregressive sequence models," in *Proc. European Conference on Computer Vision (ECCV)*, 2022, pp. 178–196.

[19] S. Fang, H. Xie, Y. Wang, Z. Mao, and Y. Zhang, "Read like humans: Autonomous, bidirectional and iterative language modeling for scene text recognition," in *Proc. IEEE/CVF Conf. Computer Vision and Pattern Recognition (CVPR)*, 2021, pp. 7098–7107.

[20] D. Yu, X. Li, C. Zhang, T. Liu, J. Han, J. Liu, and E. Ding, "Towards accurate scene text recognition with semantic reasoning networks," in *Proc. IEEE/CVF Conf. Computer Vision and Pattern Recognition (CVPR)*, 2020, pp. 12113–12122.

[21] G. Hinton, O. Vinyals, and J. Dean, "Distilling the knowledge in a neural network," in *NeurIPS Deep Learning and Representation Learning Workshop*, 2015.

[22] A. Romero, N. Ballas, S. E. Kahou, A. Chassang, C. Gatta, and Y. Bengio, "FitNets: Hints for thin deep nets," in *International Conference on Learning Representations (ICLR)*, 2015.

[23] S. Zagoruyko and N. Komodakis, "Paying more attention to attention: Improving the performance of convolutional neural networks via attention transfer," in *International Conference on Learning Representations (ICLR)*, 2017.

[24] W. Park, D. Kim, Y. Lu, and M. Cho, "Relational knowledge distillation," in *Proc. IEEE/CVF Conf. Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 3967–3976.

[25] Y. Tian, D. Krishnan, and P. Isola, "Contrastive representation distillation," in *International Conference on Learning Representations (ICLR)*, 2020.

[26] B. Heo, J. Kim, S. Yun, H. Park, N. Kwak, and J. Y. Choi, "A comprehensive overhaul of feature distillation," in *Proc. IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019, pp. 1921–1930.

[27] F. Tung and G. Mori, "Similarity-preserving knowledge distillation," in *Proc. IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019, pp. 1365–1374.

[28] X. Jiao, Y. Yin, L. Shang, X. Jiang, X. Chen, L. Li, F. Wang, and Q. Liu, "TinyBERT: Distilling BERT for natural language understanding," in *Findings of the Association for Computational Linguistics: EMNLP*, 2020, pp. 4163–4174.

[29] S. Sun, Y. Cheng, Z. Gan, and J. Liu, "Patient knowledge distillation for BERT model compression," in *Proc. Conference on Empirical Methods in Natural Language Processing (EMNLP-IJCNLP)*, 2019, pp. 4323–4332.

[30] M. Courbariaux, Y. Bengio, and J.-P. David, "BinaryConnect: Training deep neural networks with binary weights during propagations," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2015, pp. 3123–3131.

[31] M. Rastegari, V. Ordonez, J. Redmon, and A. Farhadi, "XNOR-Net: ImageNet classification using binary convolutional neural networks," in *Proc. European Conference on Computer Vision (ECCV)*, 2016, pp. 525–542.

[32] B. Jacob, S. Kligys, B. Chen, M. Zhu, M. Tang, A. Howard, H. Adam, and D. Kalenichenko, "Quantization and training of neural networks for efficient integer-arithmetic-only inference," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 2704–2713.

[33] S. Zhou, Y. Wu, Z. Ni, X. Zhou, H. Wen, and Y. Zou, "DoReFa-Net: Training low bitwidth convolutional neural networks with low bitwidth gradients," *arXiv preprint arXiv:1606.06160*, 2016.

[34] J. Choi, Z. Wang, S. Venkataramani, P. I.-J. Chuang, V. Srinivasan, and K. Gopalakrishnan, "PACT: Parameterized clipping activation for quantized neural networks," *arXiv preprint arXiv:1805.06085*, 2018.

[35] S. K. Esser, J. L. McKinstry, D. Bablani, R. Appuswamy, and D. S. Modha, "Learned step size quantization," in *International Conference on Learning Representations (ICLR)*, 2020.

[36] M. Nagel, R. A. Amjad, M. van Baalen, C. Louizos, and T. Blankevoort, "Up or down? Adaptive rounding for post-training quantization," in *Proc. International Conference on Machine Learning (ICML)*, 2020, pp. 7197–7206.

[37] E. Frantar, S. Ashkboos, T. Hoefler, and D. Alistarh, "GPTQ: Accurate post-training quantization for generative pre-trained transformers," in *International Conference on Learning Representations (ICLR)*, 2023.

[38] J. Lin, J. Tang, H. Tang, S. Yang, X. Dang, and S. Han, "AWQ: Activation-aware weight quantization for LLM compression and acceleration," in *Proc. Machine Learning and Systems (MLSys)*, 2024.

[39] T. Dettmers, M. Lewis, Y. Belkada, and L. Zettlemoyer, "LLM.int8(): 8-bit matrix multiplication for transformers at scale," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2022.

[40] K. Wang, Z. Liu, Y. Lin, J. Lin, and S. Han, "HAQ: Hardware-aware automated quantization with mixed precision," in *Proc. IEEE/CVF Conf. Computer Vision and Pattern Recognition (CVPR)*, 2019, pp. 8612–8620.

[41] Z. Dong, Z. Yao, A. Gholami, M. W. Mahoney, and K. Keutzer, "HAWQ: Hessian aware quantization of neural networks with mixed-precision," in *Proc. IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019, pp. 293–302.

[42] A. G. Howard, M. Zhu, B. Chen, D. Kalenichenko, W. Wang, T. Weyand, M. Andreetto, and H. Adam, "MobileNets: Efficient convolutional neural networks for mobile vision applications," *arXiv preprint arXiv:1704.04861*, 2017.

[43] M. Sandler, A. Howard, M. Zhu, A. Zhmoginov, and L.-C. Chen, "MobileNetV2: Inverted residuals and linear bottlenecks," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2018, pp. 4510–4520.

[44] M. Tan and Q. V. Le, "EfficientNet: Rethinking model scaling for convolutional neural networks," in *Proc. International Conference on Machine Learning (ICML)*, 2019, pp. 6105–6114.

[45] M. Jaderberg, K. Simonyan, A. Vedaldi, and A. Zisserman, "Synthetic data and artificial neural networks for natural scene text recognition," in *NeurIPS Deep Learning Workshop*, 2014.

[46] A. Gupta, A. Vedaldi, and A. Zisserman, "Synthetic data for text localisation in natural images," in *Proc. IEEE Conf. Computer Vision and Pattern Recognition (CVPR)*, 2016, pp. 2315–2324.

[47] A. Mishra, K. Alahari, and C. V. Jawahar, "Scene text recognition using higher order language priors," in *Proc. British Machine Vision Conference (BMVC)*, 2012.

[48] K. Wang, B. Babenko, and S. Belongie, "End-to-end scene text recognition," in *Proc. IEEE International Conference on Computer Vision (ICCV)*, 2011, pp. 1457–1464.

[49] D. Karatzas, F. Shafait, S. Uchida, M. Iwamura, L. G. i Bigorda, S. R. Mestre, J. Mas, D. F. Mota, J. A. Almazán, and L. P. de las Heras, "ICDAR 2013 robust reading competition," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2013, pp. 1484–1493.

[50] D. Karatzas, L. Gomez-Bigorda, A. Nicolaou, S. Ghosh, A. Bagdanov, M. Iwamura, J. Matas, L. Neumann, V. R. Chandrasekhar, S. Lu, F. Shafait, S. Uchida, and E. Valveny, "ICDAR 2015 competition on robust reading," in *Proc. International Conference on Document Analysis and Recognition (ICDAR)*, 2015, pp. 1156–1160.
