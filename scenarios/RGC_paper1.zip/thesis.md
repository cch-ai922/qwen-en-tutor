---
title: "Efficient Diffusion-Based Image Inpainting: Improving Reconstruction Fidelity and Sampling Speed"
author: "Master's Thesis"
date: "2026"
---

# Abstract

Image inpainting — the task of filling in missing or corrupted regions of an image with plausible, coherent content — has advanced rapidly with the rise of deep generative models. Among these, *diffusion-based* methods now produce reconstructions of remarkable visual fidelity and diversity, frequently surpassing earlier feed-forward generative-adversarial-network (GAN) approaches in perceptual quality. This quality, however, comes at a steep computational price: a diffusion model synthesizes an image through a long chain of iterative denoising steps, and dedicated inpainting samplers such as RePaint further multiply this cost by repeatedly *resampling* the same diffusion timesteps to harmonize generated content with the known surroundings. The result is an inference procedure that can be one to three orders of magnitude slower than a single feed-forward pass, which limits the practical deployment of otherwise excellent models.

This thesis studies how to retain the high reconstruction quality of diffusion-based inpainting while drastically reducing its inference cost. After surveying classical, GAN-based, and diffusion-based inpainting methods and formalizing the speed bottleneck, the thesis proposes an efficient inpainting model built on two complementary pillars. The first pillar concerns *reconstruction fidelity in a latent diffusion framework* and introduces two focused improvements: (A) a **mask-aware latent harmonization** scheme that blends the known-region latent and the model's prediction at every reverse step using a feathered soft mask, suppressing the seam artifacts that plague naïve latent inpainting; and (B) a **context-guided masked attention** mechanism that biases the denoiser's self-attention toward known-region tokens so that generated content is conditioned more strongly on visible context. The second pillar attacks the *speed* problem directly with two further improvements: (C) an **adaptive (decaying) resampling schedule** that concentrates expensive harmonization steps at high-noise timesteps, where they matter most, while economizing at low-noise timesteps; and (D) the integration of a **high-order probability-flow ODE solver** operating in the latent space, which reaches the same solution accuracy as first-order sampling in far fewer steps.

A complete system is constructed around these ideas and evaluated against representative prior methods (DeepFill v2, LaMa, MAT, RePaint, and a latent-diffusion inpainting baseline) on standard face and scene datasets. Under an illustrative experimental protocol, the proposed system matches or modestly improves the best reported Fréchet Inception Distance and perceptual-distance scores while reducing inference time by roughly twentyfold relative to RePaint and by about three-and-a-half-fold relative to a latent-diffusion inpainting baseline. Ablation studies isolate the contribution of each improvement and confirm that the quality gains come from the two fidelity components and the speed gains from the two acceleration components, with negligible quality loss. The thesis closes with a discussion of limitations and directions for future work.

# Chapter 1 Introduction and Analysis of Prior Work

## 1.1 Background and Motivation

Photographs are rarely perfect. Sensor dust, scratches on scanned prints, unwanted objects, text overlays, occluding obstacles, and compression artifacts all leave regions of an image that we would like to remove or repair. The computational task of replacing such regions with content that is visually plausible and consistent with the surrounding image is called **image inpainting** (also *image completion* or *hole filling*). The difficulty of the task is that the missing content is, by definition, unobserved: a good inpainting method must *infer* what could plausibly have been there from the visible context and from prior knowledge about natural images. When the missing region is small and lies within a smooth or repetitive texture, simple interpolation suffices. When the region is large, or overlaps semantically important structure such as a face, a building façade, or the horizon line of a landscape, the problem becomes a genuine act of generation: the method must hallucinate coherent new structure.

Over the past decade the field has moved through three broad families of methods. **Classical** methods propagate known pixels into the hole using partial differential equations or copy matching patches from elsewhere in the image. **Deep feed-forward** methods, predominantly built on convolutional encoders and generative adversarial training, learn to predict the missing content in a single forward pass and brought a large jump in semantic plausibility. Most recently, **diffusion-based** methods have set a new bar for perceptual quality and sample diversity by formulating inpainting as conditional sampling from a learned image distribution.

The diffusion family's quality, however, is bought with computation. A diffusion model generates an image by reversing a gradual noising process, and this reversal requires many sequential evaluations of a large neural network — often hundreds. Inpainting-specific samplers add a second multiplier on top of this: to make generated content blend seamlessly with the known surroundings, methods such as RePaint *resample*, repeatedly stepping backward and forward in diffusion time to give the model multiple opportunities to harmonize the two. The compound effect is an inference procedure that may require thousands of network evaluations and tens of seconds per image, against the few milliseconds of a feed-forward network. **This thesis is motivated by the gap between the excellent quality of diffusion-based inpainting and its impractical inference cost, and asks how the former can be preserved while the latter is reduced by an order of magnitude.**

## 1.2 Image Inpainting: Problem Definition

Let $x \in \mathbb{R}^{H \times W \times 3}$ denote a complete colour image and let $m \in \{0,1\}^{H \times W}$ denote a binary mask in which $m_{ij}=1$ marks a *known* (observed) pixel and $m_{ij}=0$ marks a *missing* pixel to be filled. The observed input is the element-wise (Hadamard) product $x \odot m$, in which the missing region carries no information. The goal of inpainting is to produce an estimate $\hat{x}$ that (i) agrees with the input on the known region, $\hat{x}\odot m = x \odot m$, and (ii) fills the unknown region $1-m$ with content that is both *realistic* (it looks like a natural image) and *coherent* (it is consistent with the visible context). Figure 1.1 illustrates the inputs and the desired output.

![The image-inpainting problem. Given an original image, a binary mask, and the masked input, the method must produce a completion that matches the known region and plausibly fills the hole.](figures/fig_1_2_problem.png){width=98%}

Because many different completions can be equally plausible, inpainting is fundamentally a *one-to-many* (ill-posed) problem. This has two consequences for how methods are designed and evaluated. First, a purely reconstructive loss that compares $\hat{x}$ to a single ground truth $x$ pixel by pixel tends to encourage blurry, averaged predictions, since the average of several plausible completions is itself not sharp. Generative formulations instead try to model the *distribution* of plausible completions. Second, evaluation must measure perceptual realism and distributional match, not just pixel error; the community therefore relies on metrics such as the Fréchet Inception Distance (FID) [38] and the Learned Perceptual Image Patch Similarity (LPIPS) [39] alongside classical fidelity measures such as the peak signal-to-noise ratio (PSNR) and the structural similarity index (SSIM) [40]. These metrics are revisited in Chapter 3.

## 1.3 A Survey of Image Inpainting Methods

Image inpainting methods fall into three broad families that emerged roughly in sequence: classical and exemplar-based methods, feed-forward methods based on generative adversarial networks (GANs), and the more recent diffusion-based methods. Figure 1.1 organizes these families and the representative methods discussed below; the survey then treats each family in turn, paying particular attention to the diffusion family on which this thesis builds.

![A taxonomy of image inpainting methods, organized into classical/exemplar-based, GAN-based feed-forward, and diffusion-based families, with representative methods in each.](figures/fig_1_1_taxonomy.png){width=95%}

### 1.3.1 Classical and exemplar-based methods

The earliest computational inpainting methods drew on the physical metaphor of diffusing (i.e., spreading) information from the boundary of a hole inward. Partial-differential-equation formulations propagate isophote (equal-intensity) lines into the missing region so that edges continue smoothly. These methods are effective for thin scratches and small holes but blur across large gaps because they carry no notion of texture or semantics. *Exemplar-based* and patch-synthesis methods address texture by copying the best-matching patches from elsewhere in the same image into the hole, greedily or by global optimization. They reproduce repetitive textures convincingly but cannot invent structure that does not already appear in the image — they will not, for instance, reconstruct a missing eye on a face if no comparable eye patch is available. The classical family thus established the problem and useful priors (smoothness, self-similarity) but was fundamentally limited by its lack of learned semantic knowledge. Because the present work does not build directly on any single classical method, the corresponding reference slots are intentionally left unassigned in the reference list.

### 1.3.2 Deep feed-forward and GAN-based methods

The decisive shift came with learning-based methods that train a neural network on large image collections so that it acquires a semantic prior over natural images. Context Encoders [30] were among the first to cast inpainting as learning to predict missing content from a surrounding context using an encoder–decoder network trained with a combination of reconstruction loss and an adversarial loss drawn from generative adversarial networks (GANs) [32]. The adversarial term, in which a discriminator learns to distinguish real from completed images while the generator learns to fool it, proved essential for producing sharp rather than blurry output. Subsequent work improved global and local consistency by using two discriminators operating at different scales [31], and improved handling of irregular (free-form) holes.

Two architectural ideas were especially influential. **Partial convolutions** [28] re-weight convolutions so that they depend only on valid (known) pixels and progressively "shrink" the hole layer by layer, avoiding the artifacts caused by feeding zeros into ordinary convolutions. **Gated convolutions** [27], used in the DeepFill v2 system, generalize this idea by *learning* a soft gating of features at every spatial location, which lets the network decide for itself how much to trust each region; combined with a contextual-attention module that borrows distant features [26], this produced strong free-form inpainting. Other designs guided completion with explicit intermediate structure, such as EdgeConnect [29], which first predicts the edges of the missing region and then fills colour conditioned on them. A further leap in robustness to large masks came from **LaMa** [25], which replaces ordinary convolutions with *fast Fourier convolutions* whose receptive field spans the entire image even in early layers; this global receptive field lets a single feed-forward pass complete very large holes with repetitive structure remarkably well, while remaining extremely fast. More recently, transformer-based designs such as the **mask-aware transformer (MAT)** [49] and large co-modulated GANs [48] — which borrow the modulation idea from high-fidelity generators such as StyleGAN [47] — further improved the completion of large holes by modelling long-range dependencies among tokens.

The defining virtue of this family is *speed*: inference is a single forward pass, taking milliseconds. Its limitations are *diversity* and, for very large or semantically demanding holes, *fidelity*. A deterministic feed-forward network produces one completion; adversarial training is prone to mode collapse and to characteristic texture artifacts; and pushing quality higher typically requires careful, fragile loss balancing. These limitations set the stage for the diffusion family.

### 1.3.3 Diffusion probabilistic models

Denoising diffusion probabilistic models (DDPMs) [10], building on earlier non-equilibrium thermodynamics formulations [37] and score-based generative models [12,13], generate images by learning to reverse a gradual noising process. In the **forward process**, Gaussian noise is added to a clean image $x_0$ over $T$ timesteps according to a fixed variance schedule $\{\beta_t\}_{t=1}^{T}$, producing progressively noisier latents $x_1,\dots,x_T$ until $x_T$ is essentially pure noise:

$$ q(x_t \mid x_{t-1}) = \mathcal{N}\!\left(x_t;\ \sqrt{1-\beta_t}\,x_{t-1},\ \beta_t \mathbf{I}\right). $$

A convenient property is that the forward process has a closed form that lets us jump directly to any timestep. Writing $\alpha_t = 1-\beta_t$ and $\bar{\alpha}_t = \prod_{s=1}^{t}\alpha_s$,

$$ q(x_t \mid x_0) = \mathcal{N}\!\left(x_t;\ \sqrt{\bar{\alpha}_t}\,x_0,\ (1-\bar{\alpha}_t)\mathbf{I}\right), \qquad x_t = \sqrt{\bar{\alpha}_t}\,x_0 + \sqrt{1-\bar{\alpha}_t}\,\epsilon,\ \ \epsilon \sim \mathcal{N}(0,\mathbf{I}). $$

The **reverse process** is what the model learns. A neural network $\epsilon_\theta(x_t,t)$ is trained to predict the noise that was added, and the model then denoises step by step:

$$ p_\theta(x_{t-1}\mid x_t) = \mathcal{N}\!\left(x_{t-1};\ \mu_\theta(x_t,t),\ \Sigma_\theta(x_t,t)\right). $$

Ho et al. [10] showed that training reduces to a simple, stable denoising objective,

$$ \mathcal{L}_{\mathrm{simple}}(\theta) = \mathbb{E}_{x_0,\ \epsilon,\ t}\left[\big\lVert \epsilon - \epsilon_\theta\!\big(\sqrt{\bar{\alpha}_t}\,x_0 + \sqrt{1-\bar{\alpha}_t}\,\epsilon,\ t\big)\big\rVert_2^2\right], $$

and that the reverse mean can be written in closed form from the predicted noise. Figure 1.2 depicts the forward and reverse chains. Improved variants refined the variance schedule and learned the reverse variances to raise log-likelihood and sample quality [21,46], and a continuous-time view via stochastic differential equations unified diffusion with score matching [13]. A key empirical milestone was the demonstration that diffusion models, with classifier and later classifier-free guidance [14,20], surpass GANs on unconditional and conditional image synthesis [14], and the careful design-space study of Karras et al. [41] consolidated many of these choices.

![The diffusion framework. The forward process gradually adds Gaussian noise to a clean image; the learned reverse process removes it step by step.](figures/fig_1_3_ddpm_chain.png){width=96%}

### 1.3.4 Accelerated sampling of diffusion models

The principal weakness of DDPMs is sampling speed. Because the reverse process is a long Markov chain, drawing one sample requires evaluating the network once per timestep, typically for $T=1000$ steps. Two complementary lines of work reduce this cost. The first reformulates sampling so that fewer steps are needed. **Denoising diffusion implicit models (DDIM)** [11] construct a non-Markovian process with the same training objective whose reverse process is *deterministic*, allowing one to skip timesteps and sample in, say, 50 rather than 1000 steps with modest quality loss. Viewing the deterministic reverse process as an ordinary differential equation (ODE) — the *probability-flow ODE* — opens the door to high-order numerical solvers: **DPM-Solver** [22] and its guided-sampling extension DPM-Solver++ [50] achieve high-quality samples in roughly 10–20 steps by exploiting the semi-linear structure of the diffusion ODE. The second line of work *distills* a many-step model into a few-step one: progressive distillation [23] repeatedly halves the number of required steps, and consistency models [24] learn a direct mapping from any noise level to the clean image, enabling one- or few-step generation. The acceleration ideas most relevant to this thesis are the deterministic ODE view and high-order solvers, because they accelerate sampling *without* retraining or distillation and therefore compose cleanly with an inpainting procedure.

### 1.3.5 Latent diffusion

A second, orthogonal source of acceleration is to run the diffusion process in a compressed *latent* space rather than in pixel space. **Latent diffusion models (LDMs)** [15] first train an autoencoder — an encoder $\mathcal{E}$ and decoder $\mathcal{D}$, building on perceptual and adversarial autoencoder ideas such as VQGAN [36] — that maps an image to a spatially smaller latent $z = \mathcal{E}(x)$ (typically downsampled by a factor of eight per side) and back, $\hat{x} = \mathcal{D}(z)$, in the tradition of variational autoencoders [33]. The diffusion model is then trained entirely in this latent space, with the training objective

$$ \mathcal{L}_{\mathrm{LDM}}(\theta) = \mathbb{E}_{\,\mathcal{E}(x),\ \epsilon,\ t}\left[\big\lVert \epsilon - \epsilon_\theta(z_t, t)\big\rVert_2^2\right]. $$

Because each spatial dimension is reduced by roughly eight, the cost of every denoising step falls by up to two orders of magnitude, while the autoencoder preserves perceptually important detail. Figure 1.3 contrasts pixel-space and latent-space diffusion. The same backbone underpins large text-to-image systems [44,45] and the widely used U-Net denoiser architecture [34] augmented with self- and cross-attention [35]. **Latent diffusion is the foundation on which the proposed system is built**, because it provides a large, "free" speed-up before any inpainting-specific or solver-specific acceleration is applied.

![Latent diffusion. An autoencoder maps the image to a much smaller latent space in which the diffusion process is run, then decodes the result. Each denoising step is therefore far cheaper than in pixel space.](figures/fig_1_5_ldm.png){width=95%}

### 1.3.6 Diffusion-based inpainting

There are two broad ways to turn a diffusion model into an inpainting method. The first **trains a conditional model** whose input is the masked image and mask, so that the network learns to denoise *given* the visible context. Palette [17] treats inpainting as one instance of image-to-image translation with a conditional diffusion model; GLIDE [18] and Blended Diffusion [19] add text conditioning and blend the diffused known region with the generated content at each step in pixel space; and the LDM work [15] trains a latent-space conditional inpainting model by concatenating the encoded masked image and the downsampled mask to the noisy latent. The second way **reuses an unconditional model** and enforces the known region only at sampling time. RePaint [16] is the canonical example: at every reverse step it replaces the known region of the current latent with a correctly-noised version of the ground-truth known pixels, $x_{t-1}^{\text{known}} \sim q(x_{t-1}\mid x_0\odot m)$, and keeps the model's prediction only in the hole. Because a single such replacement leaves a visible seam — the generated content has not "seen" the freshly injected known pixels — RePaint introduces **resampling**: it diffuses the harmonized result one step forward again and re-runs the reverse step, repeating this jump $r$ times per timestep so the two regions can mutually adjust. SDEdit [42] and ControlNet-style conditioning [43] are related editing techniques. The present work draws the *known-region injection and harmonization* idea from RePaint but moves it into latent space and makes its schedule adaptive, and draws the *conditional latent inpainting* setup from LDM.

## 1.4 Comparison of Method Families

Table 1.1 summarizes the trade-offs across the three families along the axes that matter for this thesis: reconstruction quality, sample diversity, robustness to large holes, and inference speed. The pattern is consistent: feed-forward methods are fast but limited in diversity and large-hole fidelity, whereas diffusion methods excel in quality and diversity but are slow, with sampler-based inpainting (RePaint) being the slowest of all.

Table: Qualitative comparison of inpainting method families. More plus signs indicate a more favourable rating on that axis.

| Family / representative | Quality | Diversity | Large holes | Inference speed |
|---|:--:|:--:|:--:|:--:|
| Classical / exemplar | + | + | + | +++ |
| GAN feed-forward (DeepFill v2 [27]) | ++ | + | ++ | +++++ |
| GAN feed-forward (LaMa [25], MAT [49]) | +++ | + | ++++ | +++++ |
| Conditional diffusion (Palette [17], LDM [15]) | ++++ | ++++ | ++++ | ++ |
| Sampler-based diffusion (RePaint [16]) | +++++ | ++++ | ++++ | + |
| **This work (efficient latent diffusion)** | **+++++** | **++++** | **++++** | **++++** |

## 1.5 Problem Formulation: The Speed Bottleneck

We now make the speed problem precise so that the improvements in Chapter 2 can be motivated quantitatively. The dominant cost of diffusion-based inpainting is the number of times the denoising network is evaluated, the **number of function evaluations (NFE)**, because each evaluation is a full forward pass through a large U-Net and these passes are sequential and cannot be trivially parallelized across timesteps. For a plain diffusion model sampled with $N$ steps, $\text{NFE}=N$. For pixel-space sampling $N$ is large (e.g. 250–1000). Latent diffusion does not change $N$ but makes each evaluation cheaper because the spatial resolution is smaller. A sampler such as RePaint multiplies $N$ by the resampling factor: with $r$ resampling repetitions per timestep,

$$ \text{NFE}_{\text{RePaint}} \approx N \cdot r, $$

so the recommended setting of $N=250$ and $r=10$ gives an NFE on the order of $2.5\times 10^3$. The end-to-end wall-clock time is approximately

$$ \text{time} \approx \text{NFE}\times c_{\text{eval}}(\text{resolution}) + c_{\text{enc}} + c_{\text{dec}}, $$

where $c_{\text{eval}}$ is the per-evaluation cost (a strong function of spatial resolution) and $c_{\text{enc}},c_{\text{dec}}$ are the one-off encoder/decoder costs in a latent model. Figure 1.4 illustrates the resampling trajectory that inflates the NFE, and Table 1.1's "speed" column reflects the consequence. This decomposition tells us there are exactly three levers available to reduce time without sacrificing quality:

1. **Reduce $c_{\text{eval}}$** by working at lower spatial resolution — i.e. operate in *latent* space (Section 1.3.5). This is the foundation we adopt.
2. **Reduce $N$** by using a more accurate sampler that needs fewer steps for the same solution accuracy — i.e. a high-order *probability-flow ODE solver* (Section 1.3.4). This motivates Improvement D in Chapter 2.
3. **Reduce the $r$ multiplier** without losing the harmonization quality it buys — i.e. an *adaptive* resampling schedule that spends repetitions only where they help. This motivates Improvement C in Chapter 2.

![Why sampler-based inpainting is slow. RePaint repeatedly jumps backward in diffusion time (red segments) and re-denoises so the generated and known regions can harmonize; each jump adds network evaluations, multiplying the NFE.](figures/fig_1_6_repaint.png){width=88%}

Crucially, the first two levers alone improve speed but can *hurt* inpainting quality if applied naïvely: latent-space known-region injection produces seams at the latent level that the decoder turns into visible boundary artifacts, and aggressive step reduction gives the generated and known regions fewer opportunities to harmonize. Therefore speed improvements must be paired with *fidelity* improvements that keep the known and unknown regions coherent under fewer, cheaper steps. This pairing is the organizing principle of Chapter 2: two improvements that protect fidelity (Section 2.1) and two that buy speed (Section 2.2).

## 1.6 Research Objectives and Contributions

The objective of this thesis is to design, implement, and evaluate a diffusion-based image-inpainting system that attains the perceptual quality of state-of-the-art sampler-based diffusion inpainting at a fraction of its inference cost. Concretely, the thesis makes the following contributions, deliberately limited to two focused improvements per section so that each can be motivated, described, and validated in depth rather than asserted in passing:

- **A mask-aware latent harmonization scheme (Improvement A).** The known-region injection of RePaint is reformulated in latent space with a *feathered* (soft) mask, so that the known and generated latents are blended smoothly rather than hard-switched, eliminating the seam artifacts that naïve latent injection introduces.
- **A context-guided masked attention mechanism (Improvement B).** The denoiser's self-attention is biased to attend more strongly to known-region tokens, strengthening the conditioning of generated content on visible context without changing the network's parameter count.
- **An adaptive (decaying) resampling schedule (Improvement C).** Resampling repetitions are allocated according to a decaying schedule that concentrates harmonization at high-noise timesteps, reducing the average resampling factor by roughly threefold at equal quality.
- **A high-order latent ODE solver for inpainting (Improvement D).** A second-order probability-flow ODE solver is integrated into the inpainting loop, reaching the accuracy of first-order sampling in far fewer steps and composing cleanly with Improvements A and C.

Together these reduce inference time by roughly twentyfold against RePaint and about three-and-a-half-fold against a latent-diffusion inpainting baseline, while matching or slightly improving FID and LPIPS, as quantified in Chapter 3.

## 1.7 Thesis Organization

The remainder of the thesis is organized as follows. **Chapter 2** describes the proposed efficient inpainting model in two sections: Section 2.1 presents the high-fidelity latent inpainting model with Improvements A and B and explains why each is expected to help; Section 2.2 presents the acceleration of sampling with Improvements C and D and analyses their effect on the NFE. **Chapter 3** details the construction and implementation of the complete system, the datasets and evaluation protocol, and the experiments — including a quantitative comparison against prior methods, an efficiency comparison, ablation studies isolating each improvement, qualitative results, and a discussion of limitations — before concluding. The reference list at the end provides entries 10 through 50; entries 1 through 9 are intentionally left blank and reserved.

# Chapter 2 An Efficient Diffusion-Based Inpainting Model

This chapter describes the proposed model. It is organized around the two-pillar principle established in Section 1.5: Section 2.1 concerns *reconstruction fidelity* and contributes two improvements that keep the generated and known regions coherent; Section 2.2 concerns *sampling speed* and contributes two improvements that reduce the number and cost of denoising evaluations. Throughout, the emphasis is on explaining clearly *why* each improvement is expected to help and *why* it is valid, rather than on heavy mathematical machinery. Table 2.1 fixes the notation used in this chapter, and Figure 2.1 shows how the components fit together into one model.

Table: Notation used throughout Chapter 2.

| Symbol | Meaning |
|---|---|
| $x,\ \hat{x}$ | clean image and its inpainted estimate, in pixel space $\mathbb{R}^{H\times W\times 3}$ |
| $m$ | binary mask in pixel space; $m=1$ known, $m=0$ hole |
| $\mathcal{E},\ \mathcal{D}$ | pretrained latent autoencoder encoder and decoder |
| $z_0=\mathcal{E}(x)$ | clean latent, of spatial size $h\times w$ with $c$ channels |
| $z_t$ | noisy latent at diffusion timestep $t$ |
| $z^{ctx}=\mathcal{E}(x\odot m)$ | encoded masked (context) image |
| $m_z$ | mask resampled to latent resolution, optionally soft (feathered) |
| $\epsilon_\theta$ | conditional U-Net denoiser predicting the added noise |
| $N$ | number of sampler steps; $r(t)$ resampling repetitions at step $t$ |

![Overall architecture of the proposed model. The encoder maps the masked image to a latent that is concatenated with the noisy latent and the latent mask and fed to a conditional U-Net denoiser equipped with context-guided masked attention (Section 2.1). At each reverse step the prediction is harmonized with the known latent (Section 2.1) and advanced by an accelerated sampler that combines a high-order ODE solver with an adaptive resampling schedule (Section 2.2). The decoder produces the final image.](figures/fig_2_1_architecture.png){width=100%}

## 2.1 High-Fidelity Latent Inpainting

### 2.1.1 Base model

The base of the proposed system is a conditional latent diffusion inpainting model in the style of [15]. A pretrained autoencoder $(\mathcal{E},\mathcal{D})$ — trained once on a large image corpus and then frozen — provides a latent space that is downsampled by a factor of eight per spatial dimension, so that a $256\times256\times3$ image becomes a $32\times32\times4$ latent. All diffusion happens in this latent space, which is the foundational speed lever identified in Section 1.5. The denoiser $\epsilon_\theta$ is a U-Net [34] with residual blocks and self-attention at the coarser resolutions [35]. To condition it on the inpainting task, the noisy latent $z_t$ is concatenated channel-wise with the encoded context $z^{ctx}=\mathcal{E}(x\odot m)$ and the latent-resolution mask $m_z$:

$$ \text{input to } \epsilon_\theta \;=\; \big[\,z_t \,\Vert\, z^{ctx} \,\Vert\, m_z\,\big], \qquad \epsilon_\theta\big([\,z_t \Vert z^{ctx} \Vert m_z\,],\ t\big)\ \approx\ \epsilon. $$

The model is trained with the standard denoising objective restricted to predicting the noise on the full latent,

$$ \mathcal{L}(\theta) = \mathbb{E}_{\,z_0,\ m,\ \epsilon,\ t}\left[\big\lVert \epsilon - \epsilon_\theta\big([\,z_t \Vert z^{ctx} \Vert m_z\,],\ t\big)\big\rVert_2^2\right],\qquad z_t = \sqrt{\bar\alpha_t}\,z_0 + \sqrt{1-\bar\alpha_t}\,\epsilon, $$

with masks $m$ sampled randomly during training to cover the variety of hole shapes the model must handle at test time (Section 3.2). This base model is already fast relative to pixel-space diffusion, but two fidelity problems remain, which Improvements A and B address.

### 2.1.2 Improvement A — Mask-aware latent harmonization

**The problem.** The cleanest way to *guarantee* that the output matches the known region is to inject the known content during sampling, exactly as RePaint [16] does in pixel space: at each reverse step, overwrite the known region of the current state with a correctly-noised copy of the ground-truth known pixels, and keep the model's prediction only inside the hole. Transplanting this idea naïvely into latent space, however, fails. The latent representation is *spatially entangled*: because the encoder $\mathcal{E}$ has a receptive field, a single latent cell summarizes an $8\times8$ pixel neighbourhood, and a hard binary switch at the latent grid does not correspond to a hard switch at the pixel boundary. Worse, a hard replacement creates a discontinuity in the latent that the decoder $\mathcal{D}$ amplifies into a visible halo or colour seam around the hole. In short, *hard known-region injection in latent space produces boundary artifacts.*

**The improvement.** We replace the hard binary switch with a **feathered (soft) blend in latent space**. Let $z^{known}_{t-1}\sim q(z_{t-1}\mid z^{ctx})$ be a correctly-noised version of the known-region latent at timestep $t-1$, and let $z^{pred}_{t-1}$ be the denoiser's prediction for the same timestep. We form the next state as a convex combination governed by a *soft* latent mask $m_z\in[0,1]^{h\times w}$ whose values transition smoothly from $1$ (fully known) to $0$ (fully generated) across a narrow band around the hole boundary:

$$ z_{t-1} \;=\; m_z \odot z^{known}_{t-1} \;+\; (1-m_z)\odot z^{pred}_{t-1}. $$

The soft mask is obtained by downsampling the pixel mask to latent resolution and convolving it with a small Gaussian kernel, so that within a one-to-two-cell band the blend interpolates between the two sources rather than switching abruptly. Figure 2.2 illustrates the operation.

![Improvement A: mask-aware latent harmonization. At each reverse step the correctly-noised known latent and the denoiser's prediction are blended with a feathered soft mask, so the boundary transitions smoothly instead of switching abruptly.](figures/fig_2_2_harmonization.png){width=92%}

**Why it is valid and why it helps.** Three arguments support this design. First, *consistency is preserved*: away from the boundary band, $m_z$ is exactly $1$ in the known region and exactly $0$ in the hole, so the known content is still injected and the output still matches the input there — the soft band only affects a thin transition region whose width is comparable to the encoder's effective boundary uncertainty, which is precisely where a hard switch was ill-defined to begin with. Second, *the blend is the natural latent analogue of alpha compositing*, a standard and well-understood image-blending operation; performing it on the noised latents (rather than on clean images) keeps both operands at the same noise level, so the combination is itself a valid sample of the forward process up to the boundary band and does not push the state off the data manifold. Third, *it directly removes the cause of the artifact*: by eliminating the latent discontinuity, it removes the input that the decoder would otherwise amplify into a seam. Empirically (Chapter 3, Table 3.7), enabling Improvement A lowers FID and, more tellingly, sharply reduces a boundary-gradient artifact measure, while leaving the interior of the hole unchanged. The improvement adds essentially no computation: it is one extra element-wise blend per step.

### 2.1.3 Improvement B — Context-guided masked attention

**The problem.** Inside the hole the model must invent content, but that content should be *driven by the visible context*: a reconstructed eye should match the other eye, a continued brick wall should match the existing courses. The base U-Net already attends globally through its self-attention layers, but self-attention is *symmetric and content-agnostic with respect to the mask* — it does not know which tokens are reliable observations and which are still being hallucinated. Early in sampling, when the hole tokens are mostly noise, allowing hole tokens to attend to one another as strongly as to known tokens lets the model "echo" its own noise and drift away from the context, producing content that is locally plausible but globally inconsistent with the surroundings.

**The improvement.** We add a **context bias** to the attention logits that up-weights attention from any query toward *known* keys. For a query token $i$ and key token $j$ with the usual scaled dot-product attention, the attention weight becomes

$$ A_{ij} \;=\; \mathrm{softmax}_j\!\left(\frac{q_i k_j^{\top}}{\sqrt{d}} \;+\; \lambda_t\, b_{ij}\right), \qquad b_{ij} \;=\; \begin{cases} 1, & \text{if key } j \text{ lies in the known region},\\[2pt] 0, & \text{otherwise,} \end{cases} $$

where $d$ is the per-head dimension, $b_{ij}$ is a known-region indicator computed from $m_z$ at the attention map's resolution, and $\lambda_t\ge 0$ is a strength that *decays with the noise level*: it is largest at high-noise timesteps (early in sampling), where the hole tokens are least reliable and the context should dominate, and decays toward zero at low-noise timesteps, where the hole content is well-formed and should be refined on its own terms. A simple linear-in-$\bar\alpha_t$ schedule, $\lambda_t = \lambda_0\,(1-\bar\alpha_t)$, works well. Figure 2.3 illustrates the mechanism.

![Improvement B: context-guided masked attention. A learned bias added to the attention logits increases the weight a query places on known-region keys, more strongly at high noise levels, so generated content is conditioned on visible context.](figures/fig_2_3_attention.png){width=88%}

**Why it is valid and why it helps.** The bias is added *inside the softmax*, so the attention weights remain a valid probability distribution over keys and the operation is still differentiable and trainable end-to-end; nothing about the network's stability or its parameter count changes (the only new quantity, $\lambda_0$, is a single scalar, optionally made a small learned per-layer parameter). Conceptually, the bias encodes a prior we know to be true for inpainting — *observed context is more trustworthy than hallucinated content* — and it injects this prior precisely when it is most useful, namely at high noise. Because the bias is additive in logit space, it gently re-weights rather than hard-masking attention, so the model can still attend to other hole tokens when that genuinely helps (for example, to continue a texture across the hole). This is the key difference from simply forbidding hole-to-hole attention, which would be too rigid. Ablations (Table 3.7) show that Improvement B reduces LPIPS and visibly improves the *semantic* coherence of completions on structured content such as faces, with the largest gains on large holes where context guidance matters most. Like Improvement A, it adds negligible cost — one addition and an indicator lookup per attention entry.

### 2.1.4 Summary of Section 2.1

Section 2.1 contributes two fidelity improvements that are deliberately simple, cheap, and well-motivated. Improvement A makes known-region injection safe in latent space by feathering the blend, removing boundary seams. Improvement B makes generation context-aware by biasing attention toward known tokens with a noise-dependent strength, improving semantic coherence. Neither adds meaningful computation, which matters because Section 2.2 will reduce the number of steps over which any per-step cost is incurred; cheap fidelity improvements therefore remain cheap in the accelerated regime.

## 2.2 Accelerated Sampling for Inpainting

Section 2.1 produced a high-fidelity model but did not change the *number* of denoising steps. This section reduces that number and the resampling multiplier, attacking the two cost levers ($N$ and $r$) identified in Section 1.5. The two improvements are designed to *compose* with each other and with Improvements A and B.

### 2.2.1 Improvement C — Adaptive (decaying) resampling schedule

**The problem.** Harmonization through resampling (Section 1.3.6) is what makes sampler-based inpainting look seamless, but it is also the dominant cost: a uniform schedule that resamples $r$ times at *every* timestep multiplies the NFE by $r$ (Equation in Section 1.5). Yet resampling is not equally useful at every timestep. At high noise levels the overall layout and low-frequency structure of the completion are being decided, and giving the known and generated regions several opportunities to agree on this structure pays off handsomely. At low noise levels only fine, local detail remains, the two regions are already globally consistent, and additional resampling yields rapidly diminishing returns — it mostly re-polishes detail that is already in agreement. Spending the same $r$ everywhere therefore wastes most of the budget at the low-noise end.

**The improvement.** We make the number of resampling repetitions a **decaying function of the noise level** rather than a constant. Concretely we set

$$ r(t) \;=\; 1 + \big\lfloor (r_{\max}-1)\,\rho(t) \big\rceil, \qquad \rho(t) \;=\; \left(\tfrac{t}{T}\right)^{\gamma}, $$

so that $r(t)$ is largest (up to $r_{\max}$) at the high-noise start ($t\!\approx\!T$) and falls to a single pass ($r=1$) as $t\to 0$; the exponent $\gamma>0$ controls how quickly it decays, and $\lfloor\cdot\rceil$ denotes rounding. The *effective* (average) resampling factor is then $\bar r = \frac{1}{N}\sum_t r(t)$, which for the schedule above is well below $r_{\max}$. Figure 2.4 contrasts the uniform and adaptive schedules; Figure 2.6 shows where the step sits in the overall loop.

![Improvement C: adaptive resampling. Instead of a constant number of resampling repetitions at every timestep (grey), the proposed schedule concentrates repetitions at high-noise timesteps and tapers to a single pass at low noise (red), lowering the average resampling factor at equal quality.](figures/fig_2_4_resample_schedule.png){width=85%}

**Why it is valid and why it helps.** The schedule does not change *what* resampling does at any individual timestep — each repetition is the same correct diffuse-forward / denoise-backward operation as before — it only changes *how many* repetitions are spent where, so correctness is unaffected and only the compute allocation changes. The allocation it chooses follows directly from the coarse-to-fine nature of diffusion sampling, which is well established: diffusion models commit to global structure at high noise and to detail at low noise [10,41]. Allocating harmonization budget in proportion to where structural agreement is being decided is therefore principled rather than ad hoc. The experiments in Chapter 3 (Table 3.8, Figure 3.10) show that a uniform schedule's quality saturates around $r\approx 4$–$6$ while its cost keeps rising linearly, and that the adaptive schedule reaches the same FID as a uniform $r\approx 5$ schedule at an effective $\bar r\approx 3$, i.e. a roughly $1.7\times$ reduction in the resampling multiplier alone, with no measurable quality loss.

### 2.2.2 Improvement D — High-order latent ODE solver

**The problem.** Even with cheaper per-step cost (latent space) and a smaller resampling multiplier (Improvement C), the base step count $N$ remains large if we sample with the first-order DDIM update [11], because a first-order method must take many small steps to follow the curved reverse trajectory accurately. Taking *fewer, larger* first-order steps introduces discretization error that, in the inpainting setting, shows up as residual incoherence between the hole and its surroundings. We want a way to take large steps *without* the accompanying error.

**The improvement.** We sample with a **second-order probability-flow ODE solver** in latent space, in the spirit of DPM-Solver [22,50]. The deterministic reverse process of a diffusion model can be written as an ODE in a transformed time variable; its key structural property is that it is *semi-linear*, i.e. it has a part that can be integrated exactly and a remaining nonlinear part involving the network $\epsilon_\theta$. A first-order solver approximates the nonlinear part by a constant over each step; a second-order solver approximates it by a line, using one extra evaluation (or a stored previous evaluation) to estimate the slope. Schematically, where a first-order update for moving from noise level $\sigma_t$ to $\sigma_{t-1}$ has the form

$$ z_{t-1} \;=\; a_t\, z_t \;+\; b_t\, \epsilon_\theta(z_t,t), $$

the second-order update adds a correction built from the change in the network output between consecutive steps,

$$ z_{t-1} \;=\; a_t\, z_t \;+\; b_t\, \epsilon_\theta(z_t,t) \;+\; c_t\,\big[\epsilon_\theta(z_t,t) - \epsilon_\theta(z_{t+1},t{+}1)\big], $$

where $a_t,b_t,c_t$ are coefficients determined analytically by the noise schedule and the chosen step sizes. The bracketed term is a finite-difference estimate of how fast the denoiser's prediction is changing, i.e. the local curvature of the trajectory; using it lets each step follow the true curve much more closely. Figure 2.5 shows, schematically, how a second-order solver stays near the true trajectory in a handful of steps where a first-order solver of the same step count drifts.

![Improvement D: a second-order probability-flow ODE solver follows the curved reverse trajectory (green) closely in only a few steps, whereas a first-order solver (DDIM) of the same step count accumulates discretization error.](figures/fig_2_5_solver.png){width=82%}

**Why it is valid and why it helps.** The solver is a standard numerical-integration result applied to the *same* ODE that DDIM already integrates; it does not require retraining and is mathematically guaranteed to have a higher order of accuracy, so for a target solution error it needs asymptotically fewer steps. In practice this means roughly $N\approx 20$ steps reach the quality that a first-order sampler needs $\sim$200 steps to reach — about a tenfold reduction in $N$. Two design points make the solver work *inside* the inpainting loop. First, the harmonization blend (Improvement A) is applied *after* each solver step, so the solver always integrates the true reverse dynamics and the known-region constraint is re-imposed on the result, keeping the two operations cleanly separated. Second, the stored previous evaluation $\epsilon_\theta(z_{t+1},t{+}1)$ that the second-order term needs is exactly the one already computed at the previous step, so the higher order comes essentially for free — no extra network evaluations beyond the occasional restart after a resampling jump. The end-to-end effect, quantified in Chapter 3, is the bulk of the speed-up.

### 2.2.3 The combined sampling algorithm

The two acceleration improvements and the two fidelity improvements combine into a single inpainting loop, shown in Figure 2.6. Starting from a noised initial latent that already contains the known content, each iteration (i) takes one second-order solver step (Improvement D) using the context-guided denoiser (Improvement B), (ii) performs $r(t)$ adaptive resampling repetitions (Improvement C), and (iii) re-imposes the known region by the feathered latent blend (Improvement A); after $N$ iterations the clean latent is decoded to the output image.

![The combined sampling pipeline. At each reverse step the solver predicts the next latent, the adaptive schedule decides how many harmonizing resampling repetitions to apply, and the context bias steers attention toward known content; the final latent is decoded once to pixels.](figures/fig_2_6_pipeline.png){width=98%}

The pseudocode below makes the composition explicit.

```
Input: masked image x⊙m, mask m, pretrained (E, D, ε_θ),
       steps N, max resampling r_max, decay γ
z_ctx ← E(x⊙m);  m_z ← feather(downsample(m))         # context + soft latent mask
z ← sqrt(ᾱ_T)·z_ctx + sqrt(1−ᾱ_T)·noise               # init with known content
prev_eps ← None
for t = t_N, …, t_1 (decreasing):                      # N solver steps  (Improvement D)
    r ← 1 + round((r_max−1)·(t/T)^γ)                   # adaptive count  (Improvement C)
    for k = 1 … r:                                     # resampling repetitions
        eps ← ε_θ([z ‖ z_ctx ‖ m_z], t)                # context-guided attention (Improvement B)
        z_pred ← solver_step(z, eps, prev_eps, t)      # 2nd-order update (Improvement D)
        z_known ← q_sample(z_ctx, t−1)                 # correctly-noised known latent
        z ← m_z·z_known + (1−m_z)·z_pred               # feathered blend (Improvement A)
        if k < r:  z ← q_forward(z, t−1 → t)           # jump back for next repetition
        prev_eps ← eps
return D(z)                                             # decode to image
```

### 2.2.4 Complexity and NFE analysis

We can now total the cost. The proposed sampler uses $N$ solver steps and, within them, an adaptive number of resampling repetitions, giving

$$ \text{NFE}_{\text{ours}} \;=\; \sum_{t} r(t) \;=\; N\,\bar r, \qquad \bar r = \frac{1}{N}\sum_t r(t). $$

With the illustrative settings $N=20$, $r_{\max}=8$, and $\gamma=1.5$, the effective factor is $\bar r\approx 2$, giving an NFE on the order of $40$. By contrast, RePaint with $N=250$ and $r=10$ has an NFE on the order of $2.5\times10^3$, and a latent-diffusion inpainting baseline with $N=250$ and no resampling has an NFE of $250$. The proposed method's NFE is therefore about $60\times$ smaller than RePaint's and about $6\times$ smaller than the latent baseline's; because the proposed method also operates in latent space (smaller $c_{\text{eval}}$) the wall-clock gains over the pixel-space RePaint are even larger, while the gain over the already-latent baseline tracks the NFE ratio. Table 2.2 summarizes the four improvements and the cost lever each one moves; the measured consequences are reported in Chapter 3.

Table: Summary of the four proposed improvements and the cost or quality lever each addresses.

| # | Improvement | Section | Primary effect | Cost lever moved |
|---|---|---|---|---|
| A | Mask-aware latent harmonization (feathered blend) | 2.1 | removes boundary seams | — (fidelity) |
| B | Context-guided masked attention | 2.1 | improves semantic coherence | — (fidelity) |
| C | Adaptive (decaying) resampling schedule | 2.2 | fewer wasted repetitions | reduces $\bar r$ |
| D | High-order latent ODE solver | 2.2 | accuracy in few steps | reduces $N$ |


# Chapter 3: System Construction, Implementation, and Experimental Evaluation

The previous chapter described four improvements at the level of individual mechanisms. This chapter assembles them into a single working system, specifies how that system is implemented and trained, and evaluates it against representative prior methods. The evaluation has two goals that mirror the two halves of the thesis: to show that the proposed model reconstructs masked regions with fidelity at least as good as strong baselines (Section 2.1), and to show that it does so at a fraction of the sampling cost of comparable diffusion methods (Section 2.2). Section 3.1 gives the end-to-end architecture, Section 3.2 the implementation and training details, Section 3.3 the evaluation protocol, Sections 3.4 through 3.6 the quantitative, efficiency, and ablation results, Section 3.7 the qualitative results and robustness analysis, and Sections 3.8 and 3.9 the discussion and conclusion.

> **A note on the reported numbers.** The quantitative results in this chapter are *illustrative placeholders* that reflect the relative behavior one expects from the design — the ordering of methods, the rough magnitude of the speed-ups, and the direction of each ablation — but they are not measurements from a trained model. They are included so that the evaluation structure, tables, and figures are complete and internally consistent. Before the thesis is submitted, every numeric entry in Sections 3.4 through 3.7 should be replaced with values measured from an actual training and evaluation run using the protocol of Section 3.3.

## 3.1 System architecture overview

The proposed system is a latent diffusion inpainting model with the four improvements of Chapter 2 integrated at the points where they act. Figure 3.1 shows the full data path for a single inference. An input image and a binary mask enter on the left. The known part of the image is encoded once by the frozen VAE encoder into a latent context tensor; the mask is downsampled to latent resolution. Sampling then runs in the latent space: starting from Gaussian noise, the conditioned U-Net is evaluated by the high-order ODE solver (Improvement D), the adaptive schedule (Improvement C) decides how many harmonizing repetitions to apply at the current noise level, each repetition performs the feathered latent blend (Improvement A), and every U-Net evaluation uses context-biased attention (Improvement B). After the final step the latent is decoded once by the VAE decoder, and the decoded pixels are composited with the original known pixels so that the unmasked region is preserved exactly.

![End-to-end architecture of the proposed system. Encoding and decoding happen once each; the four improvements act inside the latent sampling loop. The known pixels are reimposed after decoding so they are preserved bit-for-bit.](figures/fig_3_1_system.png){width=98%}

Two design choices in this layout are worth making explicit. First, the encoder and decoder are evaluated exactly once per image, not once per step; only the U-Net runs inside the loop. This is the structural reason the latent foundation is fast, and it is why the resampling repetitions of Improvement A and C are affordable — a repetition costs one U-Net evaluation in latent space, not one full pixel-space denoising plus a re-encode. Second, the four improvements are orthogonal in implementation: A and C touch only the sampling loop's blending logic, B touches only the attention modules, and D replaces only the update rule. None of them changes the training objective, so the same trained network supports all of the ablations in Section 3.6 by toggling sampler flags.

## 3.2 Implementation details

### 3.2.1 Network configuration

The backbone follows the standard latent-diffusion design: a pretrained VAE with a downsampling factor of eight, and a time-conditioned U-Net operating on the latent tensor. For images at $256\times256$ the latent is $32\times32\times4$. The U-Net uses four resolution levels with residual blocks and self-attention at the lower three resolutions; the context-biased attention of Improvement B is applied at exactly those attention layers. Table 3.1 lists the configuration.

Table: Network configuration of the proposed model.

| Component | Setting |
|---|---|
| VAE downsampling factor | 8 ($256\times256 \to 32\times32$) |
| Latent channels | 4 |
| U-Net base channels | 256 |
| Channel multipliers | 1, 2, 3, 4 |
| Residual blocks per level | 2 |
| Attention resolutions (latent) | 16, 8, 4 |
| Attention heads | 8 |
| Conditioning channels (context + mask) | 4 + 1 |
| Total U-Net parameters | $\approx 3.9 \times 10^8$ |

The conditioning is supplied by channel concatenation, as described in Section 2.1.1: the noisy latent, the encoded known-region context, and the downsampled mask are concatenated along the channel axis before the first convolution, so the input to the U-Net has $4+4+1=9$ channels.

### 3.2.2 Datasets

The model is intended to be trained and evaluated on three standard datasets that together cover faces, natural scenes, and general objects. Faces test fine structural coherence (eyes, symmetry), scenes test texture and layout plausibility, and objects test diversity. Table 3.2 summarizes them.

Table: Datasets used for training and evaluation.

| Dataset | Domain | Resolution | Train images | Eval images |
|---|---|---|---|---|
| CelebA-HQ | Aligned faces | $256\times256$ | 28,000 | 2,000 |
| Places2 | Natural scenes | $256\times256$ | 1.8M (subset 500k) | 5,000 |
| ImageNet | General objects | $256\times256$ | 1.28M (subset 300k) | 5,000 |

### 3.2.3 Mask generation

Robustness to mask shape matters as much as raw fidelity, because real editing masks range from thin scribbles to large rectangular holes. During training, masks are sampled from a mixture so the model never specializes to one hole type: free-form brush strokes of random width and length, random rectangles, and large center holes. The mask ratio (fraction of pixels removed) is drawn uniformly from 10% to 60%. Figure 3.2 shows representative masks from each category.

![Representative training masks: free-form brush strokes, random rectangles, and large center holes. Mixing categories during training prevents the model from specializing to a single hole shape.](figures/fig_3_2_masks.png){width=92%}

### 3.2.4 Training hyperparameters

The U-Net is trained with the simple noise-prediction objective of Equation (2.1); the VAE is frozen throughout. Training uses the AdamW optimizer with an exponential moving average (EMA) of the weights for evaluation, which is standard practice for diffusion models and noticeably stabilizes sample quality. Table 3.3 lists the settings. Note that the four improvements introduce no new trainable parameters and no new loss terms — improvements A, C, and D are sampler-side, and improvement B adds a single scalar gate $\lambda_0$ per attention layer that can either be fixed or learned at negligible cost — so the training recipe is exactly that of a plain latent inpainting model.

Table: Training hyperparameters.

| Hyperparameter | Value |
|---|---|
| Optimizer | AdamW |
| Learning rate | $1.0\times10^{-4}$ |
| Weight decay | $1.0\times10^{-2}$ |
| Batch size | 64 |
| Training steps | $5.0\times10^{5}$ |
| EMA decay | 0.9999 |
| Noise schedule | linear, $T=1000$ |
| Precision | mixed (fp16) |
| Hardware (assumed) | 4× A100 40GB |

## 3.3 Evaluation protocol

### 3.3.1 Metrics

The evaluation reports both distributional and perceptual quality, plus two cost metrics, so that fidelity and speed can be read off together. Fréchet Inception Distance (FID) [38] measures how close the distribution of inpainted images is to the distribution of real images; lower is better, and it is the headline quality metric for generative inpainting because it rewards realistic, diverse completions rather than pixel-exact ones. Learned Perceptual Image Patch Similarity (LPIPS) [39] measures perceptual distance between the completion and the ground truth; lower is better. PSNR and SSIM [40] measure pixel-level and structural reconstruction; they are reported for completeness but are known to under-reward plausible-but-non-identical completions, so they are read with that caveat. For cost, the number of function evaluations (NFE) counts U-Net forward passes per image and is hardware-independent, while runtime (seconds per image) is the wall-clock figure on the reference hardware. The combination of NFE and runtime is deliberate: NFE isolates the algorithmic step count, and runtime captures the additional benefit of working in latent rather than pixel space.

### 3.3.2 Baselines

The proposed method is compared against five representative prior methods spanning the two dominant families. DeepFill v2 [27], LaMa [25], and MAT [49] are feed-forward GAN-based inpainting models: they are extremely fast (a single forward pass) and serve as the speed reference. RePaint [16] and a latent-diffusion inpainting model (LDM-Inpaint) [15] are diffusion-based: RePaint is the fidelity-and-cost reference because it uses the resampling strategy that motivates Improvement C, and LDM-Inpaint is the closest architectural relative because it shares the latent foundation. This selection lets the evaluation answer the two questions of the thesis directly: against the GAN models, does diffusion-level quality survive the speed-ups; and against the diffusion models, how large is the speed-up at equal or better quality.

### 3.3.3 Evaluation settings

All methods are evaluated on the same held-out images with the same masks. The proposed method uses its default sampler settings ($N=20$ solver steps, $r_{\max}=8$, $\gamma=1.5$, second-order solver), RePaint uses its published settings ($N=250$, $r=10$), and LDM-Inpaint uses $N=250$ DDIM steps. FID is computed over the full evaluation set; LPIPS, PSNR, and SSIM are averaged per image; runtime is the mean over the evaluation set on a single A100 with batch size one.

## 3.4 Quantitative results

Tables 3.4 and 3.5 report the main quality comparison on CelebA-HQ and Places2. The proposed method attains the best FID on both datasets and the best LPIPS overall, while the feed-forward GAN models trail on FID despite competitive PSNR/SSIM — the expected pattern, since FID rewards distributional realism that single-pass regression-style models tend to miss on large holes. Among the diffusion methods, the proposed model slightly improves on RePaint's quality while, as Section 3.5 shows, costing a fraction of its compute.

Table: Quantitative comparison on CelebA-HQ ($256\times256$, mixed masks). Lower is better for FID and LPIPS; higher is better for PSNR and SSIM. **Best** in bold.

| Method | Family | FID $\downarrow$ | LPIPS $\downarrow$ | PSNR $\uparrow$ | SSIM $\uparrow$ |
|---|---|---|---|---|---|
| DeepFill v2 [27] | GAN | 8.5 | 0.121 | 24.1 | 0.861 |
| LaMa [25] | GAN | 6.2 | 0.103 | 25.3 | 0.889 |
| MAT [49] | GAN | 5.1 | 0.095 | 25.6 | 0.897 |
| RePaint [16] | Diffusion | 4.6 | 0.085 | 25.9 | 0.902 |
| LDM-Inpaint [15] | Diffusion (latent) | 4.9 | 0.088 | 25.7 | 0.899 |
| **Ours** | Diffusion (latent) | **4.3** | **0.082** | **26.1** | **0.905** |

Table: Quantitative comparison on Places2 ($256\times256$, mixed masks).

| Method | Family | FID $\downarrow$ | LPIPS $\downarrow$ | PSNR $\uparrow$ | SSIM $\uparrow$ |
|---|---|---|---|---|---|
| DeepFill v2 [27] | GAN | 14.8 | 0.148 | 22.4 | 0.802 |
| LaMa [25] | GAN | 9.7 | 0.121 | 23.6 | 0.841 |
| MAT [49] | GAN | 8.9 | 0.114 | 23.8 | 0.848 |
| RePaint [16] | Diffusion | 8.1 | 0.106 | 24.0 | 0.853 |
| LDM-Inpaint [15] | Diffusion (latent) | 8.4 | 0.109 | 23.9 | 0.851 |
| **Ours** | Diffusion (latent) | **7.6** | **0.101** | **24.2** | **0.857** |

Figure 3.4 plots FID against NFE for the diffusion methods, which is the clearest single view of the thesis's claim: the proposed method sits in the lower-left corner, reaching the best FID at the smallest NFE, while RePaint reaches comparable FID only after roughly two orders of magnitude more function evaluations. Figure 3.5 shows the FID comparison as bars across all six methods on both datasets, and Figure 3.6 shows the corresponding LPIPS comparison.

![FID versus NFE for the diffusion-based methods. The proposed method (lower-left) reaches the best FID at the smallest number of function evaluations; RePaint approaches the same FID only at far higher NFE. Illustrative values.](figures/fig_3_4_fid_nfe.png){width=82%}

![FID across all six methods on CelebA-HQ and Places2. Lower is better. The proposed method attains the lowest FID on both datasets. Illustrative values.](figures/fig_3_5_fid_bars.png){width=92%}

![LPIPS across all six methods. Lower is better. The diffusion methods, and the proposed method in particular, produce perceptually closer completions than the feed-forward baselines. Illustrative values.](figures/fig_3_6_lpips.png){width=92%}

## 3.5 Efficiency and speed comparison

The efficiency comparison is where the four speed-oriented design choices pay off. Table 3.6 reports NFE, runtime, and the speed-up relative to RePaint. The proposed method uses about $40$ function evaluations against RePaint's $\approx 2{,}500$, and because each evaluation is in latent space rather than pixel space, the wall-clock advantage is larger still: roughly $20\times$ faster than RePaint end-to-end, and about $3.5\times$ faster than the already-latent LDM-Inpaint baseline at the same time matching or improving its quality. The feed-forward GAN models remain faster in absolute terms — a single forward pass is hard to beat — but they do not reach the proposed method's FID, which is precisely the trade the thesis sets out to improve: diffusion-level quality at a cost that is now within striking distance of feed-forward methods rather than three orders of magnitude away.

Table: Efficiency comparison. NFE is U-Net forward passes per image; runtime is seconds per image on one A100; speed-up is relative to RePaint. Illustrative values.

| Method | Family | NFE | Runtime (s/img) $\downarrow$ | Speed-up vs RePaint |
|---|---|---|---|---|
| DeepFill v2 [27] | GAN | 1 | 0.02 | 925× |
| LaMa [25] | GAN | 1 | 0.04 | 463× |
| MAT [49] | GAN | 1 | 0.08 | 231× |
| RePaint [16] | Diffusion | $\approx 2500$ | 18.5 | 1× |
| LDM-Inpaint [15] | Diffusion (latent) | 250 | 3.2 | 5.8× |
| **Ours** | Diffusion (latent) | **40** | **0.92** | **20×** |

![Runtime per image (log scale) across methods. The proposed method narrows the gap between diffusion and feed-forward inpainting by more than an order of magnitude relative to RePaint. Illustrative values.](figures/fig_3_7_runtime.png){width=88%}

Figure 3.7 shows runtime on a logarithmic axis, which makes the spread legible: the proposed method moves the diffusion family from the tens-of-seconds regime into the sub-second regime, the same regime as the GAN models, while keeping diffusion-level quality.

## 3.6 Ablation studies

The ablations isolate the contribution of each improvement by toggling it on or off in the sampler while holding the trained network fixed. Because the improvements are orthogonal in implementation (Section 3.1), this is a clean factorization: no retraining is needed between rows.

### 3.6.1 Cumulative ablation

Table 3.7 adds the improvements one at a time, in the order A, B, C, D, starting from the plain latent inpainting baseline. The two fidelity improvements (A, B) lower FID without changing runtime materially; the two speed improvements (C, D) cut runtime sharply while leaving FID essentially unchanged — C reduces the number of resampling repetitions and D reduces the number of solver steps. Figure 3.8 visualizes the same data as a two-axis trajectory, showing the design moving down (better FID) and then left (lower runtime) as improvements accumulate.

Table: Cumulative ablation on CelebA-HQ. Each row adds one improvement to the row above. Illustrative values.

| Configuration | FID $\downarrow$ | Runtime (s/img) $\downarrow$ |
|---|---|---|
| Latent baseline (no improvements) | 4.90 | 3.20 |
| + A: mask-aware harmonization | 4.70 | 3.30 |
| + B: context-guided attention | 4.45 | 3.45 |
| + C: adaptive resampling schedule | 4.40 | 1.60 |
| + D: high-order latent solver | 4.30 | 0.92 |

![Cumulative ablation trajectory. Adding the fidelity improvements (A, B) moves the design downward to lower FID; adding the speed improvements (C, D) moves it leftward to lower runtime. Illustrative values.](figures/fig_3_8_ablation.png){width=82%}

A small detail in the table is worth noting: improvements A and B slightly *increase* runtime (from 3.20 to 3.45 s/img) because harmonization adds blending work and the attention bias adds a small per-layer cost. This is the expected and acceptable price of higher fidelity, and it is more than recovered by C and D, which together bring runtime down to 0.92 s/img — well below the baseline's 3.20.

### 3.6.2 Resampling schedule

Table 3.8 compares resampling strategies at a fixed solver-step count. No resampling is fastest but leaves visible seams (higher FID); constant resampling at $r=8$ fixes the seams but is wasteful; the adaptive schedule of Improvement C matches the constant-resampling FID at roughly a quarter of the resampling cost, because it spends repetitions only at the high-noise steps where they help. Figure 3.10 plots the FID-versus-cost trade-off for the three strategies.

Table: Effect of the resampling schedule (solver steps fixed at $N=20$). Illustrative values.

| Resampling strategy | Mean repetitions $\bar r$ | FID $\downarrow$ | Runtime (s/img) $\downarrow$ |
|---|---|---|---|
| None ($r=1$) | 1.0 | 4.62 | 0.55 |
| Constant ($r=8$) | 8.0 | 4.31 | 2.90 |
| Adaptive (ours, $\gamma=1.5$) | $\approx 2.0$ | 4.30 | 0.92 |

![Resampling trade-off: FID versus runtime for no resampling, constant resampling, and the adaptive schedule. The adaptive schedule recovers nearly all of the quality of constant resampling at a fraction of the cost. Illustrative values.](figures/fig_3_10_resample_tradeoff.png){width=82%}

### 3.6.3 Solver order

Table 3.9 isolates Improvement D by comparing a first-order (DDIM-style) update against the second-order update at matched step counts. At a large step budget the two are indistinguishable in quality, but at the small budgets that make diffusion inpainting practical, the second-order solver attains markedly lower FID for the same number of evaluations — which is what permits dropping $N$ to 20 without quality loss.

Table: Solver order at matched step counts (resampling fixed at the adaptive schedule). Illustrative values.

| Solver | $N=10$ FID | $N=20$ FID | $N=50$ FID |
|---|---|---|---|
| First-order (DDIM) | 6.8 | 4.9 | 4.32 |
| Second-order (ours) | 4.9 | 4.30 | 4.29 |

## 3.7 Qualitative results and robustness

### 3.7.1 Qualitative comparison

Figure 3.3 shows a qualitative comparison on representative masked inputs. *These panels are schematic placeholders generated for layout purposes, not real model outputs; they should be replaced with actual completions before submission.* The intended reading is that the feed-forward baselines tend to blur or over-smooth large holes, RePaint produces sharp completions but at high cost, and the proposed method produces comparably sharp and coherent completions at low cost, with the seam-free boundaries that Improvement A is designed to deliver.

![Qualitative comparison on representative inputs (masked input, baselines, and the proposed method). **Schematic placeholder — not real model outputs.** Replace with actual completions before submission.](figures/fig_3_3_qualitative.png){width=98%}

### 3.7.2 Robustness to mask ratio

A model that is only good at small holes is of limited practical use, so Figure 3.11 reports FID as a function of mask ratio from 10% to 60% for LaMa, RePaint, and the proposed method. All methods degrade as the hole grows, which is unavoidable — larger holes carry less surrounding context — but the proposed method degrades most gracefully and stays closest to RePaint's quality across the whole range, while remaining far cheaper. The gap between the proposed method and the feed-forward LaMa widens at large mask ratios, which is consistent with the expectation that generative diffusion sampling helps most when there is the least context to copy from.

![FID versus mask ratio for LaMa, RePaint, and the proposed method. All degrade as the hole grows; the proposed method tracks RePaint's quality across the range while remaining far cheaper. Illustrative values.](figures/fig_3_11_mask_ratio.png){width=82%}

### 3.7.3 Training behavior

Figure 3.9 shows the training loss and validation FID over the course of training. The curves are the smooth, monotone-then-plateau shape expected of a well-behaved diffusion training run; they are included to document the training protocol and would be replaced with the real logged curves.

![Training loss and validation FID over training steps. Illustrative curves documenting the expected training behavior.](figures/fig_3_9_training.png){width=88%}

## 3.8 Discussion and limitations

The results, read together, support the thesis's two claims at the level of design intent: the fidelity improvements (A, B) account for the quality edge over the diffusion baselines in Tables 3.4 and 3.5, and the speed improvements (C, D) account for the order-of-magnitude cost reduction in Table 3.6, with the cumulative ablation in Table 3.7 attributing each effect to its mechanism. Three limitations should be stated plainly.

First, and most importantly, the numbers in this chapter are illustrative rather than measured; the design's *predicted* behavior is reported, and the central remaining work is to train the model and replace these figures with real measurements. The structure of the evaluation — the metrics, baselines, tables, and ablations — is built to make that substitution direct.

Second, the latent foundation that makes the method fast also imposes a quality ceiling: because completion happens in the VAE's latent space and is decoded once, the finest pixel-level detail is bounded by the autoencoder's reconstruction quality. For most editing tasks this is invisible, but for applications demanding pixel-exact texture it is a real constraint, and a pixel-space refinement pass would be the natural remedy at some additional cost.

Third, the adaptive resampling schedule and the solver order each introduce a hyperparameter ($\gamma$, and the choice of order) whose best setting is mildly dataset-dependent; the defaults used here are reasonable across the three datasets but are not separately tuned per dataset, and a small per-domain search would likely recover a little more quality or speed.

## 3.9 Conclusion and future work

This thesis set out to improve both the effectiveness and the speed of diffusion-based image inpainting, and it did so by building a single latent-diffusion inpainting system around four previously published ideas adapted to the inpainting setting. On the effectiveness side, mask-aware latent harmonization removes the boundary seams that naive latent injection produces, and context-guided masked attention steers the network toward the known content so completions are semantically coherent. On the speed side, an adaptive resampling schedule spends harmonizing repetitions only where they help, and a high-order latent ODE solver reaches the same trajectory accuracy in far fewer steps. The combination is designed to deliver diffusion-level fidelity — matching or slightly improving on RePaint and a latent baseline in FID and LPIPS — at roughly $20\times$ less wall-clock cost than RePaint and about $3.5\times$ less than the latent baseline, moving diffusion inpainting from the tens-of-seconds regime into the sub-second regime occupied by feed-forward methods.

Several directions follow naturally. The most immediate is to carry out the full training and evaluation run and replace the illustrative numbers throughout Chapter 3 with measured ones, including significance testing across mask types. Beyond that, the latent quality ceiling motivates a lightweight pixel-space refinement stage; the solver could be pushed further with distillation [23] or consistency-style training [24] to reach single-digit NFE; and the context bias of Improvement B could be made input-adaptive rather than schedule-driven, letting the network learn how strongly to attend to known content at each noise level. Extending the system to text-conditioned and higher-resolution inpainting, building on the same latent foundation [15, 44, 45], is a further natural step.

# References

*References 1–9 are intentionally left blank.*

[1]

[2]

[3]

[4]

[5]

[6]

[7]

[8]

[9]

[10] J. Ho, A. Jain, and P. Abbeel, "Denoising Diffusion Probabilistic Models," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2020.

[11] J. Song, C. Meng, and S. Ermon, "Denoising Diffusion Implicit Models," in *International Conference on Learning Representations (ICLR)*, 2021.

[12] Y. Song and S. Ermon, "Generative Modeling by Estimating Gradients of the Data Distribution," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2019.

[13] Y. Song, J. Sohl-Dickstein, D. P. Kingma, A. Kumar, S. Ermon, and B. Poole, "Score-Based Generative Modeling through Stochastic Differential Equations," in *International Conference on Learning Representations (ICLR)*, 2021.

[14] P. Dhariwal and A. Nichol, "Diffusion Models Beat GANs on Image Synthesis," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2021.

[15] R. Rombach, A. Blattmann, D. Lorenz, P. Esser, and B. Ommer, "High-Resolution Image Synthesis with Latent Diffusion Models," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2022.

[16] A. Lugmayr, M. Danelljan, A. Romero, F. Yu, R. Timofte, and L. Van Gool, "RePaint: Inpainting using Denoising Diffusion Probabilistic Models," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2022.

[17] C. Saharia, W. Chan, H. Chang, C. A. Lee, J. Ho, T. Salimans, D. J. Fleet, and M. Norouzi, "Palette: Image-to-Image Diffusion Models," in *ACM SIGGRAPH*, 2022.

[18] A. Nichol, P. Dhariwal, A. Ramesh, P. Shyam, P. Mishkin, B. McGrew, I. Sutskever, and M. Chen, "GLIDE: Towards Photorealistic Image Generation and Editing with Text-Guided Diffusion Models," in *International Conference on Machine Learning (ICML)*, 2022.

[19] O. Avrahami, D. Lischinski, and O. Fried, "Blended Diffusion for Text-Driven Editing of Natural Images," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2022.

[20] J. Ho and T. Salimans, "Classifier-Free Diffusion Guidance," in *NeurIPS Workshop on Deep Generative Models and Downstream Applications*, 2021.

[21] A. Nichol and P. Dhariwal, "Improved Denoising Diffusion Probabilistic Models," in *International Conference on Machine Learning (ICML)*, 2021.

[22] C. Lu, Y. Zhou, F. Bao, J. Chen, C. Li, and J. Zhu, "DPM-Solver: A Fast ODE Solver for Diffusion Probabilistic Model Sampling in Around 10 Steps," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2022.

[23] T. Salimans and J. Ho, "Progressive Distillation for Fast Sampling of Diffusion Models," in *International Conference on Learning Representations (ICLR)*, 2022.

[24] Y. Song, P. Dhariwal, M. Chen, and I. Sutskever, "Consistency Models," in *International Conference on Machine Learning (ICML)*, 2023.

[25] R. Suvorov, E. Logacheva, A. Mashikhin, A. Remizova, A. Ashukha, A. Silvestrov, N. Kong, H. Goka, K. Park, and V. Lempitsky, "Resolution-Robust Large Mask Inpainting with Fourier Convolutions (LaMa)," in *Proceedings of the IEEE/CVF Winter Conference on Applications of Computer Vision (WACV)*, 2022.

[26] J. Yu, Z. Lin, J. Yang, X. Shen, X. Lu, and T. S. Huang, "Generative Image Inpainting with Contextual Attention," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018.

[27] J. Yu, Z. Lin, J. Yang, X. Shen, X. Lu, and T. S. Huang, "Free-Form Image Inpainting with Gated Convolution (DeepFill v2)," in *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*, 2019.

[28] G. Liu, F. A. Reda, K. J. Shih, T.-C. Wang, A. Tao, and B. Catanzaro, "Image Inpainting for Irregular Holes Using Partial Convolutions," in *Proceedings of the European Conference on Computer Vision (ECCV)*, 2018.

[29] K. Nazeri, E. Ng, T. Joseph, F. Z. Qureshi, and M. Ebrahimi, "EdgeConnect: Generative Image Inpainting with Adversarial Edge Learning," in *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV) Workshops*, 2019.

[30] D. Pathak, P. Krähenbühl, J. Donahue, T. Darrell, and A. A. Efros, "Context Encoders: Feature Learning by Inpainting," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2016.

[31] S. Iizuka, E. Simo-Serra, and H. Ishikawa, "Globally and Locally Consistent Image Completion," *ACM Transactions on Graphics (TOG)*, vol. 36, no. 4, 2017.

[32] I. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. Warde-Farley, S. Ozair, A. Courville, and Y. Bengio, "Generative Adversarial Nets," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2014.

[33] D. P. Kingma and M. Welling, "Auto-Encoding Variational Bayes," in *International Conference on Learning Representations (ICLR)*, 2014.

[34] O. Ronneberger, P. Fischer, and T. Brox, "U-Net: Convolutional Networks for Biomedical Image Segmentation," in *Medical Image Computing and Computer-Assisted Intervention (MICCAI)*, 2015.

[35] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, Ł. Kaiser, and I. Polosukhin, "Attention Is All You Need," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2017.

[36] P. Esser, R. Rombach, and B. Ommer, "Taming Transformers for High-Resolution Image Synthesis (VQGAN)," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2021.

[37] J. Sohl-Dickstein, E. A. Weiss, N. Maheswaranathan, and S. Ganguli, "Deep Unsupervised Learning using Nonequilibrium Thermodynamics," in *International Conference on Machine Learning (ICML)*, 2015.

[38] M. Heusel, H. Ramsauer, T. Unterthiner, B. Nessler, and S. Hochreiter, "GANs Trained by a Two Time-Scale Update Rule Converge to a Local Nash Equilibrium (FID)," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2017.

[39] R. Zhang, P. Isola, A. A. Efros, E. Shechtman, and O. Wang, "The Unreasonable Effectiveness of Deep Features as a Perceptual Metric (LPIPS)," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2018.

[40] Z. Wang, A. C. Bovik, H. R. Sheikh, and E. P. Simoncelli, "Image Quality Assessment: From Error Visibility to Structural Similarity (SSIM)," *IEEE Transactions on Image Processing*, vol. 13, no. 4, 2004.

[41] T. Karras, M. Aittala, T. Aila, and S. Laine, "Elucidating the Design Space of Diffusion-Based Generative Models (EDM)," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2022.

[42] C. Meng, Y. He, Y. Song, J. Song, J. Wu, J.-Y. Zhu, and S. Ermon, "SDEdit: Guided Image Synthesis and Editing with Stochastic Differential Equations," in *International Conference on Learning Representations (ICLR)*, 2022.

[43] L. Zhang, A. Rao, and M. Agrawala, "Adding Conditional Control to Text-to-Image Diffusion Models (ControlNet)," in *Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)*, 2023.

[44] A. Ramesh, P. Dhariwal, A. Nichol, C. Chu, and M. Chen, "Hierarchical Text-Conditional Image Generation with CLIP Latents (DALL·E 2)," *arXiv:2204.06125*, 2022.

[45] C. Saharia, W. Chan, S. Saxena, L. Li, J. Whang, E. Denton, S. K. S. Ghasemipour, B. K. Ayan, S. S. Mahdavi, R. G. Lopes, T. Salimans, J. Ho, D. J. Fleet, and M. Norouzi, "Photorealistic Text-to-Image Diffusion Models with Deep Language Understanding (Imagen)," in *Advances in Neural Information Processing Systems (NeurIPS)*, 2022.

[46] F. Bao, C. Li, J. Zhu, and B. Zhang, "Analytic-DPM: An Analytic Estimate of the Optimal Reverse Variance in Diffusion Probabilistic Models," in *International Conference on Learning Representations (ICLR)*, 2022.

[47] T. Karras, S. Laine, and T. Aila, "A Style-Based Generator Architecture for Generative Adversarial Networks (StyleGAN)," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2019.

[48] S. Zhao, J. Cui, Y. Sheng, Y. Dong, X. Liang, E. I. Chang, and Y. Xu, "Large Scale Image Completion via Co-Modulated Generative Adversarial Networks (CoModGAN)," in *International Conference on Learning Representations (ICLR)*, 2021.

[49] W. Li, Z. Lin, K. Zhou, L. Qi, Y. Wang, and J. Jia, "MAT: Mask-Aware Transformer for Large Hole Image Inpainting," in *Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR)*, 2022.

[50] C. Lu, Y. Zhou, F. Bao, J. Chen, C. Li, and J. Zhu, "DPM-Solver++: Fast Solver for Guided Sampling of Diffusion Probabilistic Models," *arXiv:2211.01095*, 2022.
