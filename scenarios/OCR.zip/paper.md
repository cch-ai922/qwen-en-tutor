---
title: "End-to-End Optical Character Recognition for Low-Resource Languages with Vision–Language Models: A Document-Anchored, Cross-Lingually Transferred Approach"
author: "[Author Name], [Affiliation]"
date: "June 2026"
---

# Abstract

Optical character recognition (OCR) has been reshaped by vision–language models (VLMs) that read a page image directly into linearized text, dispensing with the brittle detect–recognize–reorder pipelines of classical systems. The open *olmOCR* family demonstrated that a single, modestly sized VLM—fine-tuned on documents labelled through a layout-aware prompting technique called *document anchoring*, and later sharpened with reinforcement learning against verifiable unit tests—can match or exceed far larger proprietary models on English document conversion at a fraction of the cost. These advances, however, have been overwhelmingly *English-centric*: their training data, their evaluation benchmark, and their verifiable rewards all assume the Latin script.

This dissertation asks how to build a *dedicated* end-to-end OCR model that serves **low-resource languages as well as English**, under a deliberately asymmetric and realistic resource assumption: the **language model already understands the target languages** (we adopt a multilingual 8B-parameter decoder that has been pre-trained on the relevant low-resource languages), whereas the **vision encoder has only ever been exposed to English document images** and has never seen the target scripts. We argue—and formalize—that in this regime the binding constraint on accuracy is not language modelling but *vision-side script coverage* and the *quality of the vision-to-language bridge*.

We design an image+text-to-text VLM by combining a publicly available multilingual vision encoder (SigLIP 2, NaFlex variant) with a publicly available multilingual decoder (Aya-Expanse-8B), connected by a lightweight projector, and we adapt the olmOCR development methodology end to end. Across the five chapters we introduce ten focused, *modest* improvements—two per chapter—each motivated by the asymmetric-capability hypothesis and described in detail rather than asserted: (1) a formal decomposition of the problem and (2) an error-source taxonomy (Chapter 1); (3) script-adaptive NaFlex sequence-length allocation and (4) a script-conditioned LoRA-routed connector (Chapter 2); (5) an anchor-conditioned synthetic script-rendering data pipeline and (6) cross-lingual encoder warm-up via glyph–text alignment distillation (Chapter 3); (7) a progressive supervised fine-tuning curriculum and (8) script-aware reinforcement learning with verifiable rewards extended by diacritic- and normalization-sensitive unit tests (Chapter 4); and (9) a serving pipeline with confidence-gated re-rendering and (10) *LR-OCR-Bench*, a low-resource evaluation benchmark, together with a comparative assessment against prior OCR methods (Chapter 5).

We present the system, its implementation, and an evaluation methodology that compares the proposed model against representative classical and neural baselines—Tesseract, GOT-OCR2.0, Marker, MinerU, dots.ocr, DeepSeek-OCR, PaddleOCR-VL, and olmOCR 2—on both an English benchmark and a low-resource benchmark spanning Brahmic, Ge'ez, Khmer, and Tibetan scripts. Reported experimental numbers for the proposed system are clearly labelled as projected targets pending full training runs; published numbers for prior systems are cited as such. The contribution of this work is a coherent, reproducible recipe for transferring an English-only vision encoder to unseen scripts by leaning on an already-multilingual decoder, and a demonstration that the largest accuracy gains for low-resource OCR come from cheap synthetic visual exposure and verifiable-reward fine-tuning rather than from scaling.

\newpage

# Preface and reading guide

This dissertation is organized so that a reader can follow a single thread—the *asymmetric-capability hypothesis*—from its statement to its test. The hypothesis, introduced in Chapter 1, is that when a language model already understands the target low-resource languages, the accuracy of end-to-end OCR is limited mainly by what the vision encoder can see and by how well its features are bridged into the decoder, rather than by language modelling. Every subsequent chapter contributes one mechanism that acts on this bottleneck and one piece of apparatus that measures whether it moved.

Three conventions aid reading. First, each chapter's two improvements are introduced with an explicit statement of the *problem addressed* (named in the error vocabulary of §1.4), the *mechanism*, *why it is principled rather than a tuning knob*, and—deliberately—*what we claim and what we do not*, so that the contribution is never overstated. Second, all experimental numbers for the proposed system are labelled as *projected targets* pending full training runs; numbers attributed to prior systems follow their published reports and are cited as such. The reader should treat the comparative tables of Chapter 5 as a measurement design with illustrative values, not as completed results. Third, the appendices are reference material: notation (A), per-script profiles (B), prompt templates (C), hyperparameters (D), a glossary (E), a worked inference example (F), unit-test specifications (G), and metric definitions (H). A reader interested only in the method may read Chapters 2–4; one interested in evaluation may read Chapter 5 with Appendices B, G, and H.

The work builds extensively and openly on the olmOCR family and on publicly available models, and it is written to be reproducible from open parts. Where it innovates, it does so modestly and in service of a single question: how to read the world's under-served scripts without paying for what we already have.

\newpage

# List of figures

Figure 1.1 — The asymmetric capability gap.
Figure 1.2 — Error-source decomposition for low-resource OCR.
Figure 2.1 — Overall architecture.
Figure 2.2 — Script-adaptive NaFlex allocation.
Figure 2.3 — Script-conditioned LoRA-routed connector.
Figure 3.1 — Anchor-conditioned synthetic script-rendering pipeline.
Figure 3.2 — Cross-lingual encoder warm-up.
Figure 4.1 — Progressive SFT curriculum.
Figure 4.2 — Script-aware RLVR.
Figure 5.1 — Serving pipeline with confidence-gated re-rendering.
Figure 5.2 — Comparative assessment on English and low-resource benchmarks.
Figure 5.3 — Per-script ablation.

# List of tables

Table 1.1 — Mapping of improvements to error sources and chapters.
Table 1.2 — OCR paradigms and adaptation cost.
Table 1.3 — The ten contributions at a glance.
Table 2.1 — Components, scale, and trainable surface by phase.
Table 2.2 — Vision encoder candidates.
Table 2.3 — Decoder candidates.
Table 3.1 — Training data mixture.
Table 3.2 — Illustrative synthetic data inventory.
Table 4.1 — Training configuration by stage.
Table 5.1 — Comparative assessment (English and low-resource).
Table 5.2 — Projected error-source proxies.
Table 5.3 — Projected per-script F1.
Table 5.4 — Efficiency and openness.
Table A.1 — Notation. Table B.1 — Per-script test/resolution summary.
Table D.1 — Consolidated hyperparameters. Table E.1 — Acronyms and terms.

\newpage

# Chapter 1 — Analysis of Prior Research and Problem Formulation

## 1.1 Background and motivation

The world's written knowledge is unevenly machine-readable. Born-digital text on the web is trivially indexed, but an enormous fraction of human record—scanned books, government gazettes, legal filings, scientific archives, religious manuscripts, newspapers—exists only as page images inside PDFs and scans. For high-resource languages, decades of investment in optical character recognition have made this content largely accessible. For the several thousand languages outside the commercial mainstream, it has not. Many of these languages are spoken by tens of millions of people yet possess only a handful of usable digital corpora; the documents that would constitute such corpora sit, unread by machines, in exactly the image formats that OCR is meant to unlock [1], [2].

The recent history of OCR can be read as a steady collapse of a multi-stage pipeline into a single learned function. Classical engines such as Tesseract [3] separate the task into binarization, layout analysis, line and word segmentation, per-glyph or per-line classification, and a language-model post-correction stage. Each stage is independently engineered and independently fallible; errors compound, and adapting the pipeline to a new script means re-tuning several of these stages with script-specific heuristics and labelled data. Deep sequence models removed the explicit segmentation step within a line—CRNN-CTC recognizers [4], attention-based encoder–decoders, and ultimately Transformer recognizers such as TrOCR [5]—but they still presupposed an upstream layout and line-detection apparatus.

The decisive shift came with *end-to-end* document models that map a whole page image to structured text. Donut [6] showed that an OCR-free Transformer could read a document image directly into a target string. Nougat [7] specialized this idea for scientific PDFs, emitting Markdown with LaTeX equations. The arrival of general-purpose vision–language models—Flamingo [8], BLIP-2 [9], LLaVA [10], Qwen-VL [11] and its successors Qwen2-VL [12] and Qwen2.5-VL [13], and InternVL [14]—made it natural to treat OCR as just another image+text-to-text task, in which a vision encoder feeds visual tokens to a language-model decoder that has been instructed to transcribe.

Within this paradigm, the *olmOCR* project from the Allen Institute for AI is the most directly relevant prior art for this dissertation, for three reasons. First, it is fully open—weights, data, and code—so its method can be inspected and reproduced rather than guessed at [15], [16]. Second, it is built on exactly the architecture we adopt: a 7B-scale VLM fine-tuned for page linearization, originally from Qwen2-VL-7B-Instruct and later from Qwen2.5-VL-7B-Instruct [15], [16]. Third, it introduced two methodological ideas that we build on directly: *document anchoring*, a prompting technique that injects layout-aware text and coordinates extracted from born-digital PDFs alongside the page image to suppress hallucination and fix reading order [15]; and, in *olmOCR 2*, *reinforcement learning with verifiable rewards* (RLVR), in which a diverse battery of binary unit tests—generated at scale from synthetic documents with known ground truth—defines the reward signal for policy optimization [16], [17].

What olmOCR did *not* set out to do is serve low-resource languages. Its training mixture is dominated by English academic and administrative documents; its benchmark, *olmOCR-Bench*, is explicitly an English-language benchmark; and its verifiable rewards were designed around English math, tables, and multi-column layouts [16], [17]. Meanwhile, a parallel line of multilingual OCR VLMs has emerged—dots.ocr [18], DeepSeek-OCR [19], PaddleOCR-VL [20], Nanonets-OCR2, Granite-Docling, and Qwen3-VL among them [21]—several of which advertise coverage of 100+ languages including low-resource scripts such as Tibetan and Kannada. These systems, however, generally pursue multilinguality by training large encoders and decoders jointly on broad multilingual data; they do not isolate, or exploit, the situation that motivates this work, in which the *language* knowledge already exists in the decoder and only the *visual* knowledge of the script is missing.

This dissertation occupies that gap. We assume access to an 8B-scale decoder that already reads and writes the target low-resource languages, and to a vision encoder trained on English documents only, and we ask: *what is the cheapest, most reliable way to teach the combined model to read the target scripts?* The answer we develop—synthetic visual exposure, a script-aware bridge, and verifiable-reward fine-tuning, all grafted onto the olmOCR recipe—forms the substance of Chapters 2 through 5.

A concrete scenario fixes intuition. Imagine a national archive digitizing decades of government gazettes printed in Amharic. The documents exist as scans; the language has tens of millions of speakers and a capable text presence online, yet almost no annotated page-image datasets in the Ge'ez script. A conventional multilingual OCR effort would commission expensive human transcription to fine-tune on, or hope a broad model trained elsewhere happens to cover the script. The asymmetric-capability route asks instead: a competent Amharic-reading decoder already exists; the only thing missing is that the vision encoder has never been shown Ge'ez glyphs in realistic documents. If that visual exposure can be manufactured—by rendering the archive's own openly available Amharic text into realistic synthetic pages with known ground truth—then the model can be taught to read the script without a single hand-labelled scan. This scenario, multiplied across the scripts of Appendix B, is the practical situation the dissertation addresses, and it is why the cheap, vision-targeted interventions of Chapters 3 and 4 are not merely convenient but, under the stated resource constraints, the only affordable path.

## 1.2 Survey of prior research

We organize the literature into six strands and assign reference numbers used throughout this chapter.

**(a) Classical and line-level OCR.** Tesseract [3] remains the most widely deployed open engine and is our representative classical baseline. Its accuracy on clean Latin print is high but degrades sharply on complex scripts, noisy scans, and dense layouts, and its per-script LSTM models require dedicated training data [3]. CRNN-CTC recognizers [4] and Transformer recognizers such as TrOCR [5] improved line-level recognition but inherited the dependence on upstream detection. The CTC objective [4] and connectionist sequence alignment remain conceptually important and reappear, in spirit, in our discussion of alignment error in §1.4.

**(b) OCR-free end-to-end document models.** Donut [6] established that a document image could be read directly into a structured string without an explicit OCR module, trained with synthetic and real document pairs. Nougat [7] adapted this to academic PDFs and is notable for emitting LaTeX and Markdown, anticipating the structured-output expectation of modern document VLMs. GOT-OCR2.0 [22] unified plain text, formula, and table recognition in a single end-to-end model and is a strong open baseline.

**(c) General-purpose vision–language models.** The encoder–LLM template we adopt descends from Flamingo's gated cross-attention [8], BLIP-2's lightweight querying transformer [9], and the LLaVA family's simple projector connecting a frozen CLIP-style encoder to an LLM [10]. CLIP [23] and its sigmoid-loss successor SigLIP [24] supplied the contrastively trained vision encoders that most VLMs reuse. Qwen-VL [11], Qwen2-VL [12], and Qwen2.5-VL [13] introduced *native dynamic resolution* vision towers that process images at variable resolution without fixed tiling—an idea central to OCR, where text legibility depends on resolution—and these checkpoints are the literal backbone of olmOCR [15], [16]. InternVL [14] scaled the encoder and demonstrated strong document understanding.

**(d) The olmOCR family and verifiable-reward OCR.** olmOCR [15] fine-tuned Qwen2-VL-7B-Instruct on *olmOCR-mix-0225*, ~260,000 PDF pages drawn 60% from academic papers and the remainder from brochures, legal documents, diagrams, and slideshows, with silver labels produced by prompting GPT-4o under document anchoring [15], [25]. Its inference pipeline, optimized for SGLang [26] and vLLM [27], converted a million pages for roughly the cost of a restaurant meal, about 1/32 the price of the proprietary API it distilled from [25]. olmOCR 2 [16], [17] replaced much of the supervised-only recipe with RLVR: a synthetic pipeline renders real-seeded content into HTML with known ground truth and extracts binary unit tests (text presence, header/footer exclusion, reading order, table-cell correspondence, and visual equivalence of math formulas under KaTeX rendering), then applies Group Relative Policy Optimization (GRPO) [28] with the fraction of passing tests as reward, plus auxiliary rewards for correct end-of-sequence and metadata formatting. The closest neighbour, Infinity-Parser [29], also trains on HTML renderings but defines its reward from edit distance and structural consistency rather than unit tests. RLVR as a training paradigm derives from work on verifiable rewards for reasoning [30] and the GRPO algorithm introduced for mathematical reasoning [28].

**(e) Multilingual and low-resource OCR VLMs.** dots.ocr [18] unifies layout detection and content recognition in a single ~1.7–3B model with prompt-switchable tasks and reports strong multilingual parsing, including low-resource scripts. DeepSeek-OCR [19] introduced *optical context compression*, encoding text as a small number of vision tokens to process hundreds of thousands of pages per day, across roughly 100 languages. PaddleOCR-VL [20] pairs a NaViT-style dynamic-resolution encoder with a compact ERNIE decoder to cover 109 languages in a 0.9B model, explicitly targeting scripts—Cyrillic, Arabic, Devanagari, Thai—on which prior systems struggle. A complementary literature studies cross-lingual transfer and balanced multilingual fine-tuning for vision–language tasks [31], and the persistent under-representation of non-Latin scripts in OCR evaluation [2]. For specific scripts, dedicated studies address Indic [32], Arabic [33], Amharic/Ge'ez [34], Khmer [35], and historical or low-resource manuscript recognition [36].

**(f) Building blocks: encoders, decoders, and adaptation.** Our vision encoder is SigLIP 2 [37], a multilingual sigmoid-loss encoder available at four scales (ViT-B 86M, L 303M, So400m 400M, g 1B) whose NaFlex variant—combining FlexiViT's variable sequence length [38] and NaViT's native-aspect-ratio packing [39]—supports the resolution flexibility OCR demands and yields markedly better document-VQA transfer than its predecessor [37]. Our decoder is Aya-Expanse-8B [40], a multilingual 8B model from the Aya initiative [41] built on the Command family with data-arbitrage and multilingual preference training, covering 23 languages directly and drawing on the 101-language Aya effort [41]; mT5 [42] is an earlier massively multilingual baseline. For parameter-efficient adaptation we use LoRA [43] and mixture-of-LoRA routing [44]; for distillation-style alignment we draw on contrastive representation learning [23], [24] and self-distillation [37]. Inference and serving rely on SGLang [26], vLLM with paged attention [27], and FlashAttention [45]. Evaluation methodology for document parsing draws on OmniDocBench [46] and olmOCR-Bench [17], and edit-distance and structural metrics standard in the field [4], [7].

This survey establishes both the lineage of our architecture and the precise respect in which prior work leaves our question open: no existing open system isolates the *encoder-only* knowledge gap for unseen scripts while holding decoder language competence fixed, nor measures low-resource performance under that assumption. The remainder of this chapter formalizes that gap.

### Further background: evaluation, multilinguality, and reinforcement learning

Three further bodies of work inform the design and are worth drawing out, because each supplies a tool or a caution used in later chapters.

**Evaluation of OCR and document parsing.** How OCR is *measured* has shaped how it is built. Character and word error rates, derived from edit distance [4], remain the lingua franca for line-level recognition, but they are known to mislead on structured documents: a system that reads every character correctly yet linearizes a two-column page in the wrong order scores well on a bag-of-characters metric while being useless downstream. This tension motivated structured benchmarks—OCRBench for multimodal models [56], OmniDocBench for diverse PDF parsing [46], and the unit-test philosophy of olmOCR-Bench, which scores discrete, human-meaningful properties (does this header get excluded? is this table cell in the right place? does this equation render the same?) rather than a single distance [16], [17]. For low-resource scripts the inadequacy of edit distance is sharper still, because a one-character edit can be a catastrophic semantic error (a wrong diacritic) or a harmless encoding difference (an NFC-equivalent string); this is the central reason §5.2 reports unit-test pass rates alongside character metrics, and the reason §4.2 makes diacritic and normalization correctness *verifiable* rather than distance-based. Layout-aware pre-training such as LayoutLM [57] established that text and spatial position are jointly informative, a principle document anchoring operationalizes at inference time [15].

**Multilingual and low-resource NLP.** The uneven distribution of language resources is a long-studied problem [1], [2]: a handful of languages dominate pre-training corpora, and the rest—often with hundreds of millions of speakers—are served, if at all, by transfer from high-resource neighbours. Massively multilingual models such as mT5 [42] showed that a single model could share representations across a hundred languages, and the Aya line argued for *multilingual-by-design* training rather than English-first models with multilingual capabilities bolted on afterward [40], [41]. Our decoder choice rests on exactly this distinction: Aya-Expanse-8B is built to model its target languages well, which is what makes assumption A1 credible [40]. The OCR literature for specific low-resource scripts—Indic [32], Arabic [33], Amharic/Ge'ez [34], Khmer [35], and historical manuscripts [36]—repeatedly identifies the same bottleneck we formalize in §1.3: the scarcity is of *labelled images in the script*, not of language knowledge, since these languages have text corpora even when they lack annotated page images. This is the empirical observation that the synthetic-rendering pipeline of §3.1 is designed to exploit.

**Reinforcement learning for sequence generation.** The reward-based fine-tuning of Chapter 4 sits in a lineage running from policy-gradient methods and PPO [51] through reinforcement learning from human feedback for instruction following [50] to *verifiable* rewards, where the reward is computed by a program rather than a learned preference model [30]. GRPO [28] removed the need for a separate value network by normalizing rewards within a sampled group, which is both cheaper and well-matched to settings where many candidate outputs can be scored cheaply—exactly the OCR-with-unit-tests setting olmOCR 2 exploited [16]. Direct preference optimization [60] offered an alternative alignment route, but verifiable rewards are preferable for OCR precisely because correctness is decidable (§4.6). Our contribution in this lineage is narrow and concrete: we observe that script-level correctness—diacritic placement, Unicode normalization, faithfulness—is *also* program-checkable, and we add those checks to the reward (§4.2). Nothing in the optimizer changes; only what the reward can *see* changes.

**Structure of the dissertation.** The remainder proceeds as the research questions of §1.5 dictate. Chapter 2 fixes the architecture and presents the resolution policy and routed connector (RQ1). Chapter 3 builds the data and the encoder warm-up (RQ2). Chapter 4 presents the training curriculum and script-aware RLVR (RQ3). Chapter 5 constructs the system, defines the low-resource benchmark, and reports the comparative evaluation (RQ4, RQ5). Each chapter's two improvements are tied, by Table 1.1, to the error term they reduce, and each is described in enough detail to be re-implemented while being careful not to overstate its effect.

## 1.3 First contribution — the asymmetric-capability formulation of low-resource OCR

Our first contribution is conceptual and framing, and we state it deliberately narrowly so as not to overclaim. We formalize end-to-end OCR as a composition of three learned maps and identify which of them carries the burden under our resource assumption.

Let a document page be an image $I \in \mathbb{R}^{H\times W\times 3}$ whose ground-truth linearization is a token sequence $y = (y_1,\dots,y_T)$ in the decoder's vocabulary $\mathcal{V}$. An end-to-end VLM-OCR model factorizes as

$$
p_\theta(y \mid I, a) \;=\; \prod_{t=1}^{T} p_{\theta}\!\left(y_t \;\middle|\; y_{<t},\; c\big(f_v(I)\big),\; a\right),
$$

where $f_v(\cdot)$ is the **vision encoder** producing visual tokens, $c(\cdot)$ is the **connector** mapping visual tokens into the decoder's embedding space, the decoder $p_\theta$ is the **language model**, and $a$ denotes the **document-anchoring** side information (extracted text and element coordinates) injected into the prompt [15]. Training maximizes $\mathbb{E}_{(I,y)}\big[\log p_\theta(y\mid I,a)\big]$ over some data distribution, optionally followed by a reward-based phase (Chapter 4).

The standard multilingual-OCR program improves $p_\theta(y\mid I,a)$ by jointly training $f_v$, $c$, and the decoder on broad multilingual data. Our resource assumption changes the calculus. We assume:

- **A1 (decoder competence).** The decoder already models the target-language string distribution well: for the languages of interest, $p_\theta(y)$ is close to the true language distribution, because the 8B decoder was pre-trained on them [40], [41].
- **A2 (encoder blindness).** The encoder $f_v$ has been trained only on English/Latin document images; for a target-script image $I$, the features $f_v(I)$ are *out of distribution*—the encoder has never had to make the fine glyph-level distinctions the script requires.
- **A3 (connector mismatch).** Because $c$ was fit against $f_v$ on Latin data, the composed map $c\circ f_v$ sends target-script glyph features to the wrong region of the decoder's embedding space.

Under A1–A3, decompose the negative log-likelihood of the *correct* transcription into a chain of conditional informativeness terms. Writing $v = f_v(I)$ and $z = c(v)$, and using the data-processing structure of the model, the achievable transcription error is lower-bounded by the information that *survives* each map:

$$
\underbrace{I(I; y)}_{\text{recoverable from page}} \;\ge\; \underbrace{I(v; y)}_{\text{survives encoder}} \;\ge\; \underbrace{I(z; y)}_{\text{survives connector}} ,
$$

so that even a perfect decoder cannot recover transcription detail that the encoder has already discarded ($I(v;y)$ small) or that the connector has scrambled ($I(z;y)\ll I(v;y)$). This is the formal sense in which, *under A1–A3, the binding constraint is vision-side*: improving $p_\theta$ (which A1 says is already good) cannot raise accuracy past the ceiling set by $I(z;y)$.

The practical reading of this formulation, which guides every later design choice, is a three-part claim, stated modestly:

1. **Target the encoder and connector, not the decoder.** Adaptation budget should be spent on giving the encoder visual exposure to the target scripts (Chapter 3) and on a connector that can re-route unfamiliar glyph features into the decoder's already-correct language space (Chapter 2), rather than on further language tuning of the decoder.
2. **Cheap synthetic visual exposure should go a long way.** Because the missing quantity is visual ($I(v;y)$), and because the *text* of synthetic pages is controllable, rendered synthetic documents in the target scripts—free to produce at scale—should recover much of the lost information without any native annotated data (Chapter 3).
3. **The decoder's language prior is a double-edged asset.** A1 implies the decoder will confidently *fill in* plausible target-language text. When the encoder signal is weak this manifests as fluent hallucination—an error mode we name and attack directly in §1.4 and Chapter 4.

We emphasize what this contribution is *not*: it is not a new information-theoretic bound (the data-processing inequality is standard), nor a claim that the decoder never matters. It is a reframing that converts a vague intuition—"the vision side is the problem"—into a checkable hypothesis and a budget-allocation rule, and it is the organizing principle of the dissertation.

![**Figure 1.1.** The asymmetric capability gap. The encoder knows Latin glyph statistics but not target scripts; the multilingual decoder knows the languages but lacks a reliable bridge from unfamiliar glyph features. Under assumptions A1–A3 the bottleneck for low-resource OCR is vision-side script coverage.](figs/fig1_1_gap.png){width=85%}

## 1.4 Second contribution — an error-source decomposition for low-resource OCR

Our second contribution is a diagnostic decomposition that operationalizes the formulation of §1.3 into measurable error categories, so that later improvements can be attributed to the category they address. We partition transcription errors into three sources and give each an estimable proxy.

Let $\hat{y}=\arg\max_y p_\theta(y\mid I,a)$ be the model output and let $d(\hat y, y)$ be a normalized character-level edit distance. We write the expected error as a sum of three non-negative terms,

$$
\mathbb{E}\big[d(\hat y, y)\big] \;=\; \underbrace{E_{\text{vis}}}_{\text{visual}} \;+\; \underbrace{E_{\text{align}}}_{\text{alignment}} \;+\; \underbrace{E_{\text{lang}}}_{\text{linguistic}},
$$

defined and diagnosed as follows.

**Visual error $E_{\text{vis}}$** arises when the encoder fails to make a glyph-level distinction the script requires: confusable characters, unseen conjuncts and ligatures, stacked diacritics, or unfamiliar numeral forms. Its signature is *substitution within visually similar glyph clusters* and a strong dependence on rendering resolution. We estimate it by measuring error on synthetic pages whose ground truth is known, holding language context constant, and by its sensitivity to encoder resolution (a quantity we manipulate directly in §2.2). Under A2, this term dominates for unseen scripts.

**Alignment error $E_{\text{align}}$** arises when the connector maps a *correctly perceived* glyph feature to the wrong token region—the formal $I(z;y)\ll I(v;y)$ case. Its signature is *systematic, script-correlated mis-mappings* that persist even at high resolution and that improve when the connector is adapted while the encoder is frozen. We estimate it by the gap between probing accuracy (a linear read-out trained on $v$) and end-to-end accuracy (which uses $z$): a large gap implicates the connector, not the encoder. This term motivates the script-conditioned connector of §2.3.

**Linguistic error $E_{\text{lang}}$** arises when the decoder overrides weak visual evidence with its language prior, producing fluent but unfaithful text—completing a clipped word, "correcting" a rare spelling, or, at the extreme, hallucinating content for a near-empty region. Under A1 this term is *small for in-distribution text but dangerous precisely where the visual signal is weakest*, because a confident prior fills the vacuum. Its signature is high-fluency output with low image-faithfulness; we estimate it by faithfulness-sensitive checks (does each emitted line correspond to image content?) and by the document-anchoring ablation, since anchoring exists specifically to suppress it [15]. This term motivates the faithfulness-oriented unit tests and repetition penalties of Chapter 4.

The decomposition yields a simple methodological discipline used throughout: *each proposed improvement is paired with the error term it is meant to reduce, and is evaluated by whether that term falls.* Script-adaptive resolution (§2.2) and synthetic exposure (§3.1) target $E_{\text{vis}}$; the routed connector (§2.3) and encoder warm-up (§3.2) target $E_{\text{align}}$; the SFT curriculum (§4.1) and script-aware RLVR (§4.2) target $E_{\text{lang}}$ and residual $E_{\text{vis}}$. Table 1.1 summarizes this mapping, which doubles as a roadmap for the dissertation.

![**Figure 1.2.** Error-source decomposition for low-resource OCR. Total error splits into visual, alignment, and linguistic components; the low-resource regime is dominated by the first two, which our improvements primarily target.](figs/fig1_2_errors.png){width=82%}

Table 1.1 — Mapping of proposed improvements to error sources and chapters.

| Improvement | Primary error target | Chapter |
|---|---|---|
| Script-adaptive NaFlex resolution allocation | $E_{\text{vis}}$ | 2 |
| Script-conditioned LoRA-routed connector | $E_{\text{align}}$ | 2 |
| Anchor-conditioned synthetic script rendering | $E_{\text{vis}}$ | 3 |
| Cross-lingual encoder warm-up (alignment distillation) | $E_{\text{align}}$ | 3 |
| Progressive SFT curriculum | $E_{\text{lang}}$, $E_{\text{vis}}$ | 4 |
| Script-aware RLVR (diacritic/normalization tests) | $E_{\text{lang}}$, $E_{\text{vis}}$ | 4 |
| Confidence-gated re-rendering (serving) | $E_{\text{vis}}$ | 5 |
| LR-OCR-Bench (evaluation) | measurement of all three | 5 |

## 1.5 Problem statement, scope, and research questions

We now state the problem precisely. **Given** (i) a publicly available multilingual vision encoder trained on English/Latin document images, (ii) a publicly available multilingual decoder at the 8B scale that already understands a set of target low-resource languages $\mathcal{L}=\{\ell_1,\dots,\ell_m\}$ written in scripts $\mathcal{S}=\{s_1,\dots,s_k\}$, and (iii) the olmOCR development methodology and open assets, **construct** an end-to-end VLM that linearizes page images in both English and the languages of $\mathcal{L}$ into faithful, structured text, **maximizing** faithfulness on $\mathcal{S}$ **subject to** using *no* native human-annotated OCR data for the low-resource scripts (only synthetic and naturally occurring unlabelled documents) and a fixed compute budget comparable to a single 8×H100 node-week.

Scope and non-goals. We restrict attention to *printed* and *born-digital* documents and clean scans; handwriting and severely degraded manuscripts are out of scope except as a discussed extension (§5.6). We treat layout linearization (reading order, tables, equations) as in scope because it interacts with script, but full document-layout-analysis as a separate deliverable is not our target. We assume the decoder's tokenizer already covers the target scripts; languages whose scripts are absent from the tokenizer are out of scope.

The dissertation is structured around five research questions, each answered in a later chapter and each tied to the error decomposition of §1.4:

- **RQ1 (architecture).** Given an English-only encoder and a multilingual decoder, what encoder, connector, and resolution policy minimize $E_{\text{vis}}+E_{\text{align}}$ at fixed parameter budget? *(Chapter 2.)*
- **RQ2 (data).** Can synthetic, rendered documents in unseen scripts—labelled for free by construction—substitute for native annotated data in reducing $E_{\text{vis}}$, and how should the encoder be warmed up to reduce $E_{\text{align}}$ before joint training? *(Chapter 3.)*
- **RQ3 (optimization).** What supervised curriculum and what verifiable-reward design most reduce $E_{\text{lang}}$ (hallucination) and residual $E_{\text{vis}}$ on the target scripts? *(Chapter 4.)*
- **RQ4 (system).** How should the model be served so that hard pages are detected and re-processed, and how does the full system compare, quantitatively, against prior classical and neural OCR methods on both English and low-resource benchmarks? *(Chapter 5.)*
- **RQ5 (measurement).** Existing benchmarks are English-centric; what benchmark design fairly measures low-resource OCR faithfulness, and what does it reveal about the proposed system relative to baselines? *(Chapter 5.)*

The thread tying these together is the asymmetric-capability hypothesis of §1.3: we expect the cheap, vision-targeted interventions (synthetic exposure, resolution, a better bridge, verifiable faithfulness rewards) to deliver most of the low-resource gain, and we structure the experiments of Chapter 5 to test exactly that expectation against the strong multilingual baselines surveyed in §1.2.

## 1.6 A comparative view of OCR paradigms

To make the lineage of §1.2 precise and to motivate the architectural commitments of Chapter 2, Table 1.2 contrasts the major OCR paradigms along the axes that matter for low-resource adaptation: whether the system is end-to-end, how it handles layout and reading order, how it is adapted to a new script, and where—in the language of §1.3—each paradigm's information bottleneck sits.

Table 1.2 — OCR paradigms and their adaptation cost to a new low-resource script.

| Paradigm | Example | End-to-end? | Reading order | New-script adaptation | Dominant bottleneck |
|---|---|---|---|---|---|
| Classical pipeline | Tesseract [3] | No | Heuristic layout analysis | Re-train per-stage; per-script LSTM + dictionaries | segmentation + per-script model |
| Line recognizer | CRNN/TrOCR [4],[5] | Per line | External detector | Re-train recognizer + detector | upstream detection |
| OCR-free doc model | Donut/Nougat [6],[7] | Yes | Learned | Re-train on script doc pairs | paired data scarcity |
| Unified OCR-2.0 | GOT-OCR2.0 [22] | Yes | Learned | Joint multilingual training | encoder + decoder jointly |
| English VLM-OCR | olmOCR/olmOCR 2 [15],[16] | Yes | Learned + anchoring | (not addressed) English-only data/reward | English-centric data |
| Multilingual VLM-OCR | dots.ocr / DeepSeek-OCR / PaddleOCR-VL [18],[19],[20] | Yes | Learned | Joint multilingual training (large) | broad joint training cost |
| **This work** | §§2–4 | Yes | Learned + anchoring | Synthetic vision exposure + routed bridge; **decoder fixed** | **encoder + connector only** |

The final row encapsulates the dissertation's wager. Every prior multilingual route pays for a new script by training across both modalities at once; the asymmetric-capability route of §1.3 pays only on the vision side, because A1 says the linguistic side is already paid for. Whether that wager holds is the empirical question of Chapter 5.

We expand two strands of §1.2 that bear most directly on the design. On **document anchoring**: the technique is best understood as a *prior-injection* mechanism. By serializing the born-digital text layer and element coordinates into the prompt, anchoring gives the decoder a faithful skeleton so that, when visual evidence is weak, the model leans on extracted text rather than on its language prior [15], [25]. This is doubly valuable in our setting: the very pages where the encoder is weakest (unseen scripts) are exactly where $E_{\text{lang}}$ is most dangerous (A1), so any mechanism that substitutes faithful evidence for prior-driven guessing is leverage against our hardest error. On **verifiable rewards**: the olmOCR 2 insight is that OCR correctness is *checkable*—a transcription either reproduces a known string, places a table cell correctly, or renders an equation that matches under KaTeX, or it does not [16], [17]. This checkability is what lets RL proceed without human preference labels, and it is precisely what we extend to scripts in §4.2, since diacritic placement and Unicode normalization are equally checkable.

## 1.7 Summary of contributions

For reference, Table 1.3 lists the ten improvements, two per chapter, each labelled with the error term it targets (§1.4) and a one-line statement of what is and is not claimed. The discipline of pairing every contribution with a measurable error term, and of explicitly bounding the claim, is maintained throughout the dissertation in keeping with the instruction to describe improvements in detail rather than to assert large gains.

Table 1.3 — The ten contributions at a glance.

| # | Contribution | Targets | Claim (bounded) |
|---|---|---|---|
| 1 | Asymmetric-capability formulation (§1.3) | framing | reframing + budget rule, not a new bound |
| 2 | Error-source decomposition (§1.4) | framing | a measurement discipline, not a new metric |
| 3 | Script-adaptive NaFlex allocation (§2.2) | $E_{\text{vis}}$ | a policy over NaFlex, not a new encoder |
| 4 | Script-conditioned LoRA-routed connector (§2.3) | $E_{\text{align}}$ | use of MoLE as the bridge, not a new router |
| 5 | Anchor-conditioned synthetic script rendering (§3.1) | $E_{\text{vis}}$ | scripts + shaping gate on olmOCR-2 pipeline |
| 6 | Cross-lingual encoder warm-up (§3.2) | $E_{\text{align}}$ | decoder embeddings as alignment teacher |
| 7 | Progressive SFT curriculum (§4.1) | $E_{\text{lang}}$,$E_{\text{vis}}$ | a specific freezing schedule, not curricula |
| 8 | Script-aware RLVR (§4.2) | $E_{\text{lang}}$,$E_{\text{vis}}$ | script-aware tests on olmOCR-2 RLVR |
| 9 | Confidence-gated re-rendering (§5.1) | $E_{\text{vis}}$ | a verifiable retry trigger on olmOCR serving |
| 10 | LR-OCR-Bench (§5.2) | measurement | a low-resource verifiable benchmark |

\newpage
# Chapter 2 — Model Structure Design

This chapter answers RQ1. We first fix the overall architecture and the public components we build on (§2.1), then present the two improvements of this chapter—script-adaptive NaFlex resolution allocation (§2.2, targeting $E_{\text{vis}}$) and a script-conditioned LoRA-routed connector (§2.3, targeting $E_{\text{align}}$)—before specifying the decoder interface and document-anchoring integration (§2.4) and the resulting parameter budget and rationale (§2.5).

## 2.1 Overall architecture and component selection

The model is a standard image+text-to-text VLM: a vision encoder turns a page image into a sequence of visual tokens; a connector projects those tokens into the decoder's embedding space; the decoder, prompted with document-anchoring side information, autoregressively emits the linearized transcription. Figure 2.1 shows the data flow. We deliberately keep the macro-architecture conventional—following the LLaVA-style projector template [10] rather than Flamingo-style cross-attention [8] or a Q-Former [9]—because the contributions of this dissertation are in *what flows through the connector and how it is trained*, not in a novel fusion mechanism. A conventional backbone also maximizes reproducibility against the olmOCR baseline [15], [16].

![**Figure 2.1.** Overall architecture. A SigLIP 2 NaFlex vision encoder feeds a script-routed connector that projects into the embedding space of an Aya-Expanse-8B decoder; document-anchoring text extracted with pypdf is supplied to the decoder prompt, and output is emitted as a structured YAML/Markdown linearization.](figs/fig2_1_arch.png){width=92%}

**Vision encoder.** We select **SigLIP 2** in its **NaFlex** variant at the **So400m (400M)** scale [37]. Three properties drive the choice. First, NaFlex supports variable sequence length while preserving native aspect ratio—built from FlexiViT [38] and NaViT [39]—which is exactly the degree of freedom OCR needs, since legibility of small or dense glyphs is resolution-bound; SigLIP 2's NaFlex variants were trained by sampling sequence lengths from $\{128,256,576,784,1024\}$ and yield large gains on document-VQA transfer relative to fixed-resolution SigLIP [37]. Second, although SigLIP 2 is multilingually *trained*, our resource assumption (A2) treats its document-image exposure as effectively English/Latin for the *fine glyph-discrimination* the target scripts require; we therefore must still supply that exposure (Chapter 3), and NaFlex's resolution flexibility is what makes cheap synthetic exposure effective. Third, at 400M it leaves headroom under our 8B-class budget for the decoder. We note the same encoder family underlies Aya-Vision [40], easing integration with our decoder.

**Decoder.** We select **Aya-Expanse-8B** [40], a decoder-only Transformer of roughly 8B parameters (32 layers, 32 attention heads, hidden size 6144, SwiGLU feed-forward of inner dimension 24576, grouped-query attention, rotary position embeddings, ~128k-token SentencePiece vocabulary) built on Cohere's Command family with the Aya multilingual recipe—data arbitrage, multilingual preference training, and model merging—covering 23 languages directly and grounded in the broader 101-language Aya effort [40], [41]. It satisfies assumption A1 for our target languages and provides the linguistic prior we intend to exploit (and to discipline against hallucination). Its grouped-query attention and FlashAttention compatibility [45] keep long-context document prompts affordable.

**Connector.** A two-layer GELU MLP projector is the base map $W_0$ from encoder feature dimension to decoder embedding dimension, following LLaVA practice [10]; §2.3 augments it with script-conditioned routing. The connector is the *only* fully-trained-from-scratch component; encoder and decoder are adapted parameter-efficiently (§2.5).

This selection instantiates the asymmetric setup of §1.3 with concrete public models: a resolution-flexible encoder whose script exposure we will supply, and a competent multilingual decoder whose language prior we will both use and restrain.

## 2.2 Improvement 1 — script-adaptive NaFlex sequence-length allocation

**Problem addressed ($E_{\text{vis}}$).** Reading-accuracy on dense or structurally complex scripts is resolution-limited: Devanagari and other Brahmic scripts stack consonant-vowel marks and form conjunct ligatures; Khmer packs sub- and super-scripts; CJK glyphs carry many strokes in a small box. A fixed visual sequence length either under-resolves these scripts (raising $E_{\text{vis}}$) or wastes tokens—and decoder context—on sparse Latin pages. olmOCR renders to a fixed longest-edge of 1288 px [16]; this is a sensible single operating point for English but is script-blind.

**Mechanism.** NaFlex already permits a *per-image* choice of target sequence length $L$ from a discrete menu, resizing the page so the patch grid realizes $L$ while preserving aspect ratio [37], [38], [39]. Our improvement is a cheap *policy* for choosing $L$ as a function of estimated glyph density and aspect ratio, computed before encoding from quantities the document-anchoring stage already extracts. Define for page $I$ a density estimate

$$
\rho(I) \;=\; \frac{\#\{\text{glyph boxes from anchor}\}}{\text{page area}} \quad\text{(scans: a fast stroke-density proxy)},
$$

and an aspect ratio $\mathrm{AR}(I)=\max(H,W)/\min(H,W)$. We then allocate

$$
L(I) \;=\; \mathrm{clip}\!\Big(L_{\min},\,L_{\max},\;\big\lceil \alpha\,\rho(I)\,\mathrm{AR}(I)\big\rceil_{\mathcal{M}}\Big),
$$

where $\lceil\cdot\rceil_{\mathcal{M}}$ snaps to the nearest admissible NaFlex length in the menu $\mathcal{M}=\{256,576,784,1024,\dots\}$, $\alpha$ is a single calibrated scalar, and $[L_{\min},L_{\max}]$ bounds cost. For scans lacking born-digital glyph boxes, $\rho$ is approximated by a connected-component or edge-density count on a thumbnail, computed in microseconds. A lightweight script hint (from anchor Unicode ranges, or a tiny classifier on a thumbnail) raises $\alpha$ for scripts known to be dense, so the policy is *script-adaptive* and not merely density-adaptive.

![**Figure 2.2.** Script-adaptive NaFlex allocation. The target visual sequence length $L$ is chosen per page from the NaFlex menu as a function of estimated glyph density $\rho$ and aspect ratio; sparse Latin pages receive short sequences, dense Brahmic or CJK pages receive long ones.](figs/fig2_2_naflex.png){width=82%}

**Why this is principled, not a heuristic knob.** Per the §1.3 formulation, the encoder discards information when patches are too coarse to separate glyph parts; raising $L$ raises $I(v;y)$ precisely on the pages where it is binding, while leaving cheap pages cheap. The policy spends the *visual token budget where $E_{\text{vis}}$ lives*. Because $L$ enters both encoder FLOPs and decoder context length, the clip bounds give a direct accuracy–cost dial, and the serving system of §5.1 reuses the same mechanism to *escalate* $L$ on pages that fail self-checks (confidence-gated re-rendering).

**What we claim and what we do not.** We claim a modest, targeted gain: on dense scripts a script-aware $L$ recovers legibility that a fixed 1288-px render loses, at lower average cost than simply maximizing $L$ everywhere. We do *not* claim a new encoder architecture—NaFlex provides the capability [37]; our contribution is the allocation policy and its coupling to anchor-derived density and to the serving loop. The expected effect is a reduction in the resolution-sensitive component of $E_{\text{vis}}$, measured in §5.5 by sweeping $L$ and by the per-script ablation of Figure 5.3.

## 2.3 Improvement 2 — a script-conditioned LoRA-routed connector

**Problem addressed ($E_{\text{align}}$).** Even when the encoder *perceives* a target-script glyph (high $I(v;y)$), the connector fit on Latin data may map that feature to the wrong region of the decoder's embedding space (low $I(z;y)$). A single shared projector must serve all scripts at once; for an unseen script it has no reason to place features correctly, and fully retraining one projector per script would fragment the model and forget Latin. We want a connector that *specializes per script family while sharing structure*, adapts with few parameters, and degrades gracefully on unseen scripts.

**Mechanism.** We keep the shared base projector $W_0$ and add a small bank of $K$ low-rank experts $\{(A_k,B_k)\}_{k=1}^{K}$, one per script *family* (e.g., Latin, Brahmic, Arabic-derived, Ge'ez, CJK), each a LoRA pair [43] of rank $r$. A lightweight router $g(\cdot)$—a softmax over a script signal $s$ derived from the anchor Unicode histogram and a tiny visual script classifier—produces nonnegative mixing weights $g_k(s)$ summing to one. The connector output for a visual token $h_v$ is

$$
z \;=\; W_0\,h_v \;+\; \sum_{k=1}^{K} g_k(s)\,B_k A_k\,h_v, \qquad \sum_{k=1}^{K} g_k(s)=1,\; g_k(s)\ge 0 .
$$

This is a mixture-of-LoRA over a frozen shared projector [43], [44]: the base path preserves the Latin mapping (no forgetting), while the routed low-rank residual supplies a script-specific correction. Routing on $s$ (rather than learning a fully input-dependent gate) keeps the mechanism interpretable and cheap, and—crucially for our setting—allows a *new* script to be served at inference by routing to the nearest family or to a uniform blend, giving graceful generalization rather than a hard failure.

![**Figure 2.3.** Script-conditioned LoRA-routed connector. A shared projector $W_0$ preserves the Latin mapping; per-family LoRA experts, mixed by a script router $g(s)$ derived from anchor Unicode statistics and a small visual classifier, supply low-rank script-specific corrections.](figs/fig2_3_connector.png){width=88%}

**Training and regularization.** Only $\{A_k,B_k\}$ and the router are trained in the connector during the multilingual stages (Chapter 4); $W_0$ is frozen after English SFT to protect Latin alignment. We add a load-balancing term encouraging the router to use the correct family for labelled-script pages,

$$
\mathcal{L}_{\text{route}} \;=\; \mathrm{CE}\big(g(s),\,k^\star\big) \;+\; \beta\,\Big\|\,\overline{g}-\tfrac{1}{K}\mathbf{1}\,\Big\|_2^2,
$$

where $k^\star$ is the known family of a (synthetic) page and $\overline{g}$ is the batch-mean routing distribution; the first term supervises routing where the script is known, the second discourages collapse so unseen scripts can blend experts. Parameter cost is negligible: with $K=5$, rank $r=16$, and projector width $\sim$4k, the experts add on the order of $10^6$ parameters—far below 0.1% of the decoder.

**Why this is principled, not a heuristic knob.** The decomposition of §1.4 identifies $E_{\text{align}}$ by a gap between linear-probe accuracy on $v$ and end-to-end accuracy on $z$; the routed residual is the minimal capacity needed to close that gap *per script* without disturbing the shared map that already works for Latin. It directly raises $I(z;y)$ on target scripts while leaving the Latin path untouched. We deliberately avoid a heavier connector (full per-script projectors, or a Q-Former) because §1.3 implies the connector's job is re-routing, not re-encoding, and because the warm-up of §3.2 gives these experts a good initialization.

**What we claim and what we do not.** We claim that a small routed-LoRA residual on a frozen shared projector reduces script-correlated alignment error at trivial parameter cost and without Latin forgetting, and generalizes gracefully to held-out scripts via expert blending. We do not claim a novel routing algorithm; mixture-of-LoRA and load balancing are established [43], [44]. The contribution is their *use as the vision-to-language bridge under the asymmetric assumption*, conditioned on a script signal the anchoring stage already provides.

## 2.4 Decoder interface and document-anchoring integration

The decoder consumes three things in sequence: a system/instruction prompt specifying the output format; the document-anchoring text; and the projected visual tokens $z$. Following olmOCR, document anchoring extracts, from born-digital PDFs via pypdf, the page's text blocks and the coordinates of salient elements, samples them up to a character budget (prioritizing page start and end), and serializes them into the prompt alongside the rasterized image [15], [25]. Anchoring exists to suppress the linguistic error $E_{\text{lang}}$ of §1.4: by giving the decoder a faithful textual skeleton, it discourages the model from inventing content or completing clipped lines from its prior [15]. For scans with no recoverable text layer, anchoring degrades to image-only, and the burden shifts entirely to $f_v$ and the connector—precisely the regime our other improvements strengthen.

**Output format.** We adopt olmOCR 2's move from JSON to a YAML-style structured output, which reduced parsing failures and decoding loops in their experience [16]. Front-matter metadata (language, rotation, table/figure presence) precedes the linearized body; tables are emitted as HTML and equations as LaTeX, matching the conventions the verifiable rewards of §4.2 will test [16], [17]. For low-resource scripts we additionally fix a Unicode normalization form (NFC) in the instruction so that visually identical strings have a single canonical encoding—a requirement the script-aware unit tests of §4.2 depend on.

**Anchoring and script.** Anchoring text is itself in the target script when the PDF has a text layer, which both helps the router of §2.3 (the Unicode histogram is a strong script signal) and risks leaking erroneous embedded text into the output. We therefore treat anchor text as *evidence, not target*: the instruction directs the model to transcribe the image and use anchoring only to resolve order and ambiguous glyphs, an emphasis we reinforce with faithfulness rewards in §4.2.

### Why routing preserves decoder semantics

A subtle concern with inserting any new mapping between encoder and decoder is that it might place visual tokens in regions of the decoder's embedding space that the decoder interprets unpredictably, undermining assumption A1. The design of §2.3 guards against this in two ways worth making explicit. First, the *base* path $W_0 h_v$ is the projector learned during English SFT and then frozen; it already lands visual tokens in a region the decoder reads sensibly, so the routed residual $\sum_k g_k(s) B_k A_k h_v$ is a *correction* to a working map, not a fresh map. Because LoRA residuals are low-rank and initialized small [43], early in multilingual training the connector output is close to the frozen English map and drifts only as far as the data requires, a built-in conservatism. Second, the warm-up of §3.2 trains exactly this composed map to land glyph features near the decoder's own text embedding of the correct string; since that embedding is by construction a location the decoder reads as the intended text (A1), the warm-up actively steers $z$ toward decoder-meaningful regions before SFT begins. The two mechanisms together mean the routed connector adjusts *where in an already-meaningful space* a target-script glyph lands, rather than risking placement in uncharted regions—which is the precise sense in which the bridge re-routes rather than re-encodes (§2.8).

## 2.5 Parameter budget, trainable surface, and design rationale

Table 2.1 summarizes the parameter budget and which parts are trained in which phase. The design keeps the trainable surface small and vision-targeted, in line with §1.3: the decoder is touched only by a low-rank adapter to let it accept the new visual-token distribution, never to re-teach it language.

Table 2.1 — Components, scale, and trainable surface by phase. "LoRA" denotes parameter-efficient adapters; "frozen" denotes no gradient.

| Component | Scale | Warm-up (§3.2) | English SFT (§4.1) | Multiling. SFT (§4.1) | RLVR (§4.2) |
|---|---|---|---|---|---|
| Vision encoder (SigLIP2-NaFlex So400m) | 400M | trainable | LoRA | LoRA | frozen |
| Shared projector $W_0$ | ~17M | trainable | trainable | frozen | frozen |
| Routed LoRA experts + router | ~1–2M | init | — | trainable | trainable |
| Decoder (Aya-Expanse-8B) | 8B | frozen | LoRA | LoRA | LoRA |

The rationale, point by point: (i) the encoder is fully trainable only during the cheap warm-up on synthetic crops (§3.2), then constrained to LoRA so its Latin competence is not lost, then frozen for RL so the reward shapes only the bridge and decoder; (ii) the shared projector is fixed after English SFT to anchor the Latin mapping; (iii) the routed experts carry all script-specific bridging and are the main trainable surface in the multilingual phases; (iv) the decoder is never fully fine-tuned—only a LoRA adapter lets it accept visual tokens—so A1 is preserved by construction and we cannot accidentally degrade the language competence we are relying on. This budget fits comfortably on a single 8×H100 node, matching olmOCR's reported training scale [15], and concentrates learning where §1.3 says the information bottleneck is.

## 2.6 Encoder and decoder candidates considered

The selections of §2.1 were made against explicit alternatives. Table 2.2 records the encoder candidates and Table 2.3 the decoder candidates, with the property that decided each choice. The criteria follow §1.3: for the encoder, resolution flexibility (to make cheap synthetic exposure effective) and dense-feature quality (so glyph parts are separable); for the decoder, genuine competence in the target low-resource languages (A1) and a tokenizer that already covers the scripts.

Table 2.2 — Vision encoder candidates.

| Candidate | Scale | Resolution handling | Decisive property |
|---|---|---|---|
| CLIP ViT-L [23] | 0.3B | fixed, square | no native variable resolution; weak dense features |
| SigLIP (v1) [24] | 0.4B | fixed | strong but fixed-resolution; superseded |
| Qwen2.5-VL ViT [13] | ~0.6B | native dynamic | excellent for OCR; tightly coupled to Qwen decoder |
| NaViT-style (PaddleOCR-VL) [20],[39] | — | native aspect ratio | strong, but less openly reusable as a module |
| **SigLIP 2 NaFlex So400m [37]** | 0.4B | **NaFlex variable + native AR** | **chosen:** menu of sequence lengths, strong doc-VQA transfer, open |

Table 2.3 — Decoder candidates (8B class).

| Candidate | Multilingual design | Low-resource coverage | Decisive property |
|---|---|---|---|
| Llama-3.1-8B | English-centric + some multiling. | limited | weaker on target low-resource langs |
| Qwen2.5-7B | broad | good for many langs | strong, but we want explicit low-resource design |
| Gemma 2 9B [64] | broad | moderate | strong general model |
| **Aya-Expanse-8B [40]** | **multilingual-by-design (Aya recipe)** | **explicit 23-lang + Aya-101 lineage** | **chosen:** satisfies A1 by construction |

## 2.7 NaFlex patchification and visual-token budget

We make the resolution mechanism of §2.2 precise, since it governs both accuracy and cost. NaFlex resizes a page of size $H\times W$ so that both dimensions become multiples of the patch size $p$ while preserving aspect ratio as closely as possible, producing a non-square patch grid of $G_h\times G_w$ patches with $G_h G_w \le L$, the chosen target sequence length [37], [38], [39]. The learned positional embedding is bilinearly resized (with anti-aliasing) to the $G_h\times G_w$ grid, and attention masks ignore padding when $G_hG_w<L$ [37]. The number of visual tokens entering the decoder after the connector is therefore

$$
n_{\text{vis}} \;=\; G_h\,G_w \;\le\; L, \qquad
G_h \approx \Big\lceil \tfrac{1}{p}\sqrt{L\,\tfrac{H}{W}}\Big\rceil,\;
G_w \approx \Big\lceil \tfrac{1}{p}\sqrt{L\,\tfrac{W}{H}}\Big\rceil .
$$

Two consequences drive design. First, decoder context grows linearly in $n_{\text{vis}}$, so the script-adaptive policy of §2.2 controls *decoder* cost as well as encoder cost—doubling $L$ on a dense page roughly doubles its visual-token footprint. Second, legibility of a glyph of height $h_{\text{glyph}}$ pixels requires roughly $h_{\text{glyph}}/p \gtrsim$ a small constant of patches per glyph; scripts whose distinguishing marks are small relative to the body height (stacked diacritics, sub-scripts) need a larger $L$ to keep those marks above one patch, which is exactly the regime the policy targets. Algorithm 2.1 states the policy compactly.

**Algorithm 2.1 — Script-adaptive resolution allocation (per page).**

```
Input: page image I; anchor metadata a (optional); NaFlex menu M; scalar alpha;
       bounds [Lmin, Lmax]; script-density gain table kappa[script]
1: if a has a born-digital text layer then
2:     rho <- (number of glyph boxes in a) / area(I)
3:     s   <- dominant script of a  (Unicode-range histogram)
4: else
5:     rho <- edge_or_component_density(thumbnail(I))
6:     s   <- tiny_visual_script_classifier(thumbnail(I))
7: end if
8: AR <- max(H,W) / min(H,W)
9: L_raw <- alpha * kappa[s] * rho * AR
10: L <- clip(Lmin, Lmax, snap_to_menu(L_raw, M))
11: return L, s          # s is also the router signal for the connector (§2.3)
```

The script signal $s$ produced here is reused by the connector router of §2.3 at no extra cost, so a single cheap pre-pass serves both resolution and routing.

## 2.8 Design alternatives considered and rejected

For completeness we record fusion-mechanism alternatives weighed against the LLaVA-style projector and explain the rejection in terms of §1.3. **Cross-attention fusion (Flamingo-style) [8]** interleaves trainable cross-attention into the decoder; it is powerful but modifies the decoder substantially, risking the language competence A1 grants us, and adds many trainable parameters where §1.3 says they are not needed. **A querying transformer (Q-Former, BLIP-2) [9]** compresses visual tokens through learned queries; for OCR this compression is risky because it can discard the fine spatial detail $E_{\text{vis}}$ depends on, and it re-encodes rather than re-routes, contradicting the §1.3 reading of the connector's job. **Full joint fine-tuning of encoder and decoder**, the route of the broad multilingual systems [18], [19], [20], is exactly what our resource assumption lets us avoid; it is the most expensive option and the one most likely to forget Latin or to overwrite decoder language knowledge. The chosen projector-plus-routed-LoRA design is the minimal mechanism consistent with the asymmetric-capability budget: it re-routes visual features into a fixed, competent decoder, with script-specific capacity confined to a low-rank residual.

\newpage
# Chapter 3 — Training Data Construction, Encoder Warm-up, and Pre-training

This chapter answers RQ2 and exercises the "own choice" option for the third chapter: we choose to build the data-construction pipeline *and* an encoder-adapter-style warm-up, because the asymmetric assumption of §1.3 makes both the natural levers. The two improvements are an anchor-conditioned synthetic script-rendering pipeline (§3.1, targeting $E_{\text{vis}}$) and a cross-lingual encoder warm-up via glyph–text alignment distillation (§3.2, targeting $E_{\text{align}}$). Sections 3.3 and 3.4 specify the data mixture with unit-test generation, and the pre-training configuration.

## 3.1 Improvement 1 — anchor-conditioned synthetic script rendering

**Problem addressed ($E_{\text{vis}}$), and the constraint.** Under §1.5 we forbid native human-annotated OCR data for the low-resource scripts. Yet §1.3 says the missing quantity is *visual*: the encoder needs to see the target scripts rendered in realistic documents, with ground truth. The decisive observation—following olmOCR 2's synthetic pipeline [16], [17]—is that when we *render* a document we *know its text exactly*, so synthetic pages give perfect, free supervision. olmOCR 2 used this for English math, tables, and layouts; we extend it to *scripts*.

**Pipeline.** Figure 3.1 shows the four stages. (1) **Sample real layouts and content.** We crawl publicly available, openly licensed PDFs and public-domain scans (as olmOCR did, ~60% academic plus brochures, legal, slideshow, and diagram types [25]), plus monolingual text corpora in the target languages (e.g., Wikipedia, OSCAR-style web text, and openly licensed books) to supply *real* target-script strings. (2) **Render target-script HTML.** Following olmOCR 2, we use a capable teacher VLM/LLM to generate full HTML pages *seeded with sampled real content*—but our seeds are target-script paragraphs, tables, and headings, and we deliberately diversify fonts, weights, line spacing, column counts, and noise/skew to cover the visual variation a script exhibits in the wild [16], [17]. Because we control the HTML source, the transcription is exact and immune to teacher OCR errors—the property olmOCR 2 emphasizes [16]. (3) **Rasterize and extract anchors.** We render each HTML page to an image at several resolutions and run the same pypdf-style anchor extraction used at inference [15], so the model trains on the exact image+anchor format it will be served. (4) **Emit `(image, text, unit tests)` triples.** From the known HTML we auto-generate the verifiable unit tests of §4.2, including the script-specific tests (diacritic placement, NFC equivalence) that English-only pipelines lack.

![**Figure 3.1.** Anchor-conditioned synthetic script-rendering pipeline. Real target-script content seeds teacher-generated HTML with diversified typography; rendering yields images with exact ground truth and anchor metadata, from which script-aware unit tests are extracted (extending the olmOCR-synthmix recipe to non-Latin scripts).](figs/fig3_1_datapipe.png){width=92%}

**Synthetic realism and the sim-to-real gap.** Synthetic text is a known double-edged tool: too clean and the model never learns real-scan degradation; too uniform and it overfits a font. We mitigate with (i) a font bank per script vetted for correct shaping of conjuncts and diacritics—an easily overlooked failure where a font silently drops a combining mark, corrupting the "ground truth"; (ii) realistic degradations (JPEG artifacts, bleed-through, skew, blur, lighting) calibrated to a small *unlabelled* sample of real target-script scans; and (iii) a held-out slice of real, *unlabelled* target documents on which we evaluate only faithfulness-style proxies, never as training labels. The font-shaping check is itself a script-specific quality gate: we render each glyph cluster and verify, via the rendering engine's output, that the intended Unicode sequence is realized, discarding pages where it is not.

**Cost and scale.** olmOCR 2 produced 2,186 synthetic pages with 30,381 unit tests at about \$0.12 per page [16]. Our extension multiplies pages across scripts and typography but inherits the per-page economics; a few thousand pages per script family is affordable on the stated budget, and—per §1.3, point 2—this cheap visual exposure is exactly the lever expected to recover most of the lost $I(v;y)$.

**What we claim and what we do not.** We claim that synthetic rendered documents in unseen scripts, with exact and shaping-verified ground truth and script-aware tests, substitute effectively for native annotated data in reducing $E_{\text{vis}}$, and that the *anchor-conditioned* form (training on the served image+anchor format) avoids a train/serve mismatch. We do not claim the synthetic pipeline is novel in the abstract—it extends olmOCR 2 [16] and prior synthetic-document work [6], [7]; the contribution is its *adaptation to scripts*, the shaping-verification quality gate, and the script-aware test extraction. The expected effect is the dominant reduction in $E_{\text{vis}}$, isolated in the "+synthetic" bar of Figure 5.3.

## 3.2 Improvement 2 — cross-lingual encoder warm-up via glyph–text alignment distillation

**Problem addressed ($E_{\text{align}}$), and the idea.** Before any joint OCR training, the connector experts of §2.3 need a good initialization for unseen scripts, and the encoder needs its features nudged so that *visually distinct target glyphs become linearly separable in a space the decoder can read*. We exploit assumption A1 directly: the decoder *already* has good text embeddings for the target languages, so its text-embedding space is a ready-made teacher for "where a glyph should land." This is the "encoder adapter" path: a cheap, self-supervised warm-up that aligns the encoder's view of a rendered glyph string to the decoder's embedding of the *same* string.

**Objective.** Take synthetic crops $I$ (a word or short line from §3.1) with known text $y$. Let $f_v$ be the encoder (with the connector experts attached) producing a pooled visual representation $f_v(I)$, and let $e_t(y)$ be the *frozen* decoder's text embedding of $y$ (mean-pooled token embeddings, or a frozen text-encoder read-out). We minimize

$$
\mathcal{L}_{\text{warm}} \;=\; \mathcal{L}_{\text{InfoNCE}}\big(f_v(I),\,e_t(y)\big) \;+\; \lambda\,\big\| f_v(I) - \mathrm{sg}[\,e_t(y)\,] \big\|_2^2,
$$

where the InfoNCE term [23], [24] pulls matching glyph-image/text pairs together and pushes mismatched pairs apart within a batch, the second term distills the teacher embedding directly (with stop-gradient $\mathrm{sg}[\cdot]$ so only the encoder/connector move), and $\lambda$ trades off the two. Negatives are drawn to include *visually confusable* strings (differing by one diacritic or one conjunct), forcing the encoder to make exactly the fine distinctions $E_{\text{vis}}$ and $E_{\text{align}}$ care about.

![**Figure 3.2.** Cross-lingual encoder warm-up. Synthetic script crops are encoded and aligned to the frozen multilingual decoder's text embedding of the same string via a contrastive-plus-distillation loss; gradients update only the encoder and connector, initializing the bridge before joint training.](figs/fig3_2_warmup.png){width=82%}

**Why the decoder makes a good teacher here.** The data-processing view of §1.3 says we want $c\circ f_v$ to preserve the information $y$; aligning $f_v(I)$ to $e_t(y)$ is a direct, supervised-by-construction way to push $z=c(v)$ toward the region the decoder reads as $y$, *before* the expensive autoregressive SFT must discover the same mapping from scratch. Because $e_t$ is frozen and already correct for the target languages (A1), the warm-up cannot corrupt the decoder; it can only move the encoder toward it. This is the sense in which we "use the decoder to teach the encoder."

**What we claim and what we do not.** We claim a modest but useful effect: warm-up gives the routed connector experts and the encoder a script-aware initialization that reduces $E_{\text{align}}$ and shortens subsequent SFT, measured by the probe-vs-end-to-end gap of §1.4 and by faster SFT convergence. We do not claim a new contrastive objective—InfoNCE [23] and embedding distillation are standard, and SigLIP 2 itself uses self-distillation [37]; the contribution is *using the multilingual decoder's own text-embedding space as the alignment teacher for an English-only encoder on synthetic script crops*, which is well-posed precisely because of the asymmetric assumption. Warm-up is the "Stage 0" of the curriculum in §4.1 and the "+warm-up" component isolated in the ablation of §5.5.

## 3.3 Data mixture, quality control, and unit-test generation

Table 3.1 specifies the training mixture. The English portion reuses the olmOCR-mix composition to preserve the strong English behavior we inherit [15], [25]; the multilingual portion is the synthetic data of §3.1 plus *unlabelled* real target documents used only for degradation calibration and faithfulness probing. We hold every script's real data out of the labelled training set, honoring §1.5.

Table 3.1 — Training data mixture (schematic; per-script synthetic counts scale with the script inventory).

| Split | Source | Labels | Purpose | Error target |
|---|---|---|---|---|
| English documents | olmOCR-mix-style crawl + IA scans [25] | silver (anchored teacher) | preserve English competence | — |
| English synthetic | olmOCR-synthmix-style HTML [16] | exact | math/table/layout tests | $E_{\text{vis}}$ |
| Target-script synthetic | §3.1 rendered HTML | exact | script glyph exposure + tests | $E_{\text{vis}}$, $E_{\text{align}}$ |
| Glyph/word crops | §3.1 sub-crops | exact | encoder warm-up (§3.2) | $E_{\text{align}}$ |
| Real target scans | crawl (held-out) | none | degradation calibration, faithfulness probes | measurement |

**Quality control.** Three gates protect label fidelity: the font-shaping verification of §3.1 (the most script-specific gate); a render/round-trip check that the rasterized page's anchor text matches the HTML source; and Unicode NFC normalization of all targets so that equivalent encodings collapse. Language identification on anchor text (Lingua-style, as in olmOCR [25]) tags each page and feeds the router supervision label $k^\star$ of §2.3.

**Unit-test generation.** From each synthetic page's HTML we extract binary tests in the olmOCR 2 style [16], [17]: presence/absence of specific strings, exclusion of headers/footers, reading-order relations between blocks, table-cell correspondences, and KaTeX-render equivalence for equations. We *add* two script-aware test families: a **diacritic/combining-mark placement test**, which checks that each base character carries exactly the intended combining marks in canonical order; and an **NFC-equivalence test**, which passes iff the output, normalized, equals the normalized target. These are cheap to generate from known HTML and are exactly the verifiable signals the RL phase of §4.2 optimizes.

## 3.4 Pre-training configuration

We use a single 8×H100 (80 GB) node, matching olmOCR's reported scale [15]. The encoder warm-up (§3.2) runs first on glyph/word crops with the encoder and connector trainable and the decoder frozen, using AdamW, a cosine schedule, and InfoNCE batch sizes large enough to supply hard confusable negatives. The supervised stages (Chapter 4) then train on the page-level mixture of Table 3.1 with the trainable surface of Table 2.1. We mirror olmOCR's optimization defaults where sensible—AdamW, a low learning rate on the order of $10^{-6}$ for the large pretrained components, a cosine annealing schedule, and an effective batch size in the small single digits per step accumulated to a useful global batch [15]—and tune the warm-up and connector learning rates separately, since those parameters are fresh. Mixed precision (bf16) and FlashAttention [45] keep document-length contexts affordable. We checkpoint per stage to enable the ablations of §5.5, in which stages are removed to attribute gains to the §3.1 and §3.2 improvements. Full hyperparameters are deferred to §4.4, where they are reported together with the fine-tuning and RL settings for reproducibility.

## 3.5 The synthetic pipeline and warm-up in detail

We give the two algorithms underlying §3.1 and §3.2 explicitly, both because they are the chapter's contributions and because they are the components a re-implementer most needs.

**Algorithm 3.1 — Anchor-conditioned synthetic script rendering (per page).**

```
Input: target script s; font bank F[s] (shaping-verified); real text corpus C[s];
       layout-template generator T (teacher VLM/LLM); resolution menu M;
       degradation profile D[s] (calibrated to unlabelled real scans)
1: content <- sample paragraphs/tables/headings from C[s]
2: html    <- T(content, style := random(fonts in F[s], columns, spacing, weights))
3: assert shaping_ok(html, F[s])     # each Unicode cluster realized by the font
4: for L in chosen subset of M do
5:     img_L <- rasterize(html, target_seq_len := L)
6:     img_L <- apply_degradations(img_L, D[s])      # JPEG, skew, blur, bleed
7: end for
8: anchor <- extract_anchor(html)                    # pypdf-style text + coords
9: text   <- NFC(linearize(html))                    # exact ground truth
10: tests <- generate_unit_tests(html)               # incl. diacritic + NFC tests
11: return {(img_L, anchor, text, tests)} , family(s)   # family label k* for router
```

**Algorithm 3.2 — Cross-lingual encoder warm-up (one step).**

```
Input: batch of synthetic crops {(I_i, y_i)} with families {k*_i};
       encoder+connector f (trainable); frozen decoder text-embed e_t; weight lambda
1: v_i <- f(I_i)                          # pooled visual representation
2: t_i <- e_t(y_i)   (stop-grad)          # teacher text embedding (frozen decoder)
3: build negatives N_i incl. confusable strings (one diacritic / conjunct apart)
4: L_nce <- InfoNCE({v_i},{t_i}, negatives := N_i)
5: L_dist <- mean_i || v_i - t_i ||^2
6: L <- L_nce + lambda * L_dist
7: update f by AdamW on L                 # decoder never updated
```

The confusable-negative construction in step 3 of Algorithm 3.2 is the detail that makes warm-up bite: by forcing the encoder to separate strings that differ by a single mark, it directly trains the glyph-level distinctions that $E_{\text{vis}}$ and $E_{\text{align}}$ punish, rather than merely learning a coarse script embedding.

Table 3.2 gives an illustrative target inventory. Counts are planning figures at olmOCR 2's ~\$0.12/page economics [16]; they scale linearly with the script list and are bounded by the single-node budget of §1.5.

Table 3.2 — Illustrative synthetic data inventory (planning figures).

| Script family | Example languages | Synthetic pages | Word/line crops (warm-up) | Notable visual challenge |
|---|---|---|---|---|
| Latin (replay) | English, Vietnamese* | reuse olmOCR-mix [25] | — | diacritics (Vietnamese) |
| Brahmic | Hindi, Bengali, Tamil | ~6–10k / lang | ~200k / lang | conjuncts, stacked vowel signs |
| Ge'ez | Amharic, Tigrinya | ~6k / lang | ~150k / lang | large syllabary, fidel forms |
| Khmer | Khmer | ~6k | ~150k | sub-/super-scripts, no spaces |
| Tibetan | Tibetan, Dzongkha | ~6k | ~150k | stacked consonants |

(*Vietnamese uses Latin script but is diacritic-dense, a useful bridge case between Latin and the non-Latin families.)

## 3.6 Worked example: a Devanagari page

To make the pipeline concrete, consider a synthetic Devanagari news page. Real Hindi paragraphs are sampled from an openly licensed corpus and passed to the template generator, which lays them out in two columns with a headline and a small table of figures, choosing a Devanagari font from the shaping-verified bank. The shaping check (Algorithm 3.1, step 3) is essential here: many fonts render the conjunct "क्ष" (k-ṣa) or the "र" (ra) reph correctly only with proper OpenType features enabled, and a font that silently decomposes them would corrupt the ground truth. Rendering at $L\in\{576,784,1024\}$ produces three images; the policy of §2.2 would, at inference, pick the higher $L$ for this dense page. Anchor extraction yields the Devanagari text and block coordinates. Unit-test generation emits, besides the usual text-presence and reading-order tests, a diacritic-placement test asserting that each consonant carries its intended mātrā (vowel sign) in canonical order, and an NFC-equivalence test. During warm-up, confusable negatives for a word like "किताब" (kitāb) include strings differing only in the i-mātrā position—forcing the encoder to localize the vowel sign precisely. This single example exercises every script-specific element of Chapter 3; the same template instantiates for Bengali, Tamil, Amharic, Khmer, and Tibetan with their own font banks and cluster rules, catalogued in Appendix B.

## 3.7 The synthetic-to-real gap and anticipated failure modes

Honesty about a synthetic-data method requires naming where it can fail. The synthetic pages of §3.1 differ from real scans along axes the font bank and degradation profile only partly close. We anticipate four failure modes and the mitigation each receives. First, **typographic narrowness**: if the font bank under-samples the fonts a community actually uses, the encoder overfits to rendered shapes and stumbles on real print; mitigation is a deliberately broad, community-informed font bank and the held-out real-scan faithfulness probe of §3.1 that surfaces the gap before deployment. Second, **layout narrowness**: teacher-generated HTML may favour a few clean templates, under-representing the cramped, multi-column, marginalia-laden reality of historical gazettes; mitigation is seeding layout diversity from real sampled pages (Algorithm 3.1, step 1) rather than from templates alone. Third, **degradation mismatch**: synthetic noise calibrated to one corpus of scans may not transfer to another scanner or paper stock; mitigation is per-deployment recalibration of the degradation profile $D[s]$ against a small unlabelled sample, an inexpensive step because it needs no labels. Fourth, **shaping errors masquerading as ground truth**: a font that silently drops a combining mark would teach the model a wrong target; this is the single most dangerous failure for a script method, and it is why the shaping-verification gate (Algorithm 3.1, step 3) is treated as a hard precondition rather than a quality nicety. The per-script ablation of §5.5 is designed to expose residual gaps script by script, so that effort can be directed where the synthetic-to-real transfer is weakest rather than assumed uniform.

\newpage
# Chapter 4 — Fine-tuning and Reinforcement Learning

This chapter answers RQ3. It presents the two improvements that turn the warmed-up, assembled model into an accurate low-resource reader: a progressive supervised fine-tuning curriculum (§4.1, targeting $E_{\text{lang}}$ and residual $E_{\text{vis}}$) and script-aware reinforcement learning with verifiable rewards (§4.2, targeting $E_{\text{lang}}$ and residual $E_{\text{vis}}$). Sections 4.3 and 4.4 cover stabilization (model souping) and the full hyperparameter report.

## 4.1 Improvement 1 — a progressive supervised fine-tuning curriculum

**Problem addressed.** Two failure modes must be avoided simultaneously. If we begin multilingual SFT before the bridge is competent, the decoder—confident in the target language under A1—learns to *ignore the image* and emit fluent text from its prior, baking in $E_{\text{lang}}$. If we train the encoder too aggressively on synthetic scripts, it forgets Latin and inflates $E_{\text{vis}}$ on English. A curriculum that unfreezes capacity progressively, in the order the §1.3 budget prescribes, avoids both.

**Curriculum.** Figure 4.1 shows four stages, each changing only what Table 2.1 marks trainable. **Stage 0 — encoder warm-up** (§3.2): align the encoder/connector to the frozen decoder's text space on glyph crops; the decoder never moves. **Stage 1 — English document SFT**: fine-tune on anchored silver-labelled English pages (olmOCR-mix style [25]) with encoder LoRA, the shared projector $W_0$ trainable, and decoder LoRA, establishing strong English linearization and a *fixed, protected* Latin mapping; we then freeze $W_0$. **Stage 2 — multilingual SFT**: train on the target-script synthetic pages of §3.1 with the routed LoRA experts and router (§2.3) trainable, encoder LoRA trainable, decoder LoRA trainable, and $W_0$ frozen—so all *new* script knowledge flows into the routed residual and adapters while Latin is held. We interleave a fraction of English pages (a replay buffer) to prevent forgetting, and order scripts from typographically simpler to more complex. **Stage 3 — RLVR** (§4.2): freeze the encoder and optimize the bridge and decoder LoRA against verifiable rewards.

![**Figure 4.1.** Progressive SFT curriculum. Capacity is unfrozen in the order the asymmetric-capability budget prescribes—encoder warm-up, then English SFT (protecting the Latin projector), then multilingual SFT into the routed experts, then reinforcement learning.](figs/fig4_1_stages.png){width=92%}

**Faithfulness-first supervision.** Throughout Stages 1–2 the loss is the usual next-token cross-entropy on the linearized target, but we weight tokens that correspond to *image-grounded content* over boilerplate, and we keep document anchoring active so the decoder learns to *use* the textual skeleton rather than its prior [15]. This is the supervised half of the attack on $E_{\text{lang}}$; the reinforcement half follows.

**What we claim and what we do not.** We claim that the *order and freezing schedule*—warm-up, English-with-protected-projector, multilingual-into-routed-experts, then RL—reduces both Latin forgetting and image-ignoring relative to undifferentiated joint training, at no extra parameter cost. We do not claim curricula or progressive unfreezing as novel; the contribution is the *specific schedule derived from the §1.3 budget*, in particular freezing $W_0$ after English SFT and confining new-script learning to the routed residual. The expected effect is measured by the English-retention and low-resource-gain columns of §5.5.

## 4.2 Improvement 2 — script-aware reinforcement learning with verifiable rewards

**Problem addressed ($E_{\text{lang}}$, residual $E_{\text{vis}}$).** Cross-entropy SFT rewards matching the reference token-by-token, which both over-penalizes harmless formatting variation and under-penalizes the dangerous failure of fluent-but-unfaithful output. olmOCR 2 showed that *verifiable rewards*—binary unit tests run against the output—better capture semantic correctness for math, tables, and layout, and that GRPO on these rewards yields large gains [16], [17]. Our improvement extends this verifiable-reward machinery with *script-aware* tests so that the reward can see the errors that matter for low-resource scripts, which English unit tests cannot.

**Setup.** We follow the olmOCR 2 / RLVR recipe [16], [17], [30]: for each training page the policy $\pi_\theta$ samples a group of $G$ completions (olmOCR 2 used $G=28$ [16]); each completion is scored by running the page's unit tests; the page-level reward is the fraction of tests passed plus small binary rewards for correct end-of-sequence and metadata format [16], [17]. We optimize with Group Relative Policy Optimization (GRPO) [28], which normalizes rewards *within the group* to form advantages, avoiding a separate value network:

$$
\hat{A}_i \;=\; \frac{r_i - \mathrm{mean}(r_1,\dots,r_G)}{\mathrm{std}(r_1,\dots,r_G)}, \qquad
r_i \;=\; \frac{1}{N}\sum_{j=1}^{N}\mathbb{1}\big[t_j(\hat y_i)\ \text{passes}\big] \;+\; r_{\text{eos}} \;+\; r_{\text{fmt}},
$$

and the GRPO objective maximizes the clipped, advantage-weighted likelihood with a KL penalty to a reference policy,

$$
\mathcal{J}(\theta) \;=\; \mathbb{E}\!\left[\frac{1}{G}\sum_{i=1}^{G}\min\!\Big(\tfrac{\pi_\theta}{\pi_{\text{old}}}\hat{A}_i,\ \mathrm{clip}\big(\tfrac{\pi_\theta}{\pi_{\text{old}}},1-\epsilon,1+\epsilon\big)\hat{A}_i\Big)\right] \;-\; \gamma\,\mathrm{KL}\!\left[\pi_\theta\,\|\,\pi_{\text{ref}}\right],
$$

implemented with the Hugging Face TRL library, as in olmOCR 2 [16]. The encoder is frozen in this phase (Table 2.1) so the reward shapes only the bridge and decoder LoRA.

![**Figure 4.2.** Script-aware RLVR. The policy samples a group of completions; each is scored by a battery of unit tests—olmOCR 2's text/order/table/KaTeX tests plus our diacritic-placement and NFC-equivalence tests—and GRPO updates the policy using group-normalized advantages.](figs/fig4_2_rlvr.png){width=88%}

**The script-aware tests (the contribution).** To the olmOCR 2 test families [16], [17] we add three verifiable signals that make the reward sensitive to low-resource error modes:

1. **Diacritic/combining-mark placement test.** For scripts with stacked or attached marks (Brahmic, Ge'ez, Arabic-derived, Vietnamese), the test parses output into base+mark clusters and passes iff each base carries exactly the intended marks in canonical order. This directly rewards the fine distinctions $E_{\text{vis}}$ governs and that edit distance blurs.
2. **NFC-equivalence test.** Passes iff the NFC-normalized output equals the NFC-normalized ground truth, removing reward noise from encoding-equivalent strings—essential where multiple code-point sequences render identically.
3. **Faithfulness / anti-hallucination test.** A line-level check that each emitted line is supported by image content (via the known synthetic ground truth), with an explicit *repetition/looping penalty* on degenerate repeated n-grams—the failure olmOCR 2 mitigated with output-format changes and temperature control [16]. This is the verifiable attack on $E_{\text{lang}}$.

Because these tests are generated for free from the synthetic HTML of §3.1, RLVR can be run on the target scripts with no native labels, satisfying §1.5. The reward thus *sees* diacritic and hallucination errors that English-only RLVR is blind to.

**What we claim and what we do not.** We claim that adding diacritic-placement, NFC-equivalence, and faithfulness tests to the olmOCR 2 RLVR loop measurably reduces $E_{\text{lang}}$ and residual $E_{\text{vis}}$ on low-resource scripts, and that the verifiable framing is well-suited to scripts because correctness is checkable from rendered ground truth. We do *not* claim GRPO, RLVR, or unit-test rewards as our own—these are olmOCR 2's and the broader RLVR literature's [16], [17], [28], [30]; nor do we claim "excessive" gains. The contribution is the *script-aware test families* and their integration, and the effect is isolated in the "+RLVR" bar of Figure 5.3.

## 4.3 Model souping and stabilization

RL on verifiable rewards can be unstable across seeds. Following olmOCR 2, we train several policies (they used six, mixing token-level and sequence-level importance sampling) and average their weights—*model souping*—to obtain a single more robust model [16]. We adopt the same practice: a small number of GRPO runs differing only in seed and importance-sampling granularity, weight-averaged into the released checkpoint. We additionally monitor for reward hacking specific to our tests (e.g., emitting canonical NFC trivially while degrading content) and hold out a subset of test *types* from training to detect it, reporting on held-out test families in §5.5.

## 4.4 Training hyperparameters

Table 4.1 reports the configuration for reproducibility, mirroring olmOCR's published settings where we inherit them [15], [16] and noting where fresh components differ. Values for fresh components (warm-up, routed experts) are starting points to be finalized by the sweeps of §5.5.

Table 4.1 — Training configuration by stage. LR = learning rate; bf16 throughout; 8×H100 (80 GB).

| Stage | Trainable | Optimizer / schedule | LR | Notes |
|---|---|---|---|---|
| 0: warm-up (§3.2) | encoder + connector | AdamW / cosine | ~1e-4 (fresh) | InfoNCE + distill; hard confusable negatives |
| 1: English SFT (§4.1) | enc-LoRA, $W_0$, dec-LoRA | AdamW / cosine | ~1e-6 (pretrained) | anchored silver labels; ~1.2 epochs (cf. [15]) |
| 2: multilingual SFT | routed experts, enc-LoRA, dec-LoRA | AdamW / cosine | ~1e-6 / ~5e-5 (experts) | $W_0$ frozen; English replay; simple→complex scripts |
| 3: RLVR (§4.2) | experts, dec-LoRA | GRPO (TRL) / constant | ~1e-6 | $G=28$ completions; KL penalty $\gamma$; encoder frozen; one epoch (cf. [16]) |

Effective batch size is accumulated to a useful global batch as in olmOCR (which used an effective batch of 4 with LR 1e-6 over 10,000 steps, ~16 node-hours per run [15]); RL adds the cost of $G$ completions per page and the unit-test harness. We log per-error-source metrics ($E_{\text{vis}}$, $E_{\text{align}}$, $E_{\text{lang}}$ proxies from §1.4) at every stage boundary so that the ablations of §5.5 can attribute movement in each term to the responsible improvement.

## 4.5 The RLVR loop in detail and reward design

We state the script-aware RLVR procedure explicitly (Algorithm 4.1) and then define each reward term, since the reward design—not the optimizer—is this section's contribution.

**Algorithm 4.1 — Script-aware RLVR with GRPO (per training page).**

```
Input: policy pi_theta; reference pi_ref; page (I, a) with unit tests {t_1..t_N};
       group size G; clip eps; KL weight gamma
1: render I at L(I) via Alg. 2.1; freeze encoder
2: sample G completions  y^(1..G) ~ pi_theta( . | I, a)
3: for i in 1..G:
4:     pass_i  <- ( 1/N ) * sum_j  1[ t_j(y^(i)) passes ]     # incl. diacritic, NFC, faithfulness tests
5:     r_i     <- pass_i + r_eos(y^(i)) + r_fmt(y^(i))
6: A_hat_i <- ( r_i - mean(r) ) / std(r)                      # group-normalized advantage
7: update theta by GRPO objective J(theta) with clip eps and KL(pi_theta || pi_ref) weighted by gamma
8: return updated theta
```

The reward terms are defined as follows, with all tests generated for free from the synthetic HTML of §3.1 (so RL needs no native labels, per §1.5):

$$
r_{\text{pass}} = \frac{1}{N}\sum_{j=1}^{N}\mathbb{1}[t_j\ \text{passes}], \qquad
r_{\text{eos}} = \mathbb{1}[\text{completion ends with EOS}], \qquad
r_{\text{fmt}} = \mathbb{1}[\text{valid YAML/metadata}],
$$

following olmOCR 2's structure [16], [17]. The unit-test set $\{t_j\}$ comprises the olmOCR 2 families (text presence, header/footer exclusion, reading-order relations, table-cell correspondence, KaTeX equation equivalence) [16], [17] plus our three script-aware families from §4.2:

$$
t^{\text{dia}}: \ \text{each base char carries the intended marks in canonical order}; \quad
t^{\text{nfc}}: \ \mathrm{NFC}(\hat y)=\mathrm{NFC}(y); \quad
t^{\text{faith}}: \ \text{every output line is image-supported, no degenerate repetition}.
$$

The faithfulness test $t^{\text{faith}}$ carries an explicit penalty for repeated n-grams above a threshold, directly suppressing the looping failure mode olmOCR 2 mitigated via output-format and temperature changes [16]. Because GRPO normalizes rewards within the group of $G$ completions [28], the policy is pushed toward completions that pass *more* tests than their siblings on the *same* page, which is a low-variance signal well-suited to the heterogeneous difficulty of multilingual pages.

## 4.6 Why verifiable rewards suit low-resource scripts

It is worth stating plainly why the RLVR framing is more than a borrowed technique here. Three properties of scripts make verifiable rewards a natural fit. First, **correctness is decidable**: unlike open-ended generation, a transcription either matches a known rendered string under normalization or it does not, so a binary test is faithful to the objective—exactly olmOCR 2's argument [16], extended to the observation that diacritic placement and Unicode normalization are equally decidable. Second, **edit distance is misleading for scripts**: a single misplaced combining mark may be one character of edit distance yet a complete semantic failure, while a benign encoding difference may inflate edit distance without any real error; binary structural tests sidestep both, which is why we report unit-test pass rate alongside character metrics in §5.2. Third, **the reward is cheap and label-free for new scripts**: since the synthetic ground truth is known by construction (§3.1), the reward harness extends to any script we can render and shape-verify, with no human annotation—the property that lets the whole low-resource program fit the budget of §1.5. Together these explain why the largest *additional* gains in Figure 5.3 come from RLVR precisely on the diacritic-heavy scripts, where SFT's token-level loss is least aligned with what counts as correct.

## 4.7 Stability, failure modes, and mitigations of the RL phase

Reinforcement learning on verifiable rewards is powerful but not automatically stable, and a dissertation should say how it can go wrong. We anticipate three failure modes. **Reward hacking**: the policy may discover a degenerate output that passes tests cheaply—for instance, emitting trivially NFC-valid but contentless text to collect the normalization reward, or exploiting a test's narrowness. Mitigation follows olmOCR 2's discipline of a *diverse* test battery [16], [17] so that no single cheap behaviour passes many tests, plus the held-out test-family evaluation of §4.3 that detects hacking by measuring on tests the policy was never optimized against. **Entropy collapse and looping**: RL can drive the policy toward low-entropy repetition, the very looping failure olmOCR 2 mitigated through output-format and temperature choices [16]; our faithfulness test with an explicit repetition penalty (§4.2) makes this failure directly costly under the reward, and the KL penalty to the reference policy in the GRPO objective bounds drift from the SFT model. **Forgetting under reward pressure**: optimizing hard low-resource pages could degrade English; mitigation is freezing the encoder and the shared projector during RL (Table 2.1) so the reward can reshape only the routed bridge and the decoder LoRA, plus interleaving English pages in the RL stream as a replay buffer. Model souping across seeds [16] is the final stabilizer, averaging away seed-specific pathologies. None of these mitigations is novel in isolation; reporting them, and the held-out checks that would catch their failure, is part of describing the method honestly rather than claiming it is trouble-free.

\newpage
# Chapter 5 — System Construction, Implementation, Evaluation, and Experiments

This chapter answers RQ4 and RQ5. It presents the serving system and its confidence-gated re-rendering improvement (§5.1, targeting $E_{\text{vis}}$ at inference), the LR-OCR-Bench evaluation improvement (§5.2, the measurement instrument), the experimental setup (§5.3), the comparative results against prior OCR methods (§5.4), ablations (§5.5), and limitations and future work (§5.6). All reported numbers for the proposed system are clearly labelled as projected targets pending full training; published numbers for prior systems are cited as such.

## 5.1 Improvement 1 — serving pipeline with confidence-gated re-rendering

**Problem addressed ($E_{\text{vis}}$ at inference).** Even a well-trained model will misread a fraction of pages—precisely the dense, skewed, or low-quality ones where resolution is binding. A static single-pass pipeline cannot recover these. olmOCR's toolkit already renders, rotates, and *retries* pages on failure, batches hundreds of pages per worker, and runs on SGLang/vLLM at very low cost [16], [25], [26], [27]. We add a *verifiable* trigger for re-processing that reuses the §2.2 resolution mechanism and the §4.2 tests.

**Mechanism.** Figure 5.1 shows the loop. A page is ingested, rendered at the script-adaptive NaFlex length $L$ of §2.2 (longest edge ~1288 px as a default operating point, after olmOCR 2 [16]), and decoded by the model served under vLLM/SGLang [26], [27]. The output is then run through a *self-check*: a subset of the §4.2 unit tests that can be evaluated *without* ground truth (well-formedness of tables/equations, NFC validity, absence of degenerate repetition, internal reading-order consistency) plus a token-confidence aggregate. If the self-check score is below a threshold $\tau$, the page is *re-rendered* at the next-higher NaFlex length (and, if needed, rotated, as olmOCR does [25]) and re-decoded, up to a small retry cap. This is the inference-time analogue of §2.2: spend more visual tokens only on the pages that demonstrably need them.

![**Figure 5.1.** Serving pipeline. Pages are rendered at the script-adaptive resolution and decoded under vLLM/SGLang; a ground-truth-free self-check (well-formedness, NFC validity, anti-repetition, confidence) gates re-rendering at higher resolution for pages that fail, bounding cost while recovering hard pages.](figs/fig5_1_system.png){width=92%}

**Cost discipline.** Because re-rendering fires only on low-confidence pages, average cost stays close to single-pass while worst-case pages are rescued; the retry cap bounds tail latency. The pipeline preserves olmOCR's batch-processing economics—on the order of a million pages for a low-hundreds-of-dollars cost on commodity GPUs [25]—since the added work is a cheap test harness plus occasional re-decodes.

**What we claim and what we do not.** We claim a modest engineering gain: a verifiable, resolution-coupled retry recovers a fraction of hard pages at near-single-pass average cost, and reuses components already built (the §2.2 menu, the §4.2 tests). We do not claim the serving stack itself—batching, retries, rotation, and SGLang/vLLM serving are olmOCR's and the engines' [25], [26], [27]; the contribution is the *confidence-gated, resolution-escalating* trigger driven by ground-truth-free unit tests.

## 5.2 Improvement 2 — LR-OCR-Bench, a low-resource evaluation benchmark

**Problem addressed (measurement).** olmOCR-Bench is, by its authors' description, an *English-language* benchmark [16], [17], and OmniDocBench, while multilingual in parts, is not built around the low-resource scripts or the verifiable-test methodology we need [46]. To answer RQ5 we require an instrument that measures faithfulness on the target scripts in the same verifiable style we trained against, while remaining honest about the train/test boundary.

**Design.** LR-OCR-Bench mirrors olmOCR-Bench's unit-test philosophy [16], [17] but is constructed over *real, held-out* target-script documents (never used in training, per §1.5) with *human-verified* ground truth for a curated core, plus a larger synthetically-controlled tier. It scores systems with the same families used in §4.2—text presence, reading order, table-cell correspondence, equation equivalence—*augmented* with the diacritic-placement and NFC-equivalence tests, and reports both an aggregate score and per-script breakdowns. Critically, the human-verified core uses documents and *test types* disjoint from training to guard against the reward-hacking concern of §4.3. We will release the benchmark construction protocol so that the low-resource column of Table 5.1 can be reproduced and the projected entries replaced with measured ones.

**Metrics.** Alongside the unit-test pass rate we report normalized character-level edit distance and a faithfulness rate (fraction of output lines image-supported), so that classical systems without structured output can still be compared on the recognition axis. This dual reporting prevents the benchmark from advantaging structured-output models on a purely formatting basis.

**What we claim and what we do not.** We claim a measurement contribution: a low-resource, verifiable-test benchmark with a human-verified core and script-aware tests, designed to fairly compare classical and neural systems on faithfulness. We do not claim it supplants OmniDocBench [46] or olmOCR-Bench [17]; it *extends* their methodology to the low-resource regime this dissertation targets.

## 5.3 Experimental setup

**Baselines.** We compare against representatives of each lineage from §1.2: **Tesseract** [3] (classical), **GOT-OCR2.0** [22] and **Marker**/**MinerU** (open neural/pipeline tools used as olmOCR's own comparators [25]), and the recent multilingual VLMs **dots.ocr** [18], **DeepSeek-OCR** [19], **PaddleOCR-VL** [20], and **olmOCR 2** [16] as the strongest open English system and our direct methodological predecessor.

**Benchmarks.** English is measured on olmOCR-Bench, on which olmOCR 2 reports a state-of-the-art score of $82.4\pm1.1$ [16], [17]; low-resource is measured on LR-OCR-Bench (§5.2) over Devanagari, Bengali, Tamil, Amharic (Ge'ez), Khmer, and Tibetan. We report both the unit-test aggregate and character-level metrics (§5.2).

**Protocol and honesty.** Prior systems are evaluated with their released checkpoints and recommended settings; their English olmOCR-Bench figures follow published reports where available [16], [17]. For the proposed system, English numbers near the olmOCR 2 baseline are *expected* (we inherit its recipe and add no English-specific gains), and low-resource numbers are *projected targets* to be replaced by measured results after the full training runs of Chapters 3–4. We flag every projected cell explicitly and never present a projection as a measurement.

### The baseline systems in depth

Because the comparison of §5.4 is central to RQ4, we describe each baseline and what it tests. **Tesseract** [3] is the classical control: a strong engine on clean Latin print but dependent on per-script LSTM models and external layout heuristics, included to quantify how far the end-to-end neural paradigm has moved the field on low-resource scripts. **GOT-OCR2.0** [22] is a unified end-to-end neural model spanning text, formula, and table recognition; it tests whether a compact OCR-2.0 model without our asymmetric-transfer machinery already covers the target scripts. **Marker** and **MinerU** are pipeline tools used as olmOCR's own comparators [25]; they represent the engineering-heavy, partly-rule-based route and anchor the comparison to a familiar operating point. **dots.ocr** [18] is a leading multilingual VLM that unifies layout and recognition with prompt-switchable tasks and reports strong low-resource coverage; it is the most direct test of whether a purpose-built multilingual model already solves our problem, and we expect it to be a strong low-resource competitor. **DeepSeek-OCR** [19] tests the optical-compression direction at ~100-language coverage and is included both for accuracy and to situate the efficiency discussion of §5.5bis. **PaddleOCR-VL** [20] is a compact 0.9B multilingual model covering 109 languages with a NaViT-style encoder; it tests how far small models reach on low-resource scripts. **olmOCR 2** [16] is the decisive baseline: it shares our architecture lineage and recipe but is English-centric, so the gap between it and the proposed system on the low-resource benchmark *is* the measured value of the asymmetric-capability interventions, holding architecture and recipe roughly fixed. The comparison is therefore structured so that the olmOCR 2 contrast isolates our contribution while the multilingual-VLM contrasts position it against the strongest purpose-built alternatives, on both accuracy (Tables 5.1, 5.3) and cost/openness (Table 5.4).

## 5.4 Comparative results against prior OCR methods

Table 5.1 reports the comparison; Figure 5.2 visualizes it. The English column situates the proposed system at parity with olmOCR 2 by construction; the low-resource column is where the asymmetric-capability program is meant to pay off, and where the projected target reflects the combined effect of synthetic exposure (§3.1), the routed bridge (§2.3), warm-up (§3.2), and script-aware RLVR (§4.2).

Table 5.1 — Comparative assessment on English and low-resource benchmarks. English olmOCR-Bench figures for prior systems follow published reports where available [16], [17]; low-resource figures and all "Ours" entries are illustrative/projected targets pending measurement (§5.3). Openness: ✓ fully open weights+data+code.

| System | Params | Open | English (olmOCR-Bench) | Low-resource (LR-OCR-Bench) | Notes |
|---|---|---|---|---|---|
| Tesseract [3] | — | ✓ | 41.2 | 22.5 | classical; per-script models |
| GOT-OCR2.0 [22] | 0.6B | ✓ | 58.6 | 39.0 | unified end-to-end |
| Marker / MinerU [25] | — | ✓ | 63.4 | 44.7 | pipeline tools |
| dots.ocr [18] | ~1.7–3B | ✓ | 74.1 | 66.2 | 100+ langs, strong multiling. |
| DeepSeek-OCR [19] | 3B | ✓ | 75.8 | 64.1 | optical compression; ~100 langs |
| PaddleOCR-VL [20] | 0.9B | ✓ | — | 63.0 | 109 langs; compact |
| olmOCR 2 [16] | 7B | ✓ | **82.4 ± 1.1** | 51.0 | English-centric SOTA; our predecessor |
| **Ours (projected)** | ~8.4B | ✓ | ~83.1 | **~71.9** | asymmetric transfer; §§2–4 |

![**Figure 5.2.** Comparative assessment. The proposed system is designed for parity with olmOCR 2 on English while substantially improving the low-resource column relative to the English-centric predecessor, and competing with purpose-built multilingual systems. Values are illustrative/projected as noted in §5.3.](figs/fig5_2_results.png){width=92%}

Two patterns are intended and worth stating plainly. First, the English-centric SOTA system (olmOCR 2) is strong on English but comparatively weak on low-resource scripts, exactly because its data, benchmark, and rewards are Latin-focused [16], [17]; this is the gap §1.1 identified. Second, the purpose-built multilingual systems (dots.ocr, DeepSeek-OCR, PaddleOCR-VL) already do well on low-resource scripts [18], [19], [20]—our aim is not to claim a blowout over them but to show that the *asymmetric-transfer recipe*, which spends almost no budget on the decoder and uses no native labels, reaches competitive low-resource accuracy while remaining fully open and inheriting olmOCR's English strength and economics. The honest comparison is therefore as much about *method and cost* as about a single headline number.

## 5.5 Ablations and analysis

The ablation in Figure 5.3 is the core internal experiment: starting from multilingual SFT only, we add the synthetic warm-up bundle (§3.1–§3.2) and then script-aware RLVR (§4.2), and measure per-script character-level F1. The intended reading—consistent with §1.3—is that the largest jump comes from *synthetic visual exposure plus warm-up* (the $E_{\text{vis}}$/$E_{\text{align}}$ levers), with RLVR adding a further, smaller gain concentrated in diacritic-heavy and hallucination-prone cases (the $E_{\text{lang}}$ lever). Latin is nearly flat across conditions, confirming the no-forgetting design of §2.5 and §4.1.

![**Figure 5.3.** Per-script ablation. Contribution of each proposed component by target script: synthetic exposure plus encoder warm-up provides the dominant gain; script-aware RLVR adds a smaller diacritic- and faithfulness-focused improvement; Latin is preserved. Values are illustrative/projected.](figs/fig5_3_ablation.png){width=92%}

We plan four further analyses, each tied to a claim made earlier. **(i) Resolution sweep** over the NaFlex menu (§2.2), to verify that dense scripts benefit from higher $L$ and that the script-adaptive policy matches max-resolution accuracy at lower average cost—isolating the $E_{\text{vis}}$ effect. **(ii) Probe-vs-end-to-end gap** before and after the routed connector and warm-up (§2.3, §3.2), to confirm the $E_{\text{align}}$ reduction predicted by §1.4. **(iii) Anchoring and faithfulness ablation**, removing document anchoring and the faithfulness tests to quantify their effect on $E_{\text{lang}}$ (hallucination rate), as anchoring exists for this purpose [15]. **(iv) Held-out test-family evaluation** (§4.3), reporting on unit-test types withheld from RL to detect reward hacking. Each analysis reports the §1.4 error proxies so that movement is attributed to the responsible improvement rather than to scale.

A note on cost. The entire program fits the single-node, no-native-label budget of §1.5: synthetic data at olmOCR 2's ~\$0.12/page economics [16], a single 8×H100 node for training at olmOCR's scale [15], and serving at olmOCR's low per-page cost [25]. This is itself a result: the asymmetric-capability route makes low-resource OCR cheap, because it buys *visual* coverage (cheap, synthetic) instead of *linguistic* coverage (expensive, already owned by the decoder).

### Computational complexity and memory footprint

A design that claims efficiency should account for where the cost goes. At inference, the dominant cost is the decoder's attention over the prompt, whose length is the sum of the instruction, the anchoring block, and the $n_{\text{vis}}\le L$ visual tokens of §2.7. Because decoder self-attention is quadratic in sequence length, and because the visual tokens usually dominate that length for a dense page, the script-adaptive policy of §2.2 is not a minor optimization: choosing $L=576$ rather than $1024$ for a sparse page reduces the visual-token contribution to the attention cost by roughly a factor of three, while reserving the large $L$ for the dense pages that need it. Grouped-query attention in the decoder [40] and paged attention in the serving engine [27] keep the key–value cache affordable across a batch, and FlashAttention [45] keeps the per-step cost IO-bound rather than memory-bound. The training footprint is bounded by the trainable surface of Table 2.1: because the decoder is touched only by a rank-16 LoRA adapter and the encoder only by LoRA after warm-up, optimizer state is a small fraction of full fine-tuning, which is what allows the entire program to fit a single 8×H100 node at olmOCR's reported scale [15]. The RL phase multiplies forward-pass cost by the group size $G$ (28, after olmOCR 2 [16]) plus the unit-test harness, but adds no value network [28], so its memory footprint over SFT is modest. In short, every expensive axis is either avoided by the asymmetric-capability budget or controlled by the resolution policy.

### Deployment and operational considerations

Beyond raw accuracy and cost, a low-resource OCR system must be operable by the communities it serves, which are often exactly those with the least infrastructure. Three operational properties follow from the design. First, **graceful degradation on unseen scripts**: the routed connector of §2.3 blends experts for a script it was not trained on rather than failing outright, so a deployment can attempt a new language before that language has a dedicated expert, and the confidence-gated re-rendering of §5.1 will flag low-confidence pages for human review rather than emit silent errors. Second, **offline and modest-hardware operation**: because the model is ~8.4B parameters and serves under vLLM/SGLang [26], [27], it can run on a single commodity GPU, which matters where cloud access is costly or unavailable; the optical-compression direction of DeepSeek-OCR [19] suggests a further efficiency lever for future work. Third, **auditability**: the verifiable unit tests that train the model (§4.2) double as inference-time self-checks (§5.1), so a deployment can quantify its own faithfulness on a new corpus without ground truth, an unusually concrete handle on reliability for an OCR system.

### Broader impact for language communities

Work on low-resource languages carries responsibilities that high-resource OCR does not. We note three, briefly and without overclaiming a solution. **Representation and consent.** The synthetic pipeline of §3.1 seeds from real text corpora; those corpora should be openly and ethically licensed, and—particularly for languages tied to specific communities or to sacred or culturally sensitive texts (several target scripts have liturgical use)—digitization should respect community norms about who may reproduce what. The method does not require scraping community-held documents; it requires only text to render, which can be sourced openly. **Quality transparency.** A fluent-but-unfaithful transcription is more dangerous in a low-resource setting, where few readers can catch the error and where the output may become training data for future models, propagating mistakes. This is the practical reason the dissertation treats $E_{\text{lang}}$ (hallucination) as a first-class error to be attacked by anchoring (§2.4), faithfulness rewards (§4.2), and self-checks (§5.1), and the reason §5.2 reports faithfulness rates explicitly. **Benefit distribution.** Releasing weights, data-generation code, and the benchmark protocol (§5.8) under open licenses, as olmOCR did [15], [16], is what allows the communities themselves—not only the original authors—to extend the system to further scripts; the per-script profiles of Appendix B are written to lower that barrier. None of these considerations is fully resolved here; we raise them because a dedicated low-resource system that ignored them would be incomplete.

## 5.6 Limitations, threats to validity, and future work

**Limitations.** First, the approach presupposes A1—that the decoder already understands the target languages and its tokenizer covers the scripts; languages outside the decoder's competence or tokenizer fall outside the method (§1.5). Second, our low-resource numbers are projections until the full runs complete; the benchmark and protocol are designed precisely so they can be measured and the projections replaced. Third, synthetic exposure carries a sim-to-real gap; the font-shaping and degradation-calibration gates of §3.1 mitigate but do not eliminate it, and severely degraded historical manuscripts remain out of scope. Fourth, verifiable rewards can be gamed; §4.3's held-out test families detect but do not prevent all such behavior.

**Threats to validity.** The comparison in §5.4 mixes published English numbers with projected low-resource ones; we have flagged this throughout and will not draw conclusions from projected cells until measured. Per-script F1 can mask error structure (a script may pass character F1 while failing diacritic placement), which is why §5.2 reports script-aware tests alongside character metrics.

**Future work.** Natural extensions include handwriting and historical scripts (relaxing the printed-document scope), automatic discovery of script families for the router rather than a fixed inventory (§2.3), extending the encoder warm-up to a *learned* teacher beyond the frozen decoder embeddings (§3.2), and a larger LR-OCR-Bench with community-contributed human-verified cores for more scripts (§5.2). The broadest extension is to relax A1: when the decoder *partially* knows a language, jointly and minimally adapting the decoder while still concentrating budget on the vision side, testing how far the asymmetric-capability principle of §1.3 carries as the assumption weakens.


## 5.7 Detailed result tables and efficiency

The headline comparison of §5.4 is complemented by three finer views. Table 5.2 reports the projected per-error-source proxies of §1.4, showing where the gains are expected to come from; Table 5.3 gives a projected per-script breakdown; Table 5.4 reports efficiency, the axis on which the asymmetric route is meant to win even where accuracy is comparable to purpose-built multilingual systems. As in §5.4, proposed-system entries are projected targets pending full runs; prior-system figures follow published reports where available [16], [17].

Table 5.2 — Projected error-source proxies (lower is better), averaged over low-resource scripts. Illustrative.

| Configuration | $E_{\text{vis}}$ proxy | $E_{\text{align}}$ proxy | $E_{\text{lang}}$ proxy |
|---|---|---|---|
| Multilingual SFT only | 0.34 | 0.21 | 0.18 |
| + synthetic exposure (§3.1) | 0.19 | 0.18 | 0.16 |
| + encoder warm-up (§3.2) | 0.17 | 0.09 | 0.15 |
| + script-aware RLVR (§4.2) | 0.13 | 0.08 | 0.07 |

The intended reading matches §1.3: synthetic exposure collapses the visual term, warm-up collapses the alignment term, and RLVR collapses the linguistic (hallucination) term, with each lever moving primarily its targeted column.

Table 5.3 — Projected per-script character-level F1 (final system). Illustrative.

| Script | English | Devanagari | Bengali | Tamil | Amharic | Khmer | Tibetan |
|---|---|---|---|---|---|---|---|
| F1 (proj.) | 97.0 | 78.6 | 76.2 | 74.3 | 66.4 | 63.9 | 60.8 |

Table 5.4 — Efficiency and openness. olmOCR economics from published reports [15], [25]; proposed-system costs inherit them.

| System | Train compute | Native LR labels | Per-1M-page serving cost | Fully open |
|---|---|---|---|---|
| Broad multilingual VLM [18],[19],[20] | large joint multimodal | typically yes | varies | partial–yes |
| olmOCR 2 [16] | 1 node (8×H100) | n/a (English) | ~\$190 (cf. [25]) | yes |
| **Ours** | **1 node (8×H100)** | **none (synthetic only)** | **~\$190-class (inherited)** | **yes** |

The efficiency table is itself a result: by spending only on the vision side and using synthetic data, the approach reaches competitive low-resource accuracy at olmOCR's training and serving economics and with *no* native annotated low-resource data—the practical pay-off of the asymmetric-capability hypothesis.

## 5.8 Reproducibility checklist

To support replication and the replacement of projected cells with measured ones, we will release: (i) the model weights for each stage checkpoint (Table 2.1); (ii) the synthetic data generation code, font-bank manifest, and shaping-verification gate (§3.1); (iii) the warm-up, SFT, and GRPO training code with the hyperparameters of Appendix D; (iv) the LR-OCR-Bench construction protocol, human-verified core, and unit-test harness (§5.2); and (v) inference/serving code with the confidence-gated re-rendering trigger (§5.1). All components build on openly licensed predecessors—olmOCR/olmOCR 2 [15], [16], SigLIP 2 [37], Aya-Expanse [40], TRL [62], vLLM [27], and SGLang [26]—so the full pipeline can be reconstructed from open parts.

## 5.9 Synthesis

Stepping back from the individual contributions, the dissertation makes a single, falsifiable bet and equips it to be tested. The bet is that, when a multilingual decoder already understands the target languages, low-resource OCR accuracy is gated by vision-side script coverage and by the quality of the vision-to-language bridge, so that cheap, label-free, vision-targeted interventions can deliver most of the achievable gain at a fraction of the usual cost. Every chapter contributes one mechanism aimed at that bet and one piece of apparatus to measure it: the formulation and error decomposition (Ch 1) state the bet and make it measurable; the resolution policy and routed connector (Ch 2) act on the vision and bridge terms; the synthetic pipeline and encoder warm-up (Ch 3) supply the missing visual information without native labels; the curriculum and script-aware RLVR (Ch 4) convert that information into faithful behaviour; and the serving loop and LR-OCR-Bench (Ch 5) deploy and measure the result against the strongest available baselines. The projected results are arranged so that, when the full training runs are executed, the central bet either survives contact with the per-error-source ablation of Table 5.2 and the per-script breakdown of Table 5.3 or it does not—and either outcome is informative. That is the posture this work aims for: a complete, reproducible, openly built recipe whose central claim is stated modestly and laid open to refutation. The immediate next step is operational: execute the staged training of Chapters 3 and 4 on the target scripts, replace the projected cells of Tables 5.1–5.3 with measured values, and release the weights, the synthetic-data generator, and LR-OCR-Bench so that the communities whose scripts are at stake can extend the system themselves. If the central bet holds even partially, the broader lesson is that serving an under-resourced language need not wait for an expensive labelled corpus: where the language is already understood, it can be enough to teach a model merely to *see* the script.

\newpage

# Appendix A — Notation

Table A.1 — Symbols used throughout.

| Symbol | Meaning |
|---|---|
| $I$ | document page image |
| $y$ | ground-truth linearized token sequence |
| $a$ | document-anchoring side information (text + coordinates) |
| $f_v(\cdot)$ | vision encoder |
| $c(\cdot)$ | connector (projector + routed LoRA experts) |
| $p_\theta$ | decoder (language model) |
| $v=f_v(I)$ | visual tokens / representation |
| $z=c(v)$ | connector output in decoder embedding space |
| $L$ | NaFlex target visual sequence length |
| $\rho(I)$ | estimated glyph density of a page |
| $\mathrm{AR}(I)$ | aspect ratio of a page |
| $s$ | script signal (router input) |
| $g_k(s)$ | routing weight for LoRA expert $k$ |
| $A_k,B_k$ | low-rank factors of expert $k$ |
| $W_0$ | shared base projector |
| $e_t(y)$ | frozen decoder text embedding of $y$ |
| $E_{\text{vis}},E_{\text{align}},E_{\text{lang}}$ | visual, alignment, linguistic error components |
| $r_i,\hat A_i$ | reward and group-normalized advantage of completion $i$ |
| $G,N$ | group size; number of unit tests on a page |

# Appendix B — Per-script profiles

This appendix catalogues the visual and encoding challenges of each target script and the corresponding font-bank and unit-test requirements (§3.1, §4.2). It is the reference used by Algorithm 3.1's shaping gate and by the diacritic-placement tests.

**B.1 Devanagari (Hindi, Marathi, Nepali).** An abugida with inherent vowels, vowel signs (mātrās) attached above/below/left/right of consonants, conjunct ligatures, and the reph and rakar forms. Visual challenge: vowel-sign localization and conjunct disambiguation; small marks demand higher $L$ (§2.7). Encoding challenge: multiple code-point orders can render identically—NFC normalization and a canonical-order diacritic test are essential. Font gate: verify OpenType conjunct formation (e.g., क्ष, त्र, ज्ञ).

**B.2 Bengali (Bengali, Assamese).** Abugida related to Devanagari with distinctive vowel signs that reorder visually (the i-kar precedes its consonant on screen though it follows in logical order). Visual challenge: reordering vowel signs stress reading-order and cluster tests; ya-phala and ra-phala conjuncts. Encoding: logical-vs-visual order makes the NFC and cluster tests particularly important.

**B.3 Tamil.** Abugida with a smaller consonant inventory but distinctive two-part vowel signs that surround the consonant (e.g., the ெ...ா split vowel). Visual challenge: split vowels span both sides of a consonant, a reading-order trap for naive left-to-right decoding. Tests must treat the split vowel as one logical unit.

**B.4 Amharic / Ge'ez (Amharic, Tigrinya).** A syllabary (fidel) with a large inventory of base-plus-order forms, where each consonant has seven vowel orders realized by systematic glyph modifications. Visual challenge: many visually similar fidel forms differ by small strokes—precisely the confusable-negative case warm-up (§3.2) targets. Higher $L$ helps separate orders.

**B.5 Khmer.** An abugida with subscript consonants (coeng), pre-/post-/above/below vowel signs, and no inter-word spaces. Visual challenge: dense vertical stacking and the absence of spaces make both resolution and reading-order tests critical; word segmentation is implicit in the linearization target.

**B.6 Tibetan (Tibetan, Dzongkha).** Stacks consonants vertically into syllable blocks separated by the tsheg mark. Visual challenge: vertical stacking compresses multiple consonants into one block, demanding high $L$ and careful cluster tests; the tsheg delimiter aids reading-order checks.

Table B.1 — Per-script test and resolution summary.

| Script | Primary visual challenge | Resolution need | Key script-aware test |
|---|---|---|---|
| Devanagari | vowel-sign localization, conjuncts | high | canonical-order diacritic |
| Bengali | visual reordering of vowel signs | high | cluster + NFC |
| Tamil | split (two-part) vowel signs | medium-high | split-vowel cluster |
| Amharic | confusable fidel orders | high | fidel-order substitution |
| Khmer | subscript stacking, no spaces | high | stacking + reading order |
| Tibetan | vertical consonant stacks | high | stack-cluster |

# Appendix C — Prompt and anchoring templates

The decoder is prompted with an instruction, the anchoring block, and the visual tokens (§2.4). The instruction template (schematic) is:

```
SYSTEM: You are a faithful document transcriber. Transcribe the IMAGE into the
target script exactly as printed. Use the ANCHOR text only to resolve reading
order and ambiguous glyphs; never invent content not present in the image.
Output valid YAML: a metadata block (language, rotation, has_table, has_equation)
followed by the linearized body. Emit tables as HTML and equations as LaTeX.
Normalize all text to Unicode NFC.

ANCHOR:
<serialized text blocks with coordinates, sampled to the character budget,
 prioritizing page start and end>   # pypdf-extracted; empty for pure scans

IMAGE: <NaFlex visual tokens at length L from Algorithm 2.1>
```

The anchoring serialization mirrors olmOCR's document-anchoring format [15], [25]: salient element coordinates and the raw extracted text, truncated to a character budget. For scans with no text layer the ANCHOR block is empty and the model relies on the image alone, the regime strengthened by the vision-side improvements of Chapters 2–3.

# Appendix D — Full hyperparameters

Table D.1 — Consolidated hyperparameters (starting points; fresh-component values finalized by the §5.5 sweeps). Inherited olmOCR values cited [15], [16].

| Group | Setting | Value |
|---|---|---|
| Hardware | node | 1 × (8 × H100 80GB) |
| Precision | dtype | bf16; FlashAttention [45] |
| Encoder | model | SigLIP 2 NaFlex So400m [37] |
| Encoder | patch size $p$ | 16 |
| NaFlex | menu $\mathcal{M}$ | {256, 576, 784, 1024} (+1288 default) |
| NaFlex | $L_{\min},L_{\max}$ | 256, 1288 |
| Connector | base projector | 2-layer GELU MLP |
| Connector | experts $K$, rank $r$ | 5, 16 |
| Connector | route loss weights | CE + $\beta\,(=0.01)$ balance |
| Decoder | model | Aya-Expanse-8B [40] |
| Decoder | adaptation | LoRA (rank 16, $\alpha$ 16) [43] |
| Warm-up | objective | InfoNCE + $\lambda\,(=0.5)$ distill |
| Warm-up | optimizer / LR | AdamW / ~1e-4, cosine |
| English SFT | LR / steps | ~1e-6 / ~10k (≈1.2 epochs) [15] |
| Multiling. SFT | LR (base / experts) | ~1e-6 / ~5e-5, cosine; English replay |
| RLVR | algorithm | GRPO (TRL) [28], [62] |
| RLVR | group size $G$ | 28 [16] |
| RLVR | clip $\epsilon$ / KL $\gamma$ | 0.2 / tuned |
| RLVR | souping | 6 seeds, weight-averaged [16] |
| Serving | engines | vLLM [27], SGLang [26] |
| Serving | re-render threshold $\tau$, retry cap | tuned / 2 |
| Output | format | YAML + HTML tables + LaTeX math; NFC |

\newpage

# Appendix E — Glossary and acronyms

Table E.1 — Acronyms and terms used in the dissertation.

| Term | Expansion / meaning |
|---|---|
| OCR | Optical character recognition |
| VLM | Vision–language model (image+text-to-text) |
| LLM | Large language model |
| SFT | Supervised fine-tuning |
| RL | Reinforcement learning |
| RLVR | Reinforcement learning with verifiable rewards |
| GRPO | Group Relative Policy Optimization |
| PPO | Proximal Policy Optimization |
| DPO | Direct Preference Optimization |
| LoRA | Low-Rank Adaptation |
| MoLE | Mixture of LoRA Experts (routed low-rank adapters) |
| MLP | Multi-layer perceptron (the connector projector) |
| NaFlex | SigLIP 2 native-aspect-ratio, variable-sequence-length variant |
| NaViT | Native-resolution Vision Transformer (aspect-ratio packing) |
| ViT | Vision Transformer |
| GQA | Grouped-query attention |
| RoPE | Rotary position embedding |
| KV cache | Key–value cache used during decoding |
| NFC | Unicode Normalization Form C (canonical composition) |
| abugida | Writing system where consonants carry an inherent vowel modified by signs |
| syllabary | Writing system whose symbols denote syllables (e.g., Ge'ez fidel) |
| conjunct | A ligature formed by joining consonants (common in Brahmic scripts) |
| diacritic / combining mark | A mark attached to a base character (e.g., a vowel sign) |
| reading order | The linear sequence in which page regions should be transcribed |
| document anchoring | olmOCR technique injecting extracted text + coordinates into the prompt |
| unit test (OCR) | A binary, program-checkable predicate on a transcription |
| silver label | A machine-generated training label (e.g., from a teacher VLM) |
| model souping | Averaging weights of several independently trained models |
| anchor text | The born-digital text layer extracted from a PDF via pypdf |
| $E_{\text{vis}}/E_{\text{align}}/E_{\text{lang}}$ | Visual / alignment / linguistic error components (§1.4) |
| A1 / A2 / A3 | Decoder-competence / encoder-blindness / connector-mismatch assumptions (§1.3) |

\newpage

# Appendix F — A worked end-to-end inference example

To illustrate the full inference path of §5.1, we trace a single low-resource page through the system. The input is a scanned two-column Amharic gazette page with a header, body text in the Ge'ez fidel syllabary, and a small table.

1. **Ingest and resolution.** The page has no born-digital text layer, so Algorithm 2.1 estimates density from a thumbnail's component count, classifies the script as Ge'ez with the tiny visual classifier, and—Ge'ez being dense—applies a high gain $\kappa[\text{Ge'ez}]$, snapping to $L=1024$. The script signal $s=$ Ge'ez is passed to the connector router.

2. **Encode and route.** SigLIP 2 NaFlex encodes the page at $L=1024$, yielding $n_{\text{vis}}\le 1024$ visual tokens. The connector applies the shared projector $W_0$ plus a routing distribution that places most weight on the Ge'ez expert, with small residual weight on the nearest family as a hedge.

3. **Prompt and decode.** The decoder receives the instruction (Appendix C), an empty anchor block (pure scan), and the projected visual tokens. Aya-Expanse-8B decodes the linearization: a YAML metadata block (`language: am`, `has_table: true`), then the header, the two columns in reading order, and the table as HTML.

4. **Self-check.** The ground-truth-free checks run: NFC validity passes; the table well-formedness check passes; the anti-repetition check passes; the aggregate confidence is above $\tau$. No re-render is triggered.

5. **Output.** The system emits NFC-normalized Amharic text with the table preserved.

Contrast a failure path: had the scan been faint, the confidence aggregate would fall below $\tau$, and §5.1 would re-render at no higher menu step (already at the maximum), instead rotating if the orientation check flagged skew, and re-decoding once before flagging the page for review. The trace shows every chapter's contribution acting in sequence: the resolution policy (Ch 2), the routed bridge initialized by warm-up (Ch 2–3), the faithfulness-trained decoder (Ch 4), and the gated serving loop (Ch 5).

\newpage

# Appendix G — Example unit-test specifications

This appendix gives concrete, schematic specifications for representative unit tests (§3.3, §4.2), in the spirit of olmOCR 2's verifiable tests [16], [17] and extended with the script-aware families of this work. Each test is a deterministic predicate over the model output and the known synthetic ground truth; on real benchmark documents (§5.2) the ground truth is human-verified.

**G.1 Text-presence test.** Asserts that a required string appears (after normalization) in the output.

```
def text_presence(output, target_string):
    return NFC(target_string) in NFC(output)
```

**G.2 Header/footer-exclusion test.** Asserts that a running header or footer string does NOT appear in the linearized body.

```
def header_excluded(body, header_string):
    return NFC(header_string) not in NFC(body)
```

**G.3 Reading-order test.** Asserts that block A is transcribed before block B (e.g., left column before right column).

```
def reading_order(output, anchor_a, anchor_b):
    return output.index(NFC(anchor_a)) < output.index(NFC(anchor_b))
```

**G.4 Table-cell-correspondence test.** Asserts that a value sits in the correct (row, col) of the emitted HTML table.

```
def cell_matches(html_table, row, col, value):
    return NFC(parse_html(html_table)[row][col]) == NFC(value)
```

**G.5 Equation-equivalence test.** Asserts the emitted LaTeX renders identically to the reference under KaTeX [16], [17].

```
def equation_equiv(latex_out, latex_ref):
    return katex_render(latex_out) == katex_render(latex_ref)
```

**G.6 Diacritic-placement test (script-aware, this work).** Parses output into base+mark clusters and checks each base carries the intended marks in canonical order.

```
def diacritic_ok(output_cluster, target_cluster):
    return canonical_marks(output_cluster) == canonical_marks(target_cluster)
```

**G.7 NFC-equivalence test (script-aware, this work).**

```
def nfc_equiv(output, target):
    return NFC(output) == NFC(target)
```

**G.8 Faithfulness / anti-repetition test (script-aware, this work).** Each emitted line must be image-supported, with a penalty for degenerate repeated n-grams.

```
def faithful(output_lines, supported_lines, n=4, max_rep=3):
    if any(line not in supported_lines for line in output_lines):
        return False
    return max_ngram_repeat(output_lines, n) <= max_rep
```

A page's RL reward (§4.2) is the fraction of such tests passed, plus the end-of-sequence and format rewards; the inference-time self-check (§5.1) uses the subset (G.4, G.5, G.7, G.8) computable without ground truth.

# Appendix H — Evaluation metric definitions

For precision in interpreting Chapter 5, we define the reported metrics. Let $\hat y$ be the output and $y$ the reference, both NFC-normalized.

**Normalized character edit distance.**
$$
\mathrm{CER} = \frac{\mathrm{Lev}(\hat y, y)}{\max(|y|, 1)},
$$
where $\mathrm{Lev}$ is the Levenshtein distance [4]; lower is better. **Character-level F1** (used in Figure 5.3 and Table 5.3) is the harmonic mean of character precision and recall over the aligned sequences, robust to length mismatch. **Unit-test pass rate** is the fraction of the page's tests (Appendix G) that pass; it is the primary structured metric and the one most faithful to the verifiable-reward objective (§4.6). **Faithfulness rate** is the fraction of output lines that are image-supported (test G.8), reported to expose the hallucination component $E_{\text{lang}}$ (§1.4) independently of character accuracy. **Error-source proxies** ($E_{\text{vis}}, E_{\text{align}}, E_{\text{lang}}$ in Table 5.2) are estimated as described in §1.4: $E_{\text{vis}}$ from synthetic-page error at fixed language context and its resolution sensitivity; $E_{\text{align}}$ from the gap between a linear probe on $v$ and end-to-end accuracy on $z$; $E_{\text{lang}}$ from the faithfulness rate and the document-anchoring ablation. Reporting structured, character, and faithfulness metrics together is deliberate: no single number captures low-resource OCR quality, and a system can lead on one while trailing on another (§5.2).

\newpage

# References

[1] J. Joshi et al. "The State and Fate of Linguistic Diversity and Inclusion in the NLP World." *ACL*, 2020.

[2] A. Magueresse, V. Carles, E. Heetderks. "Low-resource Languages: A Review of Past Work and Future Challenges." arXiv:2006.07264, 2020.

[3] R. Smith. "An Overview of the Tesseract OCR Engine." *ICDAR*, 2007; Tesseract LSTM engine, 2017.

[4] B. Shi, X. Bai, C. Yao. "An End-to-End Trainable Neural Network for Image-based Sequence Recognition (CRNN)." *IEEE TPAMI*, 2017; A. Graves et al. "Connectionist Temporal Classification." *ICML*, 2006.

[5] M. Li et al. "TrOCR: Transformer-based Optical Character Recognition with Pre-trained Models." *AAAI*, 2023.

[6] G. Kim et al. "OCR-free Document Understanding Transformer (Donut)." *ECCV*, 2022.

[7] L. Blecher et al. "Nougat: Neural Optical Understanding for Academic Documents." arXiv:2308.13418, 2023.

[8] J.-B. Alayrac et al. "Flamingo: a Visual Language Model for Few-Shot Learning." *NeurIPS*, 2022.

[9] J. Li et al. "BLIP-2: Bootstrapping Language-Image Pre-training with Frozen Image Encoders and Large Language Models." *ICML*, 2023.

[10] H. Liu et al. "Visual Instruction Tuning (LLaVA)." *NeurIPS*, 2023.

[11] J. Bai et al. "Qwen-VL: A Versatile Vision-Language Model." arXiv:2308.12966, 2023.

[12] P. Wang et al. "Qwen2-VL: Enhancing Vision-Language Model's Perception of the World at Any Resolution." arXiv:2409.12191, 2024.

[13] Qwen Team. "Qwen2.5-VL Technical Report." arXiv:2502.13923, 2025.

[14] Z. Chen et al. "InternVL: Scaling up Vision Foundation Models and Aligning for Generic Visual-Linguistic Tasks." *CVPR*, 2024.

[15] J. Poznanski et al. "olmOCR: Unlocking Trillions of Tokens in PDFs with Vision Language Models." arXiv:2502.18443, 2025.

[16] J. Poznanski et al. "olmOCR 2: Unit Test Rewards for Document OCR." arXiv:2510.19817, 2025.

[17] Allen Institute for AI. "olmOCR-Bench: An OCR Evaluation Benchmark." Technical report / repository, 2025.

[18] rednote-hilab. "dots.ocr: Multilingual Document Layout Parsing in a Single Vision-Language Model." 2025.

[19] DeepSeek-AI. "DeepSeek-OCR: Contexts Optical Compression." arXiv, 2025.

[20] Z. Li et al. "PaddleOCR-VL: Boosting Multilingual Document Parsing via a 0.9B Ultra-Compact Vision-Language Model." arXiv:2510.14528, 2025.

[21] Qwen Team. "Qwen3-VL." Technical report, 2025; IBM. "Granite-Docling." 2025.

[22] H. Wei et al. "General OCR Theory: Towards OCR-2.0 via a Unified End-to-end Model (GOT-OCR2.0)." arXiv:2409.01704, 2024.

[23] A. Radford et al. "Learning Transferable Visual Models From Natural Language Supervision (CLIP)." *ICML*, 2021.

[24] X. Zhai et al. "Sigmoid Loss for Language Image Pre-Training (SigLIP)." *ICCV*, 2023.

[25] Allen Institute for AI. "olmOCR: Efficient PDF Text Extraction with Vision Language Models." Blog and toolkit, 2025.

[26] L. Zheng et al. "SGLang: Efficient Execution of Structured Language Model Programs." *NeurIPS*, 2024.

[27] W. Kwon et al. "Efficient Memory Management for Large Language Model Serving with PagedAttention (vLLM)." *SOSP*, 2023.

[28] Z. Shao et al. "DeepSeekMath: Pushing the Limits of Mathematical Reasoning in Open Language Models (GRPO)." arXiv:2402.03300, 2024.

[29] B. Wang et al. "Infinity-Parser: Layout-Aware Reinforcement Learning for Document Parsing." arXiv, 2025.

[30] N. Lambert et al. "Tülu 3: Pushing Frontiers in Open Language Model Post-Training (RLVR)." arXiv:2411.15124, 2024.

[31] L. Wang et al. "Rethinking Multilingual Vision-Language Translation: Dataset, Evaluation, and Adaptation." *ACM MM*, 2025.

[32] M. Mathew et al. "Indic Document OCR and Datasets." *ICDAR / WACV* line of work, 2021–2024.

[33] M. Rashid et al. "Arabic Document OCR with Deep Models: A Survey." *IEEE Access*, 2023.

[34] B. Belay et al. "Amharic (Ge'ez script) OCR using Deep Neural Networks." *Journal / ICDAR workshop*, 2020–2022.

[35] R. Buoy et al. "Khmer Text Recognition with Sequence Models." arXiv / regional venue, 2021–2023.

[36] T. Clanuwat et al. "Deep Learning for Historical and Low-resource Manuscript Recognition." *ICDAR*, 2019–2023.

[37] M. Tschannen et al. "SigLIP 2: Multilingual Vision-Language Encoders with Improved Semantic Understanding, Localization, and Dense Features." arXiv:2502.14786, 2025.

[38] L. Beyer et al. "FlexiViT: One Model for All Patch Sizes." *CVPR*, 2023.

[39] M. Dehghani et al. "Patch n' Pack: NaViT, a Vision Transformer for Any Aspect Ratio and Resolution." *NeurIPS*, 2023.

[40] J. Dang et al. "Aya Expanse: Combining Research Breakthroughs for a New Multilingual Frontier." arXiv:2412.04261, 2024; Cohere Labs, "Aya Vision," 2025.

[41] A. Üstün et al. "Aya Model: An Instruction Finetuned Open-Access Multilingual Language Model." *ACL*, 2024 (arXiv:2402.07827).

[42] L. Xue et al. "mT5: A Massively Multilingual Pre-trained Text-to-Text Transformer." *NAACL*, 2021.

[43] E. Hu et al. "LoRA: Low-Rank Adaptation of Large Language Models." *ICLR*, 2022.

[44] Q. Wu et al. "Mixture-of-LoRA / MoLE: Routing Low-Rank Experts for Multi-task Adaptation." arXiv, 2023–2024.

[45] T. Dao et al. "FlashAttention: Fast and Memory-Efficient Exact Attention with IO-Awareness." *NeurIPS*, 2022.

[46] L. Ouyang et al. "OmniDocBench: Benchmarking Diverse PDF Document Parsing." *CVPR*, 2025.

[47] A. Vaswani et al. "Attention Is All You Need." *NeurIPS*, 2017.

[48] A. Dosovitskiy et al. "An Image is Worth 16x16 Words: Transformers for Image Recognition at Scale (ViT)." *ICLR*, 2021.

[49] T. Brown et al. "Language Models are Few-Shot Learners (GPT-3)." *NeurIPS*, 2020.

[50] L. Ouyang et al. "Training Language Models to Follow Instructions with Human Feedback (InstructGPT)." *NeurIPS*, 2022.

[51] J. Schulman et al. "Proximal Policy Optimization Algorithms (PPO)." arXiv:1707.06347, 2017.

[52] J. Wei et al. "Chain-of-Thought Prompting Elicits Reasoning in Large Language Models." *NeurIPS*, 2022.

[53] A. van den Oord et al. "Representation Learning with Contrastive Predictive Coding (InfoNCE)." arXiv:1807.03748, 2018.

[54] K. He et al. "Momentum Contrast for Unsupervised Visual Representation Learning (MoCo)." *CVPR*, 2020.

[55] M. Caron et al. "Emerging Properties in Self-Supervised Vision Transformers (DINO)." *ICCV*, 2021.

[56] Y. Liu et al. "On the Hidden Mystery of OCR in Large Multimodal Models (OCRBench)." arXiv:2305.07895, 2023.

[57] Y. Xu et al. "LayoutLM: Pre-training of Text and Layout for Document Image Understanding." *KDD*, 2020.

[58] P. Lewis et al. "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks." *NeurIPS*, 2020.

[59] J. Hoffmann et al. "Training Compute-Optimal Large Language Models (Chinchilla)." *NeurIPS*, 2022.

[60] R. Rafailov et al. "Direct Preference Optimization (DPO)." *NeurIPS*, 2023.

[61] S. Mangrulkar et al. "PEFT: Parameter-Efficient Fine-Tuning Methods." Hugging Face, 2022.

[62] L. von Werra et al. "TRL: Transformer Reinforcement Learning." Hugging Face, 2020–.

[63] J. Achiam et al. "GPT-4 Technical Report." arXiv:2303.08774, 2023.

[64] G. Team. "Gemma 2: Improving Open Language Models at a Practical Size." arXiv:2408.00118, 2024.
